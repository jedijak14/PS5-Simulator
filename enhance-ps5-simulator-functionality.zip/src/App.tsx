import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { Bell } from "lucide-react";
import type { Game, Parental, Profile, Running, Route, Settings, Stage, Wallpaper as WallpaperT } from "./types";
import { DEMO_GAMES } from "./lib/demoGames";
import { STORE_GAMES } from "./lib/catalog";
import { APPS, getApp, type AppDef } from "./lib/apps";
import { getTheme } from "./lib/themes";
import { Ctx, type AppCtx } from "./lib/ctx";
import { appAllowed } from "./lib/rules";
import {
  clearGames, defaultProfile, eraseKeys, factoryReset, getHidden, getInstalled, getLastProfile, getMeta, loadParental, loadProfiles, loadSettings, loadUserGames, loadWallpapers,
  newId, removeGame, removeWallpaper as dbRemoveWallpaper, saveParental, saveProfiles, saveSettings, saveWallpaper, setHidden, setInstalled, setLastProfile,
} from "./lib/store";
import { fileToDataUrl } from "./lib/art";
import { sfx } from "./lib/sfx";
import { music } from "./lib/music";
import { useNav } from "./lib/useNav";
import Wallpaper from "./components/Wallpaper";
import Boot from "./components/Boot";
import ProfileSelect from "./components/Profiles";
import Home from "./components/Home";
import InstallGame from "./components/InstallGame";
import GameRunner from "./components/GameRunner";
import ControlCenter from "./components/ControlCenter";
import Browser from "./components/Browser";
import MediaPlayer from "./components/MediaPlayer";
import SettingsApp from "./components/SettingsApp";
import About from "./components/About";
import Guide from "./components/Guide";
import StoreApp from "./components/StoreApp";
import YouTube from "./components/YouTube";
import { DisneyApp, GenericStreamApp, SpotifyApp } from "./components/Streaming";
import { PSLogo } from "./components/ui";

interface Toast { id: number; msg: string }

function AppSplash({ app }: { app: AppDef }) {
  return (
    <div className="pointer-events-none absolute inset-0 z-[55] flex flex-col items-center justify-center" style={{ background: app.bg, color: app.fg, animation: "fade-out 0.55s ease 0.6s forwards" }}>
      <div style={{ animation: "logo-in 0.7s cubic-bezier(.2,.8,.2,1) both" }}><app.Icon className="h-[8rem] w-[8rem]" /></div>
      <div className="mt-4 text-[1.6rem] font-semibold" style={{ animation: "rise-in 0.6s ease 0.15s both" }}>{app.name}</div>
    </div>
  );
}

const SYSTEM = new Set(["settings", "about"]);

export default function App() {
  const [stage, setStage] = useState<Stage>("booting");
  const [quickBoot] = useState(false);
  const [bootKey, setBootKey] = useState(0);
  const [blackout, setBlackout] = useState(false);
  const [settings, setSettings] = useState<Settings>(loadSettings);
  const [parental, setParentalState] = useState<Parental>(loadParental);
  const [profiles, setProfiles] = useState<Profile[]>(() => {
    const p = loadProfiles();
    if (p.length) return p;
    const d = defaultProfile();
    saveProfiles([d]);
    return [d];
  });
  const [activeId, setActiveId] = useState<string | null>(null);
  const [wallpapers, setWallpapers] = useState<WallpaperT[]>([]);
  const [userGames, setUserGames] = useState<Game[]>([]);
  const [hidden, setHiddenState] = useState<string[]>(getHidden);
  const [installed, setInstalledState] = useState<string[]>(getInstalled);
  const [metaTick, setMetaTick] = useState(0);
  const [route, setRoute] = useState<Route>({ type: "home" });
  const [running, setRunning] = useState<Running[]>([]);
  const [cc, setCc] = useState(false);
  const [installOpen, setInstallOpen] = useState(false);
  const [toasts, setToasts] = useState<Toast[]>([]);
  const [fullscreen, setFullscreen] = useState(false);
  const [intro, setIntro] = useState(true);
  const [returnKey, setReturnKey] = useState(0);
  const [splash, setSplash] = useState<{ id: string; n: number } | null>(null);
  const toastId = useRef(0);
  const splashN = useRef(0);

  const lastId = getLastProfile();
  const profile = profiles.find((p) => p.id === activeId) ?? profiles.find((p) => p.id === lastId) ?? profiles[0];
  const theme = getTheme(profile.theme);
  const restricted = parental.enabled && profile.child;
  const wallpaperImage = (profile.wallpaper ? wallpapers.find((w) => w.id === profile.wallpaper)?.data : null) ?? theme.image ?? null;

  /* ---------- persistence & services ---------- */
  useEffect(() => { void loadUserGames().then(setUserGames); void loadWallpapers().then(setWallpapers); }, []);
  useEffect(() => { saveProfiles(profiles); }, [profiles]);
  useEffect(() => { sfx.setVolume(settings.volume); sfx.setEnabled(settings.sfx); }, [settings.volume, settings.sfx]);
  useEffect(() => { music.setVolume(settings.musicVolume); }, [settings.musicVolume]);
  useEffect(() => { music.setMood(theme.mood); }, [theme.mood]);
  useEffect(() => {
    const f = () => setFullscreen(!!document.fullscreenElement);
    document.addEventListener("fullscreenchange", f);
    return () => document.removeEventListener("fullscreenchange", f);
  }, []);
  useEffect(() => {
    document.documentElement.style.fontSize = settings.largeText ? "calc(min(100vw / 80, 100vh / 45) * 1.12)" : "";
  }, [settings.largeText]);

  // audio needs a user gesture – unlock on the first one, then (re)start ambient music
  useEffect(() => {
    const u = () => {
      sfx.unlock();
      [120, 500, 1200].forEach((t) => window.setTimeout(() => music.retry(), t));
    };
    window.addEventListener("pointerdown", u);
    window.addEventListener("keydown", u);
    return () => { window.removeEventListener("pointerdown", u); window.removeEventListener("keydown", u); };
  }, []);

  const on = stage === "on";
  const ambient = settings.music && stage !== "booting" && !running.some((r) => !(r.kind === "app" && r.id === "browser"));
  useEffect(() => { music.setActive(ambient); }, [ambient]);

  const update = useCallback((p: Partial<Settings>) => {
    setSettings((s) => { const n = { ...s, ...p }; saveSettings(n); return n; });
  }, []);
  const setParental = useCallback((p: Partial<Parental>) => {
    setParentalState((s) => { const n = { ...s, ...p }; saveParental(n); return n; });
  }, []);

  const notify = useCallback((msg: string) => {
    const id = ++toastId.current;
    setToasts((t) => [...t.slice(-2), { id, msg }]);
    sfx.notify();
    window.setTimeout(() => setToasts((t) => t.filter((x) => x.id !== id)), 3800);
  }, []);

  /* ---------- library ---------- */
  const games = useMemo(() => {
    const meta = getMeta();
    return [...DEMO_GAMES.filter((g) => !hidden.includes(g.id)), ...STORE_GAMES.filter((g) => installed.includes(g.id)), ...userGames].map((g) => ({
      ...g, lastPlayed: meta[g.id]?.lastPlayed, playtime: meta[g.id]?.playtime ?? 0,
    }));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [userGames, hidden, installed, metaTick]);

  /* ---------- navigation & running apps ---------- */
  const goHome = useCallback(() => {
    setCc(false);
    setRoute({ type: "home" });
    setIntro(false);
    setReturnKey((k) => k + 1);
  }, []);
  useEffect(() => { if (route.type === "home") setMetaTick((t) => t + 1); }, [route.type]);

  const openApp = useCallback((id: string) => {
    const def = getApp(id);
    if (def && !appAllowed(def, restricted, parental)) { sfx.error(); notify("Blocked by Parental Controls"); return; }
    sfx.open();
    setCc(false);
    const already = running.some((r) => r.kind === "app" && r.id === id);
    if (def?.persist && !already) setRunning((r) => [...r, { kind: "app", id }]);
    if (def && !already) setSplash({ id, n: ++splashN.current });
    setRoute({ type: "app", id });
  }, [running, restricted, parental, notify]);

  const launchGame = useCallback((g: Game) => {
    setCc(false);
    if (!running.some((r) => r.kind === "game" && r.id === g.id)) setRunning((r) => [...r, { kind: "game", id: g.id }]);
    else sfx.open();
    setRoute({ type: "game", id: g.id });
  }, [running]);

  const closeRunning = useCallback((r: Running) => {
    setRunning((l) => l.filter((x) => !(x.kind === r.kind && x.id === r.id)));
    setRoute((cur) => ((cur.type === "game" && r.kind === "game" && cur.id === r.id) || (cur.type === "app" && r.kind === "app" && cur.id === r.id) ? { type: "home" } : cur));
    setIntro(false);
    setReturnKey((k) => k + 1);
  }, []);

  const toggleFullscreen = useCallback(() => {
    if (document.fullscreenElement) void document.exitFullscreen();
    else void document.documentElement.requestFullscreen?.().catch(() => undefined);
  }, []);

  /* ---------- installs ---------- */
  const install = useCallback((id: string) => {
    setInstalledState((l) => { if (l.includes(id)) return l; const n = [...l, id]; setInstalled(n); return n; });
  }, []);
  const uninstall = useCallback((id: string) => {
    setInstalledState((l) => { const n = l.filter((x) => x !== id); setInstalled(n); return n; });
    setRunning((l) => l.filter((r) => r.id !== id));
    setRoute((cur) => ((cur.type === "game" || cur.type === "app") && cur.id === id ? { type: "home" } : cur));
    notify("Deleted");
  }, [notify]);

  const deleteGame = useCallback(async (g: Game) => {
    if (g.builtin) {
      const h = [...hidden, g.id];
      setHidden(h);
      setHiddenState(h);
      setRunning((l) => l.filter((r) => r.id !== g.id));
    } else if (g.url) {
      uninstall(g.id);
      return;
    } else {
      await removeGame(g.id).catch(() => undefined);
      setUserGames((u) => u.filter((x) => x.id !== g.id));
      setRunning((l) => l.filter((r) => r.id !== g.id));
    }
    notify(`${g.title} deleted`);
  }, [hidden, notify, uninstall]);

  const deleteAllGames = useCallback(async () => {
    const h = DEMO_GAMES.map((g) => g.id);
    setHidden(h);
    setHiddenState(h);
    const keep = installed.filter((id) => !STORE_GAMES.some((g) => g.id === id));
    setInstalled(keep);
    setInstalledState(keep);
    await clearGames().catch(() => undefined);
    setUserGames([]);
    setRunning((l) => l.filter((r) => r.kind !== "game"));
    notify("All games deleted");
  }, [installed, notify]);

  const eraseAll = useCallback(() => {
    void factoryReset().then(() => window.location.reload());
  }, []);

  /* ---------- profiles & wallpapers ---------- */
  const updateProfile = useCallback((patch: Partial<Profile>, id?: string) => {
    setProfiles((ps) => ps.map((p) => (p.id === (id ?? profile.id) ? { ...p, ...patch } : p)));
  }, [profile.id]);
  const addProfile = useCallback((p: Partial<Profile>): Profile => {
    const np: Profile = { id: newId(), name: "Player", avatar: "robot", theme: "midnight", wallpaper: null, child: false, createdAt: Date.now(), ...p };
    setProfiles((ps) => [...ps, np]);
    return np;
  }, []);
  const deleteProfile = useCallback((id: string) => {
    setProfiles((ps) => (ps.length <= 1 ? ps : ps.filter((p) => p.id !== id)));
    eraseKeys((k) => k.startsWith(`ps5.p.${id}.`));
  }, []);

  const addWallpaper = useCallback(async (file: File) => {
    try {
      const data = await fileToDataUrl(file, 2560);
      const w: WallpaperT = { id: newId(), name: file.name.replace(/\.[^.]+$/, "").slice(0, 28) || "Wallpaper", data, addedAt: Date.now() };
      await saveWallpaper(w);
      setWallpapers((l) => [...l, w]);
      updateProfile({ wallpaper: w.id });
      notify("Wallpaper uploaded and applied");
    } catch {
      sfx.error();
      notify("Couldn't read that image");
    }
  }, [notify, updateProfile]);
  const removeWallpaper = useCallback((id: string) => {
    void dbRemoveWallpaper(id).catch(() => undefined);
    setWallpapers((l) => l.filter((w) => w.id !== id));
    setProfiles((ps) => ps.map((p) => (p.wallpaper === id ? { ...p, wallpaper: null } : p)));
  }, []);

  /* ---------- power ---------- */
  const transition = useCallback((then: () => void) => {
    setCc(false);
    sfx.shutdown();
    setBlackout(true);
    window.setTimeout(() => {
      setRoute({ type: "home" });
      setRunning([]);
      setInstallOpen(false);
      setIntro(true);
      then();
      setBlackout(false);
    }, 1000);
  }, []);
  const restart = useCallback(() => transition(() => { setBootKey((k) => k + 1); setStage("booting"); }), [transition]);
  const switchUser = useCallback(() => transition(() => setStage("profiles")), [transition]);

  const pickProfile = (p: Profile) => {
    setActiveId(p.id);
    setLastProfile(p.id);
    setStage("on");
    setIntro(true);
    setReturnKey((k) => k + 1);
    window.setTimeout(() => notify(`Welcome, ${p.name}`), 1400);
  };

  /* ---------- global keys ---------- */
  useNav((a) => { if (a === "ps") { sfx.ps(); setCc(true); } }, on && !cc && !installOpen && !blackout);
  const streamingRoute = route.type === "app" && getApp(route.id)?.group === "streaming";
  useNav((a) => { if (a === "back") { sfx.back(); goHome(); } }, on && streamingRoute && !cc && !installOpen);

  const foreground: Running | null = route.type === "game" ? { kind: "game", id: route.id } : route.type === "app" && !SYSTEM.has(route.id) ? { kind: "app", id: route.id } : route.type === "app" ? { kind: "app", id: route.id } : null;
  const homeActive = on && route.type === "home" && !cc && !installOpen;
  const sysActive = on && !cc && !installOpen && !blackout;

  const ctxValue: AppCtx = {
    settings, update, profile, profiles, theme, wallpaperImage, updateProfile, addProfile, deleteProfile, switchUser, wallpapers, addWallpaper, removeWallpaper,
    parental, setParental, restricted, notify, games, installed, install, uninstall, running, openApp, launchGame, closeRunning, goHome, fullscreen, toggleFullscreen,
    deleteGame: (g) => void deleteGame(g), deleteAllGames: () => void deleteAllGames(), eraseAll, openControlCenter: () => { sfx.ps(); setCc(true); }, restart,
  };

  const filter = settings.brightness !== 1 || settings.hdr ? `brightness(${settings.brightness})${settings.hdr ? " contrast(1.08) saturate(1.25)" : ""}` : undefined;
  const wallPaused = route.type === "game" || (route.type === "app" && !!getApp(route.id)?.persist);

  const renderApp = (def: AppDef, act: boolean) => {
    switch (def.id) {
      case "browser": return <Browser active={act && !cc} />;
      case "media": return <MediaPlayer settings={settings} active={act && !cc} onClose={goHome} notify={notify} />;
      case "spotify": return <SpotifyApp app={def} />;
      case "youtube": return <YouTube app={def} />;
      case "disney": return <DisneyApp app={def} />;
      default: return <GenericStreamApp app={def} />;
    }
  };

  return (
    <Ctx.Provider value={ctxValue}>
      <div className={`ps-font relative h-full w-full overflow-hidden bg-black ${settings.motion ? "" : "reduce-motion"}`} style={{ filter, ["--ps-font" as string]: theme.font }}>
        {stage !== "booting" && <Wallpaper theme={theme} image={wallpaperImage} animate={settings.motion} paused={wallPaused} />}

        {stage === "booting" && <Boot key={bootKey} quick={quickBoot} onDone={() => setStage("profiles")} />}

        {stage === "profiles" && (
          <ProfileSelect
            profiles={profiles}
            lastId={lastId}
            hints={settings.hints}
            onPick={pickProfile}
            onCreate={(v) => addProfile(v)}
            onEdit={(id, v) => updateProfile(v, id)}
            onDelete={(p) => deleteProfile(p.id)}
          />
        )}

        {on && (
          <div className={`absolute inset-0 ${route.type === "home" ? "" : "invisible"}`} style={{ fontFamily: theme.font }}>
            <Home active={homeActive} intro={intro} returnKey={returnKey} onInstall={() => setInstallOpen(true)} />
          </div>
        )}

        {/* running games stay mounted in the background */}
        {on && running.filter((r) => r.kind === "game").map((r) => {
          const g = games.find((x) => x.id === r.id);
          if (!g) return null;
          const act = route.type === "game" && route.id === r.id;
          return (
            <div key={"g" + r.id} className="absolute inset-0 z-30" style={{ visibility: act ? "visible" : "hidden", pointerEvents: act ? "auto" : "none" }}>
              <GameRunner game={g} active={act && !cc} launchSound={settings.gameSound} onPS={() => { sfx.ps(); setCc(true); }} />
            </div>
          );
        })}

        {/* running apps stay mounted in the background */}
        {on && running.filter((r) => r.kind === "app").map((r) => {
          const def = getApp(r.id);
          if (!def) return null;
          const act = route.type === "app" && route.id === r.id;
          return (
            <div key={"a" + r.id} className="absolute inset-0 z-30" style={{ visibility: act ? "visible" : "hidden", pointerEvents: act ? "auto" : "none" }}>
              {renderApp(def, act)}
            </div>
          );
        })}

        {/* system screens close when you leave them */}
        {on && route.type === "app" && route.id === "settings" && <div className="anim-app-enter absolute inset-0 z-30"><SettingsApp active={sysActive} /></div>}
        {on && route.type === "app" && route.id === "about" && <div className="anim-app-enter absolute inset-0 z-30"><About active={sysActive} /></div>}
        {on && route.type === "app" && route.id === "guide" && <div className="anim-app-enter absolute inset-0 z-30"><Guide active={sysActive} /></div>}
        {on && route.type === "app" && route.id === "store" && <div className="anim-app-enter absolute inset-0 z-30"><StoreApp /></div>}

        {on && route.type === "app" && splash && splash.id === route.id && getApp(splash.id) && <AppSplash key={splash.n} app={getApp(splash.id)!} />}

        {installOpen && (
          <div className="absolute inset-0 z-[60]">
            <InstallGame
              showHints={settings.hints}
              onClose={() => setInstallOpen(false)}
              onInstalled={(g) => { setUserGames((u) => [...u.filter((x) => x.id !== g.id), g]); setInstallOpen(false); notify(`${g.title} installed`); }}
            />
          </div>
        )}

        {/* floating PS button when inside an app or game */}
        {on && route.type !== "home" && !cc && (
          <button
            onClick={() => { sfx.ps(); setCc(true); }}
            title="PS button — Control Center (F1)"
            className="group absolute bottom-[1rem] left-[1rem] z-[90] flex h-[2.7rem] w-[2.7rem] items-center justify-center rounded-full bg-black/55 opacity-50 shadow-lg ring-1 ring-white/25 backdrop-blur-md transition-all hover:scale-110 hover:opacity-100"
          >
            <PSLogo className="h-[1.3rem] w-[1.3rem] text-white" />
            {running.length > 1 && <span className="absolute -right-1 -top-1 flex h-[1.1rem] w-[1.1rem] items-center justify-center rounded-full bg-white text-[0.65rem] font-bold text-black">{running.length}</span>}
          </button>
        )}

        {cc && on && <ControlCenter foreground={foreground} onClose={() => setCc(false)} />}

        {/* toasts */}
        <div className="pointer-events-none absolute left-1/2 top-[1.6rem] z-[120] flex -translate-x-1/2 flex-col items-center gap-2">
          {settings.notifications && toasts.map((t) => (
            <div key={t.id} className="glass flex items-center gap-3 rounded-full bg-black/55 px-5 py-[0.6rem] text-[0.92rem] font-medium shadow-2xl" style={{ animation: "rise-in 0.35s ease both" }}>
              <Bell className="h-4 w-4 text-white/80" /> {t.msg}
            </div>
          ))}
        </div>

        {blackout && <div className="anim-fade-in absolute inset-0 z-[200] bg-black" style={{ animationDuration: "0.9s" }} />}
      </div>
    </Ctx.Provider>
  );
}

export { APPS };
