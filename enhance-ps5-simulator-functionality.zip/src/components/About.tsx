import { useEffect, useMemo, useRef, useState, type ReactNode } from "react";
import { ArrowLeft, Cpu, Gamepad2, HardDrive, Info, MemoryStick, Monitor, Speaker, Laptop, Activity, Disc3 } from "lucide-react";
import { useApp } from "../lib/ctx";
import { useNav } from "../lib/useNav";
import { sfx } from "../lib/sfx";
import { getMeta, newId, read, write } from "../lib/store";
import { fmtTime } from "../lib/rules";
import { Hint, HintBar } from "./ui";

const BOOT = Date.now();

function gpuName(): string {
  try {
    const c = document.createElement("canvas");
    const gl = (c.getContext("webgl") || c.getContext("experimental-webgl")) as WebGLRenderingContext | null;
    if (!gl) return "Unavailable";
    const ext = gl.getExtension("WEBGL_debug_renderer_info");
    return ext ? String(gl.getParameter(ext.UNMASKED_RENDERER_WEBGL)) : String(gl.getParameter(gl.RENDERER));
  } catch {
    return "Unavailable";
  }
}
function browserName(): string {
  const ua = navigator.userAgent;
  const m = ua.match(/(Edg|OPR|Chrome|Firefox|Version)\/([\d.]+)/);
  if (!m) return ua.slice(0, 40);
  const n = m[1] === "Edg" ? "Microsoft Edge" : m[1] === "OPR" ? "Opera" : m[1] === "Version" ? "Safari" : m[1];
  return `${n} ${m[2].split(".")[0]}${/Chrome|Edg|OPR/.test(ua) ? " (Chromium)" : ""}`;
}

function Card({ icon, title, color, rows }: { icon: ReactNode; title: string; color: string; rows: [string, string][] }) {
  return (
    <div className="rounded-[1.2rem] bg-white/[0.07] p-5 ring-1 ring-white/10">
      <div className="mb-3 flex items-center gap-3">
        <div className="flex h-[2.4rem] w-[2.4rem] items-center justify-center rounded-full text-white" style={{ background: color }}>{icon}</div>
        <h3 className="text-[1.1rem] font-semibold">{title}</h3>
      </div>
      <div className="divide-y divide-white/[0.07]">
        {rows.map(([k, v]) => (
          <div key={k} className="flex items-start justify-between gap-6 py-[0.5rem] text-[0.88rem]">
            <span className="shrink-0 text-white/55">{k}</span>
            <span className="text-right font-medium text-white/90">{v}</span>
          </div>
        ))}
      </div>
    </div>
  );
}

/** System Software information. Name, software, processor, GPU and a lot more. */
export default function About({ active }: { active: boolean }) {
  const ctx = useApp();
  const ref = useRef<HTMLDivElement>(null);
  const [now, setNow] = useState(Date.now());
  const [storage, setStorage] = useState("…");
  const serial = useMemo(() => {
    const s = read<{ serial?: string }>("ps5.device", {});
    if (s.serial) return s.serial;
    const v = "SIM" + newId().toUpperCase().replace(/[^A-Z0-9]/g, "").slice(0, 9).padEnd(9, "7");
    write("ps5.device", { serial: v });
    return v;
  }, []);

  useEffect(() => {
    const t = window.setInterval(() => setNow(Date.now()), 1000);
    navigator.storage?.estimate?.().then((e) => setStorage(`${((e.usage ?? 0) / 1048576).toFixed(1)} MB used`)).catch(() => setStorage("n/a"));
    return () => clearInterval(t);
  }, []);

  useNav((a) => {
    if (a === "down") ref.current?.scrollBy({ top: 120, behavior: "smooth" });
    else if (a === "up") ref.current?.scrollBy({ top: -120, behavior: "smooth" });
    else if (a === "back") { sfx.back(); ctx.openApp("settings"); }
  }, active);

  const meta = getMeta();
  const totalPlay = Object.values(meta).reduce((n, m) => n + m.playtime, 0);
  const up = Math.floor((now - BOOT) / 1000);
  const upStr = `${Math.floor(up / 3600)}h ${Math.floor((up % 3600) / 60)}m ${up % 60}s`;
  const host = useMemo(() => gpuName(), []);
  const nav = navigator as unknown as { deviceMemory?: number; platform?: string; userAgentData?: { platform?: string } };

  return (
    <div className="absolute inset-0 flex flex-col bg-black/70 text-white backdrop-blur-2xl">
      <div className="absolute inset-0 bg-gradient-to-b from-black/40 to-black/60" />
      <div className="relative z-10 flex items-center gap-4 px-[4rem] pb-3 pt-[1.8rem]">
        <button onClick={() => ctx.openApp("settings")} className="flex h-10 w-10 items-center justify-center rounded-full bg-white/10 hover:bg-white/20"><ArrowLeft className="h-5 w-5" /></button>
        <div className="flex h-[2.6rem] w-[2.6rem] items-center justify-center rounded-full bg-[#6366f1]"><Info className="h-[1.6rem] w-[1.6rem]" /></div>
        <div><h1 className="text-[1.7rem] font-semibold leading-tight">System Software</h1><div className="text-[0.82rem] text-white/50">Console information</div></div>
      </div>

      <div ref={ref} className="no-scrollbar relative z-10 flex-1 overflow-y-auto px-[4rem] pb-24 pt-2">
        {/* headline */}
        <div className="mb-5 grid grid-cols-3 gap-4">
          {[
            { k: "Name", v: "PS5-Simulator" },
            { k: "System Software", v: "Version 11.20.00" },
            { k: "Processor", v: "AMD Zen 2 · 8 cores" },
          ].map((x) => (
            <div key={x.k} className="rounded-2xl bg-gradient-to-br from-white/15 to-white/[0.04] p-5 ring-1 ring-white/10">
              <div className="text-[0.72rem] font-semibold uppercase tracking-[0.2em] text-white/50">{x.k}</div>
              <div className="mt-1 text-[1.5rem] font-semibold">{x.v}</div>
            </div>
          ))}
        </div>

        <div className="grid grid-cols-2 gap-4">
          <Card icon={<Info className="h-5 w-5" />} title="System" color="#6366f1" rows={[
            ["Name", "PS5-Simulator"],
            ["System Software", "Version 11.20.00"],
            ["Software build", "SIM-2026.11 · Release channel"],
            ["Model", "CFI-SIM1215A"],
            ["Serial number", serial],
            ["Console region", "Worldwide"],
            ["Uptime", upStr],
          ]} />
          <Card icon={<Cpu className="h-5 w-5" />} title="Processor" color="#ef4444" rows={[
            ["CPU", "AMD Ryzen™ Zen 2 (custom)"],
            ["Cores / Threads", "8 cores · 16 threads"],
            ["Clock speed", "Up to 3.5 GHz (variable frequency)"],
            ["Process", "7 nm"],
            ["Cache", "4 MB L2 · 8 MB L3"],
            ["Architecture", "x86-64 · SMT enabled"],
          ]} />
          <Card icon={<Gamepad2 className="h-5 w-5" />} title="Graphics (GPU)" color="#22c55e" rows={[
            ["GPU", "AMD Radeon™ RDNA 2 (custom)"],
            ["Compute units", "36 CUs"],
            ["Clock speed", "Up to 2.23 GHz (variable frequency)"],
            ["Performance", "10.28 TFLOPS"],
            ["Ray tracing", "Hardware accelerated"],
            ["Resolution output", "Up to 4K @ 120 Hz · 8K ready"],
          ]} />
          <Card icon={<MemoryStick className="h-5 w-5" />} title="Memory" color="#f59e0b" rows={[
            ["Capacity", "16 GB GDDR6"],
            ["Interface", "256-bit"],
            ["Bandwidth", "448 GB/s"],
            ["Reserved for system", "≈ 2.5 GB"],
          ]} />
          <Card icon={<HardDrive className="h-5 w-5" />} title="Storage" color="#64748b" rows={[
            ["Internal drive", "825 GB custom NVMe SSD"],
            ["Raw read speed", "5.5 GB/s"],
            ["Simulator storage", storage],
            ["Games installed", String(ctx.games.length)],
            ["Apps installed", String(ctx.installed.filter((id) => !ctx.games.some((g) => g.id === id)).length)],
            ["Expansion slot", "M.2 NVMe (simulated)"],
          ]} />
          <Card icon={<Disc3 className="h-5 w-5" />} title="Media, Audio & Video" color="#a855f7" rows={[
            ["Disc drive", "Ultra HD Blu-ray™ (simulated)"],
            ["Audio", "Tempest 3D AudioTech"],
            ["Video output", "HDMI 2.1"],
            ["HDR", ctx.settings.hdr ? "On" : "Off"],
            ["Display (this device)", `${window.innerWidth} × ${window.innerHeight} @ ${window.devicePixelRatio.toFixed(1)}x`],
          ]} />
          <Card icon={<Laptop className="h-5 w-5" />} title="Host Device (real hardware)" color="#0ea5e9" rows={[
            ["Browser engine", browserName()],
            ["Processor threads", String(navigator.hardwareConcurrency ?? "Unknown")],
            ["Device memory", nav.deviceMemory ? `${nav.deviceMemory}+ GB` : "Unknown"],
            ["Graphics", host.length > 44 ? host.slice(0, 44) + "…" : host],
            ["Platform", nav.userAgentData?.platform ?? nav.platform ?? "Unknown"],
            ["Language", navigator.language],
            ["Time zone", Intl.DateTimeFormat().resolvedOptions().timeZone],
          ]} />
          <Card icon={<Activity className="h-5 w-5" />} title="Simulator" color="#14b8a6" rows={[
            ["Users", String(ctx.profiles.length)],
            ["Signed in as", ctx.profile.name],
            ["Active theme", ctx.theme.name],
            ["Apps running", String(ctx.running.length)],
            ["Total play time", fmtTime(totalPlay)],
            ["Uploaded wallpapers", String(ctx.wallpapers.length)],
          ]} />
        </div>
        <div className="mt-6 flex items-center gap-2 text-[0.78rem] text-white/35"><Monitor className="h-4 w-4" /><Speaker className="h-4 w-4" /> This is a simulator for entertainment. PlayStation and PS5 are trademarks of Sony Interactive Entertainment.</div>
      </div>

      <HintBar show={ctx.settings.hints && active}>
        <Hint k="↑↓">Scroll</Hint>
        <Hint k="Esc" glyph="circle">Back</Hint>
      </HintBar>
    </div>
  );
}
