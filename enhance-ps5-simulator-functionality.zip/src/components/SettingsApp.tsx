import { useEffect, useMemo, useRef, useState, type ReactNode } from "react";
import {
  Accessibility, ArrowLeft, BookOpen, Check, Image as ImageIcon, HardDrive, Info, Maximize, Monitor, Palette, Plus, ShieldCheck, Trash2, UserRound, Users, Volume2, Wifi, Settings2, Upload,
} from "lucide-react";
import type { Profile } from "../types";
import { THEMES, THEME_GROUPS, type Theme } from "../lib/themes";
import { AvatarIcon } from "../lib/avatars";
import { useApp } from "../lib/ctx";
import { useNav } from "../lib/useNav";
import { sfx } from "../lib/sfx";
import { AGE_OPTIONS, ageLabel } from "../lib/rules";
import { eraseKeys, localStorageBytes } from "../lib/store";
import { ConfirmDialog, Hint, HintBar, Toggle } from "./ui";
import { MAX_PROFILES, UserEditor } from "./Profiles";

/* ------------------------------------------------------------------ *
 *  PIN dialog (verify or set)
 * ------------------------------------------------------------------ */
export function PinDialog({ title, message, mode, pin, onDone, onCancel }: { title: string; message: string; mode: "verify" | "set"; pin?: string; onDone: (pin: string) => void; onCancel: () => void }) {
  const [digits, setDigits] = useState("");
  const [first, setFirst] = useState<string | null>(null);
  const [err, setErr] = useState("");
  const [shake, setShake] = useState(false);

  const fail = (m: string) => {
    setErr(m);
    setShake(true);
    sfx.error();
    setDigits("");
    window.setTimeout(() => setShake(false), 450);
  };
  const submit = (d: string) => {
    if (mode === "verify") {
      if (d === pin) { sfx.select(); onDone(d); } else fail("Incorrect PIN. Try again.");
    } else if (first === null) {
      setFirst(d); setDigits(""); setErr(""); sfx.select();
    } else if (first === d) { sfx.select(); onDone(d); } else { setFirst(null); fail("PINs did not match. Start again."); }
  };
  const press = (n: string) => {
    sfx.move();
    setErr("");
    setDigits((d) => {
      const nd = (d + n).slice(0, 4);
      if (nd.length === 4) window.setTimeout(() => submit(nd), 120);
      return nd;
    });
  };
  const pressRef = useRef(press);
  pressRef.current = press;

  useEffect(() => {
    const f = (e: KeyboardEvent) => {
      if (/^[0-9]$/.test(e.key)) { e.preventDefault(); e.stopImmediatePropagation(); pressRef.current(e.key); }
      else if (e.key === "Backspace") { e.preventDefault(); e.stopImmediatePropagation(); setDigits((d) => d.slice(0, -1)); }
      else if (e.key === "Escape") { e.preventDefault(); e.stopImmediatePropagation(); sfx.back(); onCancel(); }
    };
    window.addEventListener("keydown", f, true);
    return () => window.removeEventListener("keydown", f, true);
  }, [onCancel]);

  return (
    <div className="anim-fade-in absolute inset-0 z-[90] flex items-center justify-center bg-black/80 backdrop-blur-xl">
      <div className={`anim-pop w-[26rem] rounded-[1.4rem] bg-[#171a22] p-8 text-center shadow-2xl ring-1 ring-white/10 ${shake ? "anim-shake" : ""}`}>
        <ShieldCheck className="mx-auto h-10 w-10 text-white/80" />
        <h3 className="mt-3 text-[1.35rem] font-semibold">{mode === "set" && first !== null ? "Confirm new PIN" : title}</h3>
        <p className="mt-1 text-[0.85rem] text-white/55">{mode === "set" && first !== null ? "Enter the same 4-digit PIN again." : message}</p>
        <div className="my-6 flex justify-center gap-4">
          {[0, 1, 2, 3].map((i) => <div key={i} className={`h-[1rem] w-[1rem] rounded-full transition-all ${i < digits.length ? "scale-110 bg-white" : "bg-white/25"}`} />)}
        </div>
        <div className="h-5 text-[0.82rem] text-[#ff8a95]">{err}</div>
        <div className="mx-auto mt-2 grid w-[15rem] grid-cols-3 gap-3">
          {["1", "2", "3", "4", "5", "6", "7", "8", "9", "", "0", "⌫"].map((k, i) =>
            k === "" ? <div key={i} /> : (
              <button key={i} onClick={() => (k === "⌫" ? setDigits((d) => d.slice(0, -1)) : press(k))} className="h-[3.2rem] rounded-xl bg-white/10 text-[1.2rem] font-semibold transition-colors hover:bg-white/25 active:bg-white active:text-black">{k}</button>
            )
          )}
        </div>
        <button onClick={() => { sfx.back(); onCancel(); }} className="mt-5 text-[0.88rem] text-white/50 hover:text-white">Cancel</button>
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------ *
 *  generic row list
 * ------------------------------------------------------------------ */
type Row =
  | { t: "toggle"; label: string; desc?: string; value: boolean; onChange: (v: boolean) => void }
  | { t: "slider"; label: string; desc?: string; value: number; min: number; max: number; step: number; fmt?: (v: number) => string; onChange: (v: number) => void }
  | { t: "choice"; label: string; desc?: string; value: string; options: { v: string; l: string }[]; onChange: (v: string) => void }
  | { t: "action"; label: string; desc?: string; value?: string; danger?: boolean; onSelect: () => void; icon?: ReactNode }
  | { t: "text"; label: string; desc?: string; value: string; onCommit: (v: string) => void }
  | { t: "info"; label: string; value: string }
  | { t: "head"; label: string };

const focusable = (r: Row) => r.t !== "info" && r.t !== "head";

function RowList({ rows, active, onBack }: { rows: Row[]; active: boolean; onBack: () => void }) {
  const first = Math.max(0, rows.findIndex(focusable));
  const [f, setF] = useState(first);
  const [editing, setEditing] = useState<number | null>(null);
  const [draft, setDraft] = useState("");
  const [err, setErr] = useState("");
  const inputRef = useRef<HTMLInputElement>(null);
  const skipBlur = useRef(false);
  const listRef = useRef<HTMLDivElement>(null);

  const idx = Math.min(f, rows.length - 1);
  const move = (d: 1 | -1) => {
    let i = idx;
    for (;;) {
      i += d;
      if (i < 0 || i >= rows.length) return;
      if (focusable(rows[i])) { setF(i); sfx.move(); return; }
    }
  };

  useEffect(() => {
    listRef.current?.querySelector<HTMLElement>(`[data-r="${idx}"]`)?.scrollIntoView({ block: "nearest", behavior: "smooth" });
  }, [idx]);
  useEffect(() => { if (editing !== null) inputRef.current?.focus(); }, [editing]);

  const commit = () => {
    const row = rows[editing!];
    if (row?.t !== "text") return;
    const v = draft.trim();
    if (!v) { setErr("Name can't be empty"); sfx.error(); return; }
    skipBlur.current = true;
    row.onCommit(v.slice(0, 16));
    setEditing(null);
    setErr("");
    sfx.select();
  };
  const cancelEdit = () => { skipBlur.current = true; setEditing(null); setErr(""); };

  const act = (i: number, dir: 0 | 1 | -1) => {
    const r = rows[i];
    if (!r) return;
    if (r.t === "toggle" && dir === 0) { r.onChange(!r.value); sfx.toggle(); }
    else if (r.t === "toggle" && dir !== 0) { r.onChange(dir === 1); sfx.toggle(); }
    else if (r.t === "slider" && dir !== 0) { r.onChange(Math.max(r.min, Math.min(r.max, +(r.value + dir * r.step).toFixed(3)))); sfx.move(); }
    else if (r.t === "choice") {
      const k = r.options.findIndex((o) => o.v === r.value);
      const n = dir === 0 ? (k + 1) % r.options.length : Math.max(0, Math.min(r.options.length - 1, k + dir));
      if (n !== k) { r.onChange(r.options[n].v); sfx.move(); }
    } else if (r.t === "action" && dir === 0) { sfx.select(); r.onSelect(); }
    else if (r.t === "text" && dir === 0) { sfx.select(); skipBlur.current = false; setDraft(r.value); setErr(""); setEditing(i); }
  };

  useNav((a) => {
    if (editing !== null) { if (a === "back") cancelEdit(); return; }
    if (a === "up") move(-1);
    else if (a === "down") move(1);
    else if (a === "left") act(idx, -1);
    else if (a === "right") act(idx, 1);
    else if (a === "confirm") act(idx, 0);
    else if (a === "back") { sfx.back(); onBack(); }
  }, active);

  return (
    <div ref={listRef} className="no-scrollbar mx-auto flex h-full w-[58rem] flex-col gap-[0.35rem] overflow-y-auto pb-24 pt-2">
      {rows.map((r, i) => {
        if (r.t === "head") return <div key={i} className="px-2 pb-1 pt-5 text-[0.72rem] font-semibold uppercase tracking-[0.2em] text-white/45">{r.label}</div>;
        const on = i === idx && active;
        const dark = on;
        const sub = dark ? "text-black/55" : "text-white/50";
        return (
          <div
            key={i}
            data-r={i}
            onMouseEnter={() => focusable(r) && setF(i)}
            onClick={() => focusable(r) && r.t !== "slider" && act(i, 0)}
            className={`flex min-h-[3.7rem] shrink-0 items-center justify-between gap-6 rounded-[0.9rem] px-5 py-2 transition-all duration-150 ${r.t === "info" ? "bg-white/[0.04]" : on ? "scale-[1.012] bg-white text-black shadow-xl" : "bg-white/[0.07] hover:bg-white/[0.11]"} ${r.t !== "info" ? "cursor-pointer" : ""}`}
          >
            <div className="min-w-0">
              <div className={`flex items-center gap-3 text-[1.02rem] font-medium ${r.t === "action" && r.danger && !on ? "text-[#ff8a95]" : ""}`}>
                {r.t === "action" && r.icon}
                {r.label}
              </div>
              {"desc" in r && r.desc && <div className={`mt-[0.1rem] text-[0.78rem] ${sub}`}>{r.desc}</div>}
            </div>
            <div className="flex shrink-0 items-center gap-3 text-[0.95rem]">
              {r.t === "info" && <span className="max-w-[28rem] text-right text-white/80">{r.value}</span>}
              {r.t === "toggle" && <Toggle on={r.value} />}
              {r.t === "slider" && (
                <>
                  <input type="range" className="ps-range w-[15rem]" min={r.min} max={r.max} step={r.step} value={r.value} onChange={(e) => r.onChange(parseFloat(e.target.value))} onFocus={(e) => e.currentTarget.blur()} />
                  <span className={`w-[3.2rem] text-right tabular-nums ${sub}`}>{r.fmt ? r.fmt(r.value) : Math.round(r.value * 100) + "%"}</span>
                </>
              )}
              {r.t === "choice" && <span className={`flex items-center gap-3 ${on ? "" : "text-white/80"}`}><span className={on ? "opacity-60" : "opacity-0"}>‹</span>{r.options.find((o) => o.v === r.value)?.l}<span className={on ? "opacity-60" : "opacity-0"}>›</span></span>}
              {r.t === "action" && r.value && <span className={sub}>{r.value}</span>}
              {r.t === "action" && !r.value && !r.danger && <span className={on ? "text-black/40" : "text-white/30"}>›</span>}
              {r.t === "text" && (
                editing === i ? (
                  <div className="flex flex-col items-end">
                    <input
                      ref={inputRef}
                      value={draft}
                      maxLength={16}
                      onChange={(e) => { setDraft(e.target.value); setErr(""); }}
                      onKeyDown={(e) => { if (e.key === "Enter") { e.preventDefault(); commit(); } }}
                      onBlur={() => { if (skipBlur.current) return; if (draft.trim()) { commit(); } else { setEditing(null); setErr(""); } }}
                      className="w-[16rem] rounded-lg bg-black/10 px-3 py-[0.35rem] text-right text-[1rem] text-black outline-none ring-2 ring-[#2e7bff]"
                    />
                    {err && <span className="mt-1 text-[0.72rem] text-[#d92b3f]">{err}</span>}
                  </div>
                ) : (
                  <span className={sub}>{r.value} ✎</span>
                )
              )}
            </div>
          </div>
        );
      })}
    </div>
  );
}

/* ------------------------------------------------------------------ *
 *  grid page (themes + wallpapers)
 * ------------------------------------------------------------------ */
function ThemePreview({ t, big }: { t: Theme; big?: boolean }) {
  return (
    <div className="relative h-full w-full overflow-hidden" style={{ background: `linear-gradient(135deg, ${t.colors[0]}, ${t.colors[1]} 60%, ${t.colors[2]})` }}>
      {t.image && <div className="absolute inset-0 bg-cover bg-center" style={{ backgroundImage: `url("${t.image.replace("h=1080&w=1920", "h=360&w=640")}")`, filter: t.imgFilter }} />}
      <div className="absolute inset-0" style={{ background: t.overlay }} />
      <div className="absolute bottom-2 left-2 flex gap-1">
        {[0, 1, 2].map((i) => (
          <div key={i} className="h-[1.4rem] w-[1.4rem]" style={{ borderRadius: `calc(${t.radius} / 3)`, background: t.icons === "tint" && t.tileBg ? t.tileBg : "rgba(255,255,255,.75)", border: t.icons === "tint" ? `1px solid ${t.tileBorder}` : undefined }} />
        ))}
      </div>
      {big && <div className="absolute right-2 top-2 h-3 w-3 rounded-full" style={{ background: t.accent }} />}
    </div>
  );
}

function ThemesPage({ active, onBack }: { active: boolean; onBack: () => void }) {
  const ctx = useApp();
  const list = useMemo(() => THEME_GROUPS.flatMap((g) => THEMES.filter((t) => t.group === g)), []);
  const [sel, setSel] = useState(() => Math.max(0, list.findIndex((t) => t.id === ctx.profile.theme)));
  const COLS = 4;
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => { ref.current?.querySelector<HTMLElement>(`[data-i="${sel}"]`)?.scrollIntoView({ block: "center", behavior: "smooth" }); }, [sel]);
  const apply = (t: Theme) => { ctx.updateProfile({ theme: t.id }); sfx.select(); ctx.notify(`Theme: ${t.name}`); };
  useNav((a) => {
    if (a === "left" && sel > 0) { setSel(sel - 1); sfx.move(); }
    else if (a === "right" && sel < list.length - 1) { setSel(sel + 1); sfx.move(); }
    else if (a === "up" && sel - COLS >= 0) { setSel(sel - COLS); sfx.move(); }
    else if (a === "down" && sel + COLS < list.length) { setSel(sel + COLS); sfx.move(); }
    else if (a === "confirm") apply(list[sel]);
    else if (a === "back") { sfx.back(); onBack(); }
  }, active);
  const cur = list[sel];
  return (
    <div className="mx-auto flex h-full w-[66rem] gap-8">
      <div ref={ref} className="no-scrollbar grid flex-1 content-start gap-4 overflow-y-auto pb-24 pt-2" style={{ gridTemplateColumns: `repeat(${COLS}, minmax(0,1fr))` }}>
        {list.map((t, i) => {
          const on = i === sel && active;
          const applied = ctx.profile.theme === t.id;
          const showHead = i === 0 || list[i - 1].group !== t.group;
          return (
            <div key={t.id} className="contents">
              {showHead && <div className="col-span-4 -mb-1 mt-2 text-[0.72rem] font-semibold uppercase tracking-[0.2em] text-white/45">{t.group}</div>}
              <button data-i={i} onMouseEnter={() => setSel(i)} onClick={() => apply(t)} className={`relative text-left transition-transform duration-150 ${on ? "scale-[1.05]" : ""}`}>
                <div className="aspect-video overflow-hidden rounded-xl" style={{ boxShadow: on ? "0 0 0 0.18rem #fff, 0 0.8rem 2rem rgba(0,0,0,.5)" : "0 0.3rem 0.8rem rgba(0,0,0,.4)" }}>
                  <ThemePreview t={t} />
                </div>
                {applied && <div className="absolute right-2 top-2 flex h-6 w-6 items-center justify-center rounded-full bg-[#4ade80] text-black"><Check className="h-4 w-4" strokeWidth={3.5} /></div>}
                <div className="mt-2 truncate text-[0.88rem] font-semibold">{t.name}</div>
              </button>
            </div>
          );
        })}
      </div>
      <div className="w-[15rem] shrink-0 pt-2">
        <div className="sticky top-2 rounded-2xl bg-white/[0.07] p-4">
          <div className="aspect-video overflow-hidden rounded-lg"><ThemePreview t={cur} big /></div>
          <div className="mt-3 text-[1.1rem] font-semibold">{cur.name}</div>
          <div className="mt-1 text-[0.78rem] leading-relaxed text-white/60">{cur.desc}</div>
          <div className="mt-3 flex flex-wrap gap-1 text-[0.68rem] text-white/70">
            <span className="rounded bg-white/10 px-2 py-[0.1rem]">{cur.fx}</span>
            <span className="rounded bg-white/10 px-2 py-[0.1rem]">{cur.mood} music</span>
            <span className="rounded bg-white/10 px-2 py-[0.1rem]">{cur.icons === "tint" ? "themed icons" : "brand icons"}</span>
          </div>
        </div>
      </div>
    </div>
  );
}

function WallpapersPage({ active, onBack }: { active: boolean; onBack: () => void }) {
  const ctx = useApp();
  const { wallpapers, profile, restricted, parental } = ctx;
  const blocked = restricted && parental.blockUpload;
  const COLS = 4;
  const total = wallpapers.length + 2; // 0 = theme default, 1 = upload
  const [sel, setSel] = useState(() => (profile.wallpaper ? Math.max(0, wallpapers.findIndex((w) => w.id === profile.wallpaper) + 2) : 0));
  const file = useRef<HTMLInputElement>(null);
  const [confirm, setConfirm] = useState<string | null>(null);

  const upload = () => {
    if (blocked) { sfx.error(); ctx.notify("Uploads are blocked by Parental Controls"); return; }
    file.current?.click();
  };
  const pick = (i: number) => {
    if (i === 0) { ctx.updateProfile({ wallpaper: null }); sfx.select(); ctx.notify("Using theme wallpaper"); }
    else if (i === 1) upload();
    else { ctx.updateProfile({ wallpaper: wallpapers[i - 2].id }); sfx.select(); ctx.notify("Wallpaper applied"); }
  };

  useNav((a) => {
    if (a === "left" && sel > 0) { setSel(sel - 1); sfx.move(); }
    else if (a === "right" && sel < total - 1) { setSel(sel + 1); sfx.move(); }
    else if (a === "up" && sel - COLS >= 0) { setSel(sel - COLS); sfx.move(); }
    else if (a === "down" && sel + COLS < total) { setSel(sel + COLS); sfx.move(); }
    else if (a === "confirm") pick(sel);
    else if (a === "options" && sel >= 2) setConfirm(wallpapers[sel - 2].id);
    else if (a === "back") { sfx.back(); onBack(); }
  }, active && !confirm);

  return (
    <div className="mx-auto h-full w-[62rem] overflow-y-auto pb-24 pt-2 no-scrollbar">
      <p className="mb-4 text-[0.88rem] text-white/60">Upload your own images to use as the Home screen background. They're saved on this device and kept for each user. Press <span className="keycap">Tab</span> on a wallpaper to delete it.</p>
      <input ref={file} type="file" accept="image/*" className="hidden" onChange={async (e) => { const f = e.target.files?.[0]; e.target.value = ""; if (f) await ctx.addWallpaper(f); }} />
      <div className="grid gap-4" style={{ gridTemplateColumns: `repeat(${COLS}, minmax(0,1fr))` }}>
        {[0, 1, ...wallpapers.map((_, i) => i + 2)].map((i) => {
          const on = sel === i && active;
          const w = i >= 2 ? wallpapers[i - 2] : null;
          const applied = i === 0 ? !profile.wallpaper : w ? profile.wallpaper === w.id : false;
          return (
            <button key={i} onMouseEnter={() => setSel(i)} onClick={() => pick(i)} className={`relative aspect-video overflow-hidden rounded-xl text-left transition-transform duration-150 ${on ? "scale-[1.05]" : ""}`} style={{ boxShadow: on ? "0 0 0 0.18rem #fff, 0 0.8rem 2rem rgba(0,0,0,.5)" : "0 0.3rem 0.8rem rgba(0,0,0,.4)" }}>
              {i === 0 && <><ThemePreview t={THEMES.find((t) => t.id === profile.theme) ?? THEMES[0]} /><div className="absolute inset-0 flex items-end bg-gradient-to-t from-black/70 to-transparent p-3 text-[0.85rem] font-semibold">Theme default</div></>}
              {i === 1 && <div className={`flex h-full w-full flex-col items-center justify-center gap-2 border-2 border-dashed ${blocked ? "border-white/15 text-white/30" : "border-white/35 bg-white/[0.06]"}`}><Upload className="h-8 w-8" /><span className="text-[0.88rem] font-semibold">Upload wallpaper</span></div>}
              {w && <><img src={w.data} alt="" className="h-full w-full object-cover" /><div className="absolute inset-x-0 bottom-0 truncate bg-gradient-to-t from-black/80 to-transparent px-3 pb-2 pt-6 text-[0.78rem]">{w.name}</div>
                <span onClick={(e) => { e.stopPropagation(); setConfirm(w.id); }} className="absolute right-2 top-2 flex h-7 w-7 items-center justify-center rounded-full bg-black/65 hover:bg-[#ff5d6c]"><Trash2 className="h-3.5 w-3.5" /></span></>}
              {applied && <div className="absolute left-2 top-2 flex h-6 w-6 items-center justify-center rounded-full bg-[#4ade80] text-black"><Check className="h-4 w-4" strokeWidth={3.5} /></div>}
            </button>
          );
        })}
      </div>
      {confirm && <ConfirmDialog title="Delete wallpaper?" message="This image will be removed from your saved wallpapers." confirmLabel="Delete" danger onCancel={() => setConfirm(null)} onConfirm={() => { ctx.removeWallpaper(confirm); setConfirm(null); setSel(0); }} />}
    </div>
  );
}

/* ------------------------------------------------------------------ *
 *  categories
 * ------------------------------------------------------------------ */
type PageId = "users" | "themes" | "wallpapers" | "sound" | "screen" | "access" | "parental" | "storage" | "network" | "system";
interface Cat { id: PageId | "about" | "guide"; label: string; sub: string; icon: ReactNode; color: string }
const ic = "h-[1.7rem] w-[1.7rem]";
const CATS: Cat[] = [
  { id: "users", label: "Users and Accounts", sub: "Name, avatar, add or remove users", icon: <Users className={ic} />, color: "#3b82f6" },
  { id: "themes", label: "Themes", sub: "PlayStation themes with custom icons", icon: <Palette className={ic} />, color: "#a855f7" },
  { id: "wallpapers", label: "Wallpapers", sub: "Upload and manage backgrounds", icon: <ImageIcon className={ic} />, color: "#ec4899" },
  { id: "sound", label: "Sound", sub: "Volume, effects and ambient music", icon: <Volume2 className={ic} />, color: "#14b8a6" },
  { id: "screen", label: "Screen and Video", sub: "Brightness, HDR and motion", icon: <Monitor className={ic} />, color: "#0ea5e9" },
  { id: "access", label: "Accessibility", sub: "Text size, hints and clock", icon: <Accessibility className={ic} />, color: "#22c55e" },
  { id: "parental", label: "Family and Parental Controls", sub: "PIN, age limits and restrictions", icon: <ShieldCheck className={ic} />, color: "#f59e0b" },
  { id: "storage", label: "Saved Data and Storage", sub: "Manage and erase your data", icon: <HardDrive className={ic} />, color: "#64748b" },
  { id: "network", label: "Network", sub: "Connection status and test", icon: <Wifi className={ic} />, color: "#06b6d4" },
  { id: "system", label: "System", sub: "Restart, clock and reset", icon: <Settings2 className={ic} />, color: "#94a3b8" },
  { id: "about", label: "System Software", sub: "Console information", icon: <Info className={ic} />, color: "#6366f1" },
  { id: "guide", label: "User's Guide", sub: "Learn how everything works", icon: <BookOpen className={ic} />, color: "#10b981" },
];

export default function SettingsApp({ active }: { active: boolean }) {
  const ctx = useApp();
  const { settings, update, profile, profiles, parental, theme } = ctx;
  const [page, setPage] = useState<PageId | null>(null);
  const [cat, setCat] = useState(0);
  const [dialog, setDialog] = useState<null | { kind: "confirm"; title: string; message: string; label: string; run: () => void } | { kind: "editor"; id: string | "new" } | { kind: "pin"; mode: "verify" | "set"; run: (p: string) => void }>(null);
  const [gate, setGate] = useState(false); // parental unlocked this session
  const [netMsg, setNetMsg] = useState("");
  const [storageEst, setStorageEst] = useState<string>("…");
  const [tick, setTick] = useState(0);

  useEffect(() => {
    navigator.storage?.estimate?.().then((e) => setStorageEst(`${((e.usage ?? 0) / 1048576).toFixed(1)} MB of ${((e.quota ?? 0) / 1073741824).toFixed(1)} GB`)).catch(() => setStorageEst("n/a"));
  }, [tick, ctx.wallpapers.length]);

  const confirm = (title: string, message: string, label: string, run: () => void) => setDialog({ kind: "confirm", title, message, label, run });
  const openPage = (id: Cat["id"]) => {
    sfx.select();
    if (id === "about") return ctx.openApp("about");
    if (id === "guide") return ctx.openApp("guide");
    if (id === "parental" && parental.enabled && !gate) {
      setDialog({ kind: "pin", mode: "verify", run: () => { setGate(true); setDialog(null); setPage("parental"); } });
      return;
    }
    setPage(id);
  };

  useNav((a) => {
    const COLS = 2;
    if (a === "left" && cat % COLS === 1) { setCat(cat - 1); sfx.move(); }
    else if (a === "right" && cat % COLS === 0 && cat + 1 < CATS.length) { setCat(cat + 1); sfx.move(); }
    else if (a === "up" && cat - COLS >= 0) { setCat(cat - COLS); sfx.move(); }
    else if (a === "down" && cat + COLS < CATS.length) { setCat(cat + COLS); sfx.move(); }
    else if (a === "confirm") openPage(CATS[cat].id);
    else if (a === "back") { sfx.back(); ctx.goHome(); }
  }, active && page === null && !dialog);

  const modalOpen = !!dialog;
  const back = () => setPage(null);

  /* ---------------- pages ---------------- */
  const pageRows = (): Row[] => {
    switch (page) {
      case "users": {
        const others = profiles.filter((p) => p.id !== profile.id);
        return [
          { t: "head", label: "Current user" },
          { t: "text", label: "Name", desc: "Press Enter to rename. You can clear the field while typing.", value: profile.name, onCommit: (v) => { ctx.updateProfile({ name: v }); ctx.notify("Name updated"); } },
          { t: "action", label: "Change Avatar", desc: "Pick from 36 high-quality avatars", icon: <AvatarIcon id={profile.avatar} size="2rem" ring={false} />, onSelect: () => setDialog({ kind: "editor", id: profile.id }) },
          { t: "toggle", label: "Child account", desc: "Parental controls apply to this user when enabled", value: profile.child, onChange: (v) => {
            if (parental.enabled && !v) setDialog({ kind: "pin", mode: "verify", run: () => { ctx.updateProfile({ child: false }); setDialog(null); } });
            else ctx.updateProfile({ child: v });
          } },
          { t: "head", label: "Manage users" },
          ...(profiles.length < MAX_PROFILES ? [{ t: "action", label: "Add User", icon: <Plus className="h-5 w-5" />, onSelect: () => setDialog({ kind: "editor", id: "new" }) } as Row] : []),
          { t: "action", label: "Switch User", icon: <UserRound className="h-5 w-5" />, onSelect: () => ctx.switchUser() },
          ...others.map((p): Row => ({ t: "action", label: `Delete ${p.name}`, danger: true, icon: <Trash2 className="h-5 w-5" />, onSelect: () => confirm(`Delete ${p.name}?`, "This user's settings, themes and app data will be removed permanently.", "Delete", () => { ctx.deleteProfile(p.id); setDialog(null); }) })),
        ];
      }
      case "sound":
        return [
          { t: "head", label: "Effects" },
          { t: "toggle", label: "Sound Effects", desc: "Menu navigation and notification sounds", value: settings.sfx, onChange: (v) => update({ sfx: v }) },
          { t: "slider", label: "Master Volume", value: settings.volume, min: 0, max: 1, step: 0.05, onChange: (v) => update({ volume: v }) },
          { t: "toggle", label: "Game Launch Sound", desc: "Play the start-up sound when you enter a game", value: settings.gameSound, onChange: (v) => update({ gameSound: v }) },
          { t: "head", label: "Home Screen Music" },
          { t: "toggle", label: "Ambient Music", desc: `Generative music that changes with your theme (${theme.mood})`, value: settings.music, onChange: (v) => update({ music: v }) },
          { t: "slider", label: "Music Volume", value: settings.musicVolume, min: 0, max: 1, step: 0.05, onChange: (v) => update({ musicVolume: v }) },
          { t: "action", label: "Test Sound", onSelect: () => sfx.test() },
        ];
      case "screen":
        return [
          { t: "slider", label: "Brightness", value: settings.brightness, min: 0.5, max: 1.25, step: 0.05, fmt: (v) => Math.round(((v - 0.5) / 0.75) * 100) + "%", onChange: (v) => update({ brightness: v }) },
          { t: "toggle", label: "HDR", desc: "Boost contrast and color saturation", value: settings.hdr, onChange: (v) => update({ hdr: v }) },
          { t: "toggle", label: "Motion Effects", desc: "Animated wallpapers and particles", value: settings.motion, onChange: (v) => update({ motion: v }) },
          { t: "action", label: ctx.fullscreen ? "Exit Fullscreen" : "Enter Fullscreen", icon: <Maximize className="h-5 w-5" />, onSelect: () => ctx.toggleFullscreen() },
          { t: "head", label: "Video output" },
          { t: "info", label: "Resolution", value: `${window.innerWidth} × ${window.innerHeight}` },
          { t: "info", label: "Pixel density", value: `${window.devicePixelRatio.toFixed(2)}x` },
        ];
      case "access":
        return [
          { t: "toggle", label: "Larger Text & Interface", desc: "Scale the whole interface up by 12%", value: settings.largeText, onChange: (v) => update({ largeText: v }) },
          { t: "toggle", label: "Button Hints", desc: "Show control hints at the bottom of the screen", value: settings.hints, onChange: (v) => update({ hints: v }) },
          { t: "toggle", label: "Motion Effects", desc: "Turn off to reduce movement", value: settings.motion, onChange: (v) => update({ motion: v }) },
          { t: "toggle", label: "Notifications", desc: "Pop-up banners for downloads and messages", value: settings.notifications, onChange: (v) => update({ notifications: v }) },
          { t: "choice", label: "Clock", value: settings.clock24 ? "24" : "12", options: [{ v: "12", l: "12-hour" }, { v: "24", l: "24-hour" }], onChange: (v) => update({ clock24: v === "24" }) },
        ];
      case "parental":
        return [
          { t: "toggle", label: "Parental Controls", desc: "Restrict child accounts. Mark users as child accounts in Users and Accounts.", value: parental.enabled, onChange: (v) => { ctx.setParental({ enabled: v }); if (v && parental.pin === "0000") ctx.notify("Default PIN is 0000 — change it below"); } },
          { t: "action", label: "Change PIN", desc: "A 4-digit PIN protects these settings", value: "••••", onSelect: () => setDialog({ kind: "pin", mode: "set", run: (p) => { ctx.setParental({ pin: p }); setDialog(null); ctx.notify("PIN updated"); } }) },
          { t: "choice", label: "Age Rating Limit", desc: "Games and apps above this rating are hidden and locked", value: String(parental.maxAge), options: AGE_OPTIONS.map((n) => ({ v: String(n), l: ageLabel(n) })), onChange: (v) => ctx.setParental({ maxAge: parseInt(v) }) },
          { t: "head", label: "Restrictions for child accounts" },
          { t: "toggle", label: "Block Web Browser", value: parental.blockBrowser, onChange: (v) => ctx.setParental({ blockBrowser: v }) },
          { t: "toggle", label: "Block PlayStation Store", value: parental.blockStore, onChange: (v) => ctx.setParental({ blockStore: v }) },
          { t: "toggle", label: "Block Streaming Apps", desc: "Spotify, YouTube, Disney+ and others", value: parental.blockStreaming, onChange: (v) => ctx.setParental({ blockStreaming: v }) },
          { t: "toggle", label: "Block Uploads", desc: "No custom games or wallpapers", value: parental.blockUpload, onChange: (v) => ctx.setParental({ blockUpload: v }) },
          { t: "head", label: "Status" },
          { t: "info", label: "Child accounts", value: profiles.filter((p) => p.child).map((p) => p.name).join(", ") || "None" },
        ];
      case "storage": {
        const bytes = localStorageBytes();
        return [
          { t: "head", label: "Usage" },
          { t: "info", label: "Browser storage in use", value: storageEst },
          { t: "info", label: "Settings & app data", value: `${(bytes / 1024).toFixed(1)} KB` },
          { t: "info", label: "Games installed", value: `${ctx.games.length}` },
          { t: "info", label: "Uploaded wallpapers", value: `${ctx.wallpapers.length}` },
          { t: "head", label: "Erase" },
          { t: "action", label: "Delete All Games", desc: "Removes every game from your library", danger: true, icon: <Trash2 className="h-5 w-5" />, onSelect: () => confirm("Delete all games?", "All games, including those downloaded from the Store, will be removed from your library.", "Delete All", () => { ctx.deleteAllGames(); setDialog(null); setTick((t) => t + 1); }) },
          { t: "action", label: "Delete Uploaded Wallpapers", danger: true, icon: <Trash2 className="h-5 w-5" />, onSelect: () => confirm("Delete wallpapers?", "All uploaded wallpapers will be removed.", "Delete", () => { ctx.wallpapers.forEach((w) => ctx.removeWallpaper(w.id)); setDialog(null); }) },
          { t: "action", label: "Clear Browser Data", desc: "History, bookmarks and search engine", danger: true, icon: <Trash2 className="h-5 w-5" />, onSelect: () => confirm("Clear browser data?", "Bookmarks and history for all users will be erased.", "Clear", () => { eraseKeys((k) => /\.(bookmarks|history|engine)$/.test(k)); setDialog(null); ctx.notify("Browser data cleared — restart the browser to apply"); }) },
          { t: "action", label: "Sign Out of All Apps", desc: "Spotify, Disney+, Netflix and other sign-ins, plus favorites", danger: true, icon: <Trash2 className="h-5 w-5" />, onSelect: () => confirm("Sign out of all apps?", "Streaming sign-ins, saved playlists and favorites will be removed.", "Sign Out", () => { eraseKeys((k) => /\.p\.[^.]+\.(auth|spotify|yt)\./.test(k)); setDialog(null); ctx.notify("Signed out — reopen apps to apply"); }) },
          { t: "action", label: "Reset Play History", desc: "Last played and play time", danger: true, icon: <Trash2 className="h-5 w-5" />, onSelect: () => confirm("Reset play history?", "Play time and last played info will be cleared.", "Reset", () => { eraseKeys((k) => k === "ps5.meta"); setDialog(null); ctx.restart(); }) },
          { t: "action", label: "Erase Everything", desc: "Users, settings, games, wallpapers and all saved data", danger: true, icon: <Trash2 className="h-5 w-5" />, onSelect: () => confirm("Erase everything?", "This resets the simulator to a factory state. All users, games, wallpapers and saved data will be permanently erased.", "Erase", () => ctx.eraseAll()) },
        ];
      }
      case "network": {
        const c = (navigator as unknown as { connection?: { effectiveType?: string; downlink?: number; rtt?: number; type?: string } }).connection;
        return [
          { t: "info", label: "Status", value: navigator.onLine ? "Connected to the Internet" : "Not connected" },
          { t: "info", label: "Connection type", value: c?.type ? c.type : "Wi-Fi / Ethernet" },
          { t: "info", label: "Effective speed class", value: c?.effectiveType?.toUpperCase() ?? "Unknown" },
          { t: "info", label: "Estimated downlink", value: c?.downlink ? `${c.downlink} Mbps` : "Unknown" },
          { t: "info", label: "Round-trip time", value: c?.rtt ? `${c.rtt} ms` : "Unknown" },
          { t: "action", label: "Test Internet Connection", desc: netMsg || "Measure latency to the PlayStation network", onSelect: async () => {
            setNetMsg("Testing…");
            const t0 = performance.now();
            try {
              await fetch("https://www.gstatic.com/generate_204", { mode: "no-cors", cache: "no-store" });
              setNetMsg(`Success — ${Math.round(performance.now() - t0)} ms`);
            } catch { setNetMsg("Failed — no response"); }
          } },
        ];
      }
      case "system":
        return [
          { t: "action", label: "System Software", desc: "View console information", onSelect: () => ctx.openApp("about") },
          { t: "action", label: "User's Guide", desc: "Learn how everything works", onSelect: () => ctx.openApp("guide") },
          { t: "choice", label: "Clock", value: settings.clock24 ? "24" : "12", options: [{ v: "12", l: "12-hour" }, { v: "24", l: "24-hour" }], onChange: (v) => update({ clock24: v === "24" }) },
          { t: "toggle", label: "Notifications", value: settings.notifications, onChange: (v) => update({ notifications: v }) },
          { t: "action", label: ctx.fullscreen ? "Exit Fullscreen" : "Enter Fullscreen", onSelect: () => ctx.toggleFullscreen() },
          { t: "head", label: "Power" },
          { t: "action", label: "Restart", desc: "Replay the start-up sequence", onSelect: () => ctx.restart() },
          { t: "action", label: "Switch User", onSelect: () => ctx.switchUser() },
        ];
      default:
        return [];
    }
  };

  const cur = CATS.find((c) => c.id === page);
  const rows = page && page !== "themes" && page !== "wallpapers" ? pageRows() : [];

  return (
    <div className="absolute inset-0 flex flex-col bg-black/65 text-white backdrop-blur-2xl">
      <div className="absolute inset-0 bg-gradient-to-b from-black/40 via-transparent to-black/50" />
      {/* header */}
      <div className="relative z-10 flex items-center justify-between px-[4rem] pb-3 pt-[1.8rem]">
        <div className="flex items-center gap-4">
          {page && <button onClick={() => { sfx.back(); back(); }} className="flex h-10 w-10 items-center justify-center rounded-full bg-white/10 hover:bg-white/20"><ArrowLeft className="h-5 w-5" /></button>}
          <div className="flex h-[2.6rem] w-[2.6rem] items-center justify-center rounded-full" style={{ background: cur ? cur.color : "rgba(255,255,255,.15)" }}>{cur ? cur.icon : <Settings2 className={ic} />}</div>
          <div>
            <h1 className="text-[1.7rem] font-semibold leading-tight">{cur ? cur.label : "Settings"}</h1>
            {cur && <div className="text-[0.82rem] text-white/50">{cur.sub}</div>}
          </div>
        </div>
        <div className="flex items-center gap-4">
          <span className="text-[0.9rem] text-white/70">{profile.name}</span>
          <AvatarIcon id={profile.avatar} size="2.5rem" />
        </div>
      </div>

      <div className="relative z-10 min-h-0 flex-1 px-[4rem]">
        {page === null && (
          <div className="mx-auto grid h-full max-w-[66rem] grid-cols-2 content-start gap-x-6 gap-y-[0.7rem] overflow-y-auto pb-24 pt-3 no-scrollbar">
            {CATS.map((c, i) => {
              const on = cat === i;
              return (
                <button key={c.id} onMouseEnter={() => setCat(i)} onClick={() => openPage(c.id)} className={`anim-rise flex items-center gap-5 rounded-[1.1rem] px-5 py-[0.9rem] text-left transition-all duration-150 ${on ? "scale-[1.02] bg-white text-black shadow-2xl" : "bg-white/[0.07] hover:bg-white/[0.11]"}`} style={{ animationDelay: `${i * 0.025}s` }}>
                  <div className="flex h-[3.4rem] w-[3.4rem] shrink-0 items-center justify-center rounded-full text-white shadow-lg" style={{ background: `linear-gradient(135deg, ${c.color}, ${c.color}aa)` }}>{c.icon}</div>
                  <div className="min-w-0">
                    <div className="truncate text-[1.1rem] font-semibold">{c.label}</div>
                    <div className={`truncate text-[0.82rem] ${on ? "text-black/55" : "text-white/50"}`}>{c.sub}</div>
                  </div>
                </button>
              );
            })}
          </div>
        )}
        {page === "themes" && <ThemesPage active={active && !modalOpen} onBack={back} />}
        {page === "wallpapers" && <WallpapersPage active={active && !modalOpen} onBack={back} />}
        {page && page !== "themes" && page !== "wallpapers" && <RowList key={page} rows={rows} active={active && !modalOpen} onBack={back} />}
      </div>

      <HintBar show={settings.hints && !modalOpen}>
        <Hint k="↑↓←→" >Navigate</Hint>
        <Hint k="Enter" glyph="cross">Select</Hint>
        <Hint k="Esc" glyph="circle">{page ? "Back" : "Home"}</Hint>
      </HintBar>

      {dialog?.kind === "confirm" && <ConfirmDialog title={dialog.title} message={dialog.message} confirmLabel={dialog.label} danger onCancel={() => setDialog(null)} onConfirm={dialog.run} />}
      {dialog?.kind === "pin" && <PinDialog mode={dialog.mode} pin={parental.pin} title={dialog.mode === "verify" ? "Enter your PIN" : "Set a new PIN"} message={dialog.mode === "verify" ? "Enter the 4-digit Parental Controls PIN." : "Choose a 4-digit PIN."} onCancel={() => setDialog(null)} onDone={(p) => dialog.run(p)} />}
      {dialog?.kind === "editor" && (
        <UserEditor
          title={dialog.id === "new" ? "Add User" : "Edit User"}
          initial={dialog.id === "new" ? undefined : profiles.find((p) => p.id === dialog.id)}
          hints={settings.hints}
          onCancel={() => setDialog(null)}
          onSave={(v) => {
            if (dialog.id === "new") ctx.addProfile(v as Partial<Profile>);
            else ctx.updateProfile(v, dialog.id);
            setDialog(null);
          }}
        />
      )}
    </div>
  );
}
