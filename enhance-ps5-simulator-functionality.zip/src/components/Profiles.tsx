import { useEffect, useRef, useState } from "react";
import { Check, Plus, UserRound, Baby, Pencil, Trash2 } from "lucide-react";
import type { Profile } from "../types";
import { AVATARS, AvatarIcon } from "../lib/avatars";
import { useNav } from "../lib/useNav";
import { sfx } from "../lib/sfx";
import { ConfirmDialog, Hint, HintBar, OptionsPanel, PSLogo, Toggle } from "./ui";

export const MAX_PROFILES = 8;

/** Create / edit a user. Uses a local draft so clearing the name never snaps back. */
export function UserEditor({
  initial,
  title,
  hints,
  onSave,
  onCancel,
}: {
  initial?: Profile;
  title: string;
  hints: boolean;
  onSave: (v: { name: string; avatar: string; child: boolean }) => void;
  onCancel: () => void;
}) {
  const [name, setName] = useState(initial?.name ?? "");
  const [avatar, setAvatar] = useState(initial?.avatar ?? AVATARS[Math.floor(Math.random() * AVATARS.length)].id);
  const [child, setChild] = useState(initial?.child ?? false);
  const [sec, setSec] = useState(0); // 0 name · 1 avatars · 2 child · 3 buttons
  const [btn, setBtn] = useState(1);
  const [err, setErr] = useState(false);
  const input = useRef<HTMLInputElement>(null);
  const COLS = 9;

  useEffect(() => {
    if (sec === 0) input.current?.focus();
    else input.current?.blur();
  }, [sec]);

  const save = () => {
    const n = name.trim();
    if (!n) {
      setErr(true);
      sfx.error();
      setSec(0);
      window.setTimeout(() => setErr(false), 500);
      return;
    }
    sfx.select();
    onSave({ name: n.slice(0, 16), avatar, child });
  };

  useNav(
    (a) => {
      if (a === "back") {
        sfx.back();
        onCancel();
        return;
      }
      if (sec === 0) {
        if (a === "down") setSec(1);
        return;
      }
      if (sec === 1) {
        const i = AVATARS.findIndex((x) => x.id === avatar);
        const go = (n: number) => {
          if (n >= 0 && n < AVATARS.length) {
            setAvatar(AVATARS[n].id);
            sfx.move();
          }
        };
        if (a === "left") go(i - 1);
        else if (a === "right") go(i + 1);
        else if (a === "up") (i - COLS < 0 ? setSec(0) : go(i - COLS));
        else if (a === "down") (i + COLS >= AVATARS.length ? setSec(2) : go(i + COLS));
        return;
      }
      if (sec === 2) {
        if (a === "up") setSec(1);
        else if (a === "down") setSec(3);
        else if (a === "confirm") {
          setChild((c) => !c);
          sfx.toggle();
        }
        return;
      }
      if (a === "up") setSec(2);
      else if (a === "left") setBtn(0);
      else if (a === "right") setBtn(1);
      else if (a === "confirm") (btn === 1 ? save() : onCancel());
    },
    true,
    true
  );

  return (
    <div className="anim-fade-in absolute inset-0 z-[90] flex items-center justify-center bg-black/75 backdrop-blur-xl">
      <div className="anim-pop flex w-[52rem] flex-col rounded-[1.6rem] bg-[#15181f]/95 p-[2.2rem] shadow-2xl ring-1 ring-white/10">
        <div className="flex items-center gap-5">
          <AvatarIcon id={avatar} size="5.2rem" />
          <div className="flex-1">
            <h3 className="text-[1.5rem] font-semibold">{title}</h3>
            <p className="text-[0.85rem] text-white/55">Choose a name and an avatar for this user.</p>
          </div>
        </div>

        <label className="mt-6 text-[0.72rem] font-semibold uppercase tracking-[0.18em] text-white/50">Online ID / Name</label>
        <input
          ref={input}
          value={name}
          maxLength={16}
          placeholder="Enter a name"
          onChange={(e) => setName(e.target.value)}
          onFocus={() => setSec(0)}
          onKeyDown={(e) => {
            if (e.key === "ArrowDown") {
              e.preventDefault();
              setSec(1);
            } else if (e.key === "Enter") {
              e.preventDefault();
              setSec(1);
            }
          }}
          className={`mt-2 rounded-xl bg-white/10 px-4 py-[0.8rem] text-[1.1rem] outline-none transition-all ${sec === 0 ? "ring-2 ring-white" : "ring-1 ring-white/10"} ${err ? "anim-shake ring-2 !ring-[#ff5d6c]" : ""}`}
        />
        {err && <div className="mt-1 text-[0.8rem] text-[#ff8a95]">Please enter a name.</div>}

        <label className="mt-5 text-[0.72rem] font-semibold uppercase tracking-[0.18em] text-white/50">Avatar</label>
        <div className={`no-scrollbar mt-2 grid gap-[0.7rem] rounded-2xl p-3 ${sec === 1 ? "bg-white/[0.06] ring-1 ring-white/30" : "bg-white/[0.03]"}`} style={{ gridTemplateColumns: `repeat(${COLS}, minmax(0,1fr))`, maxHeight: "14.5rem", overflowY: "auto" }}>
          {AVATARS.map((a) => (
            <button
              key={a.id}
              ref={(el) => {
                if (el && a.id === avatar && sec === 1) el.scrollIntoView({ block: "nearest" });
              }}
              title={a.name}
              onClick={() => {
                setAvatar(a.id);
                setSec(1);
                sfx.move();
              }}
              className={`relative mx-auto rounded-full transition-transform duration-150 ${a.id === avatar ? "scale-110" : "opacity-80 hover:scale-105 hover:opacity-100"}`}
            >
              <AvatarIcon id={a.id} size="3.3rem" ring={false} />
              {a.id === avatar && <span className="absolute -inset-[0.2rem] rounded-full ring-[0.2rem] ring-white" />}
              {a.id === avatar && (
                <span className="absolute -bottom-1 -right-1 flex h-[1.2rem] w-[1.2rem] items-center justify-center rounded-full bg-white text-black">
                  <Check className="h-3 w-3" strokeWidth={3.5} />
                </span>
              )}
            </button>
          ))}
        </div>

        <button
          onClick={() => {
            setChild((c) => !c);
            setSec(2);
            sfx.toggle();
          }}
          className={`mt-4 flex items-center justify-between rounded-xl px-4 py-[0.75rem] text-left transition-all ${sec === 2 ? "bg-white text-black" : "bg-white/[0.06]"}`}
        >
          <span className="flex items-center gap-3">
            <Baby className="h-[1.3rem] w-[1.3rem]" />
            <span>
              <span className="block text-[0.98rem] font-semibold">Child account</span>
              <span className={`block text-[0.78rem] ${sec === 2 ? "text-black/60" : "text-white/50"}`}>Applies parental controls (age limits, blocked apps) when enabled in Settings</span>
            </span>
          </span>
          <Toggle on={child} />
        </button>

        <div className="mt-6 flex justify-end gap-3">
          {["Cancel", initial ? "Save" : "Create"].map((l, i) => (
            <button
              key={l}
              onMouseEnter={() => {
                setSec(3);
                setBtn(i);
              }}
              onClick={() => (i === 1 ? save() : onCancel())}
              className={`min-w-[9rem] rounded-full px-6 py-[0.65rem] text-[0.95rem] font-semibold transition-all ${sec === 3 && btn === i ? "scale-105 bg-white text-black" : i === 1 ? "bg-[#2e7bff] text-white" : "bg-white/12 text-white/80"}`}
            >
              {l}
            </button>
          ))}
        </div>
      </div>
      <HintBar show={hints}>
        <Hint k="↑↓←→" >Navigate</Hint>
        <Hint k="Esc" glyph="circle">Cancel</Hint>
      </HintBar>
    </div>
  );
}

/** "Who's using this console?" */
export default function ProfileSelect({
  profiles,
  lastId,
  hints,
  onPick,
  onCreate,
  onEdit,
  onDelete,
}: {
  profiles: Profile[];
  lastId: string | null;
  hints: boolean;
  onPick: (p: Profile) => void;
  onCreate: (v: { name: string; avatar: string; child: boolean }) => void;
  onEdit: (id: string, v: { name: string; avatar: string; child: boolean }) => void;
  onDelete: (p: Profile) => void;
}) {
  const [sel, setSel] = useState(() => Math.max(0, profiles.findIndex((p) => p.id === lastId)));
  const [editor, setEditor] = useState<null | "new" | Profile>(null);
  const [opts, setOpts] = useState(false);
  const [confirm, setConfirm] = useState<Profile | null>(null);
  const [leaving, setLeaving] = useState<string | null>(null);
  const total = profiles.length + (profiles.length < MAX_PROFILES ? 1 : 0);
  const cur = Math.min(sel, total - 1);

  const pick = (p: Profile) => {
    if (leaving) return;
    sfx.open();
    setLeaving(p.id);
    window.setTimeout(() => onPick(p), 650);
  };

  useNav(
    (a) => {
      if (leaving) return;
      if (a === "left" && cur > 0) {
        setSel(cur - 1);
        sfx.move();
      } else if (a === "right" && cur < total - 1) {
        setSel(cur + 1);
        sfx.move();
      } else if (a === "confirm") {
        if (cur >= profiles.length) {
          sfx.select();
          setEditor("new");
        } else pick(profiles[cur]);
      } else if (a === "options" && cur < profiles.length) {
        sfx.select();
        setOpts(true);
      }
    },
    !editor && !opts && !confirm
  );

  return (
    <div className="absolute inset-0 z-20 flex flex-col items-center justify-center" style={{ animation: leaving ? "fade-out 0.6s ease 0.1s forwards" : "fade-in 0.8s ease both" }}>
      <div className="absolute inset-0 bg-black/45" />
      <div className="relative flex flex-col items-center">
        <PSLogo className="h-[2.4rem] w-[2.4rem] opacity-90" />
        <h1 className="anim-rise mt-5 text-[2.2rem] font-semibold tracking-tight">Who's Playing?</h1>
        <p className="anim-rise mt-1 text-[0.95rem] text-white/60" style={{ animationDelay: "0.08s" }}>Select a user to continue</p>

        <div className="mt-[3.2rem] flex items-start justify-center gap-[2.6rem]">
          {profiles.map((p, i) => {
            const on = cur === i;
            return (
              <button
                key={p.id}
                onMouseEnter={() => setSel(i)}
                onClick={() => pick(p)}
                className="anim-rise group flex w-[8.5rem] flex-col items-center"
                style={{ animationDelay: `${0.1 + i * 0.06}s` }}
              >
                <div className={`relative transition-transform duration-200 ${on ? "scale-[1.18]" : "scale-100 opacity-75"} ${leaving === p.id ? "!scale-[1.5]" : ""}`}>
                  <AvatarIcon id={p.avatar} size="7.6rem" ring={false} />
                  {on && <span className="focus-ring absolute -inset-[0.35rem] rounded-full" />}
                  {p.child && (
                    <span className="absolute -right-1 bottom-1 flex h-[1.9rem] w-[1.9rem] items-center justify-center rounded-full bg-[#ffd23f] text-black shadow">
                      <Baby className="h-[1.1rem] w-[1.1rem]" />
                    </span>
                  )}
                </div>
                <span className={`mt-5 max-w-full truncate text-[1.05rem] transition-all ${on ? "font-semibold text-white" : "text-white/60"}`}>{p.name}</span>
              </button>
            );
          })}
          {profiles.length < MAX_PROFILES && (
            <button
              onMouseEnter={() => setSel(profiles.length)}
              onClick={() => {
                sfx.select();
                setEditor("new");
              }}
              className="anim-rise flex w-[8.5rem] flex-col items-center"
              style={{ animationDelay: `${0.1 + profiles.length * 0.06}s` }}
            >
              <div className={`relative transition-transform duration-200 ${cur === profiles.length ? "scale-[1.18]" : "opacity-75"}`}>
                <div className="flex h-[7.6rem] w-[7.6rem] items-center justify-center rounded-full bg-white/10 ring-1 ring-white/25 backdrop-blur-md">
                  <Plus className="h-[3rem] w-[3rem]" strokeWidth={1.4} />
                </div>
                {cur === profiles.length && <span className="focus-ring absolute -inset-[0.35rem] rounded-full" />}
              </div>
              <span className={`mt-5 text-[1.05rem] ${cur === profiles.length ? "font-semibold" : "text-white/60"}`}>Add User</span>
            </button>
          )}
        </div>
      </div>

      <HintBar show={hints}>
        <Hint k="Enter" glyph="cross">Select</Hint>
        <Hint k="Tab" glyph="square">Manage User</Hint>
      </HintBar>

      {editor && (
        <UserEditor
          title={editor === "new" ? "Add User" : "Edit User"}
          initial={editor === "new" ? undefined : editor}
          hints={hints}
          onCancel={() => setEditor(null)}
          onSave={(v) => {
            if (editor === "new") {
              onCreate(v);
              setSel(profiles.length);
            } else onEdit(editor.id, v);
            setEditor(null);
          }}
        />
      )}
      {opts && profiles[cur] && (
        <OptionsPanel
          title={profiles[cur].name}
          onClose={() => setOpts(false)}
          items={[
            { label: "Select", icon: <UserRound className="h-full w-full" />, onSelect: () => { setOpts(false); pick(profiles[cur]); } },
            { label: "Edit User", icon: <Pencil className="h-full w-full" />, onSelect: () => { setOpts(false); setEditor(profiles[cur]); } },
            ...(profiles.length > 1 ? [{ label: "Delete User", danger: true, icon: <Trash2 className="h-full w-full" />, onSelect: () => { setOpts(false); setConfirm(profiles[cur]); } }] : []),
          ]}
        />
      )}
      {confirm && (
        <ConfirmDialog
          title={`Delete ${confirm.name}?`}
          message="This user's saved settings, themes, streaming sign-ins and favorites will be permanently removed."
          confirmLabel="Delete"
          danger
          onCancel={() => setConfirm(null)}
          onConfirm={() => {
            onDelete(confirm);
            setConfirm(null);
            setSel(0);
          }}
        />
      )}
    </div>
  );
}
