import { useEffect, useLayoutEffect, useMemo, useRef, useState, type CSSProperties, type ReactNode } from "react";
import { Play, Plus, Settings as Gear, Trash2, X, ShoppingBag, UserRound, LogOut, Gamepad2, ArrowDownToLine } from "lucide-react";
import type { Game } from "../types";
import { APPS, getApp, type AppDef } from "../lib/apps";
import { useApp } from "../lib/ctx";
import { useNav } from "../lib/useNav";
import { sfx } from "../lib/sfx";
import { hash } from "../lib/art";
import { appAllowed, fmtAgo, fmtTime, gameAllowed } from "../lib/rules";
import { AvatarIcon } from "../lib/avatars";
import { ConfirmDialog, Hint, HintBar, OptionsPanel } from "./ui";

interface Tile {
  key: string;
  kind: "game" | "app" | "action";
  title: string;
  subtitle: string;
  game?: Game;
  app?: AppDef;
  action?: "store" | "custom";
  running: boolean;
}

function CrossFade({ src, className = "" }: { src: string | null; className?: string }) {
  const [layers, setLayers] = useState<{ cur: string | null; prev: string | null }>({ cur: src, prev: null });
  useEffect(() => {
    setLayers((l) => (l.cur === src ? l : { cur: src, prev: l.cur }));
    const t = window.setTimeout(() => setLayers((l) => ({ ...l, prev: null })), 700);
    return () => clearTimeout(t);
  }, [src]);
  return (
    <>
      {layers.prev && <img src={layers.prev} alt="" className={className} draggable={false} />}
      {layers.cur && <img key={layers.cur} src={layers.cur} alt="" draggable={false} className={`${className} anim-fade-in`} style={{ animationDuration: "0.6s" }} />}
    </>
  );
}

export default function Home({ active, intro, returnKey, onInstall }: { active: boolean; intro: boolean; returnKey: number; onInstall: () => void }) {
  const ctx = useApp();
  const { games, theme, settings, profile, parental, restricted, running, installed } = ctx;
  const [zone, setZone] = useState<"top" | "tiles">("tiles");
  const [tab, setTab] = useState<"games" | "media">("games");
  const [topIdx, setTopIdx] = useState(0);
  const [idx, setIdx] = useState({ games: 0, media: 0 });
  const [options, setOptions] = useState(false);
  const [profMenu, setProfMenu] = useState(false);
  const [confirm, setConfirm] = useState<Game | AppDef | null>(null);
  const [clock, setClock] = useState(() => new Date());

  useEffect(() => {
    const t = window.setInterval(() => setClock(new Date()), 10000);
    return () => clearInterval(t);
  }, []);

  const isRunning = (kind: "app" | "game", id: string) => running.some((r) => r.kind === kind && r.id === id);

  const tiles: Tile[] = useMemo(() => {
    if (tab === "media") {
      const list = [...APPS.filter((a) => a.builtin), ...installed.map((id) => getApp(id)).filter((a): a is AppDef => !!a)].filter((a) => appAllowed(a, restricted, parental));
      const t: Tile[] = list.map((a) => ({ key: "app-" + a.id, kind: "app", title: a.name, subtitle: `${a.category} · App`, app: a, running: isRunning("app", a.id) }));
      if (appAllowed(getApp("store")!, restricted, parental)) t.push({ key: "more-apps", kind: "action", action: "store", title: "Get More Apps", subtitle: "Streaming & entertainment", running: false });
      return t;
    }
    const sorted = games
      .filter((g) => gameAllowed(g, restricted, parental))
      .sort((a, b) => (b.lastPlayed ?? 0) - (a.lastPlayed ?? 0) || b.addedAt - a.addedAt);
    const gt: Tile[] = sorted.map((g) => ({ key: g.id, kind: "game", title: g.title, subtitle: g.lastPlayed ? `Game · ${g.genre ?? "PS5"}` : "Game · New", game: g, running: isRunning("game", g.id) }));
    if (appAllowed(getApp("store")!, restricted, parental)) gt.push({ key: "more-games", kind: "action", action: "store", title: "Get More Games", subtitle: "Browse the PlayStation Store", running: false });
    if (!(restricted && parental.blockUpload)) gt.push({ key: "custom", kind: "action", action: "custom", title: "Add Your Own Game", subtitle: "Install an HTML game file", running: false });
    return gt;
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [tab, games, installed, restricted, parental, running]);

  const cur = Math.max(0, Math.min(idx[tab], tiles.length - 1));
  const tile = tiles[cur];

  useEffect(() => {
    setIdx((i) => (i[tab] > tiles.length - 1 ? { ...i, [tab]: Math.max(0, tiles.length - 1) } : i));
  }, [tiles.length, tab]);

  const refs = useRef<(HTMLDivElement | null)[]>([]);
  const [shift, setShift] = useState(0);
  useLayoutEffect(() => {
    const el = refs.current[cur];
    if (!el) return;
    const rem = parseFloat(getComputedStyle(document.documentElement).fontSize);
    setShift(el.offsetLeft - rem * 4);
  }, [cur, tab, tiles.length]);

  const go = (t?: Tile) => {
    if (!t) return;
    sfx.select();
    if (t.kind === "game" && t.game) ctx.launchGame(t.game);
    else if (t.kind === "app" && t.app) ctx.openApp(t.app.id);
    else if (t.action === "store") ctx.openApp("store");
    else if (t.action === "custom") onInstall();
  };
  const setCur = (i: number) => setIdx((s) => ({ ...s, [tab]: i }));
  const setTabN = (n: number) => setTab(n === 0 ? "games" : "media");

  const TOP = 4; // games, media, settings, profile
  useNav(
    (a) => {
      if (zone === "tiles") {
        if (a === "left" && cur > 0) { setCur(cur - 1); sfx.move(); }
        else if (a === "right" && cur < tiles.length - 1) { setCur(cur + 1); sfx.move(); }
        else if (a === "up") { setZone("top"); setTopIdx(tab === "games" ? 0 : 1); sfx.move(); }
        else if (a === "confirm") go(tile);
        else if (a === "options" && tile && tile.kind !== "action") { sfx.select(); setOptions(true); }
      } else {
        if (a === "left" && topIdx > 0) { const n = topIdx - 1; setTopIdx(n); if (n < 2) setTabN(n); sfx.move(); }
        else if (a === "right" && topIdx < TOP - 1) { const n = topIdx + 1; setTopIdx(n); if (n < 2) setTabN(n); sfx.move(); }
        else if (a === "down") { setZone("tiles"); sfx.move(); }
        else if (a === "confirm") {
          sfx.select();
          if (topIdx < 2) setZone("tiles");
          else if (topIdx === 2) ctx.openApp("settings");
          else setProfMenu(true);
        }
      }
    },
    active && !options && !confirm && !profMenu
  );

  const trophy = tile?.game ? hash(tile.game.id) % 100 : 0;
  const upper = theme.upper ? "uppercase tracking-wide" : "";
  const bgUrl = tile?.game?.background ?? null;

  /* ---- tile visuals ---- */
  const appStyle = (a: AppDef): CSSProperties =>
    theme.icons === "tint" && theme.tileBg
      ? { background: theme.tileBg, color: theme.tileFg, border: `1px solid ${theme.tileBorder}` }
      : { background: a.bg, color: a.fg, border: "1px solid rgba(255,255,255,.12)" };
  const actionStyle: CSSProperties = { background: "linear-gradient(135deg,rgba(255,255,255,.14),rgba(255,255,255,.05))", border: "1px dashed rgba(255,255,255,.35)" };

  const optionItems =
    !tile || tile.kind === "action"
      ? []
      : [
          { label: tile.running ? "Resume" : tile.kind === "game" ? "Play" : "Open", icon: <Play className="h-full w-full" />, onSelect: () => { setOptions(false); go(tile); } },
          ...(tile.running ? [{ label: tile.kind === "game" ? "Close Game" : "Close App", icon: <X className="h-full w-full" />, onSelect: () => { setOptions(false); ctx.closeRunning({ kind: tile.kind as "app" | "game", id: tile.game?.id ?? tile.app!.id }); } }] : []),
          ...(tile.kind === "game" && tile.game && !(restricted && parental.blockUpload && !tile.game.builtin)
            ? [{ label: "Delete", danger: true, icon: <Trash2 className="h-full w-full" />, onSelect: () => { setOptions(false); setConfirm(tile.game!); } }]
            : []),
          ...(tile.kind === "app" && tile.app && !tile.app.builtin
            ? [{ label: "Delete", danger: true, icon: <Trash2 className="h-full w-full" />, onSelect: () => { setOptions(false); setConfirm(tile.app!); } }]
            : []),
        ];

  const time = clock.toLocaleTimeString([], { hour: "numeric", minute: "2-digit", hour12: !settings.clock24 });
  const topTabs = ["Games", "Media"];

  return (
    <div key={returnKey} className={`absolute inset-0 overflow-hidden ${intro ? "anim-home-intro" : "anim-home-return"}`}>
      {/* key art */}
      <div className="absolute inset-0">
        <div className="absolute inset-0" style={{ opacity: bgUrl ? 0.92 : 0, transition: "opacity .6s" }}>
          <CrossFade src={bgUrl} className="absolute inset-0 h-full w-full object-cover" />
        </div>
        {tile?.app && (
          <div key={tile.key} className="anim-fade-in absolute inset-0" style={{ animationDuration: "0.6s" }}>
            <div className="absolute inset-0 opacity-35" style={{ background: theme.icons === "tint" ? theme.tileBg : tile.app.bg, filter: "blur(30px)" }} />
            <div className="absolute -right-[4rem] top-[3rem] opacity-[0.07]" style={{ color: "#fff" }}>
              <tile.app.Icon className="h-[40rem] w-[40rem]" />
            </div>
          </div>
        )}
        <div className="absolute inset-0 bg-gradient-to-r from-black/70 via-black/20 to-black/5" />
        <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-black/10 to-black/55" />
      </div>

      {/* top bar */}
      <div className="absolute left-0 right-0 top-0 z-10 flex items-center justify-between px-[4rem] pt-[1.6rem]">
        <div className="flex items-center gap-[2.2rem]">
          {topTabs.map((label, i) => {
            const on = tab === (i === 0 ? "games" : "media");
            const focus = zone === "top" && topIdx === i;
            return (
              <button
                key={label}
                onClick={() => { setTabN(i); setTopIdx(i); setZone("tiles"); sfx.move(); }}
                className={`relative pb-[0.45rem] text-[1.25rem] transition-all duration-200 ${upper} ${on ? "font-semibold text-white" : "font-medium text-white/50"} ${focus ? "scale-110" : ""}`}
              >
                {label}
                <span className={`absolute -bottom-[0.05rem] left-0 h-[0.18rem] rounded-full transition-all duration-300 ${on ? "w-full opacity-100" : "w-0 opacity-0"}`} style={{ background: theme.accent }} />
                {focus && <span className="focus-ring absolute -inset-x-[0.9rem] -inset-y-[0.2rem] rounded-full" />}
              </button>
            );
          })}
        </div>
        <div className="flex items-center gap-[1.5rem]">
          {running.length > 0 && (
            <button onClick={() => ctx.openControlCenter()} className="glass flex items-center gap-2 rounded-full px-4 py-[0.35rem] text-[0.82rem] font-semibold text-white/90">
              <span className="h-2 w-2 animate-pulse rounded-full" style={{ background: theme.accent }} />
              {running.length} running
            </button>
          )}
          <button
            onClick={() => { ctx.openApp("settings"); }}
            className={`relative flex h-[2.4rem] w-[2.4rem] items-center justify-center rounded-full transition-all ${zone === "top" && topIdx === 2 ? "scale-110 bg-white/20" : "bg-white/0"}`}
          >
            <Gear className="h-[1.5rem] w-[1.5rem]" strokeWidth={1.7} />
            {zone === "top" && topIdx === 2 && <span className="focus-ring absolute -inset-[0.2rem] rounded-full" />}
          </button>
          <button onClick={() => setProfMenu(true)} className={`relative flex items-center gap-3 rounded-full transition-all ${zone === "top" && topIdx === 3 ? "scale-110" : ""}`}>
            <AvatarIcon id={profile.avatar} size="2.5rem" />
            {zone === "top" && topIdx === 3 && <span className="focus-ring absolute -inset-[0.2rem] rounded-full" />}
          </button>
          <div className="text-[1.15rem] font-medium tabular-nums">{time}</div>
        </div>
      </div>

      {/* tile row */}
      <div className="absolute left-0 right-0 top-[8rem] z-10 h-[15rem]">
        <div className="absolute left-0 flex items-end gap-[1.1rem] transition-transform duration-[450ms] ease-[cubic-bezier(.2,.8,.2,1)]" style={{ transform: `translateX(${-shift}px)`, bottom: 0 }}>
          {tiles.map((t, i) => {
            const on = i === cur;
            const focusLook = on && zone === "tiles";
            return (
              <div
                key={t.key}
                ref={(el) => { refs.current[i] = el; }}
                onClick={() => (on ? go(t) : (setCur(i), setZone("tiles"), sfx.move()))}
                className={`relative shrink-0 cursor-pointer transition-all duration-300 ${on ? "h-[13.2rem] w-[13.2rem]" : "h-[9.4rem] w-[9.4rem] opacity-90"} ${on && theme.bounce ? "anim-bob" : ""}`}
              >
                <div
                  className={`relative h-full w-full overflow-hidden ${theme.grain ? "grain" : ""}`}
                  style={{
                    borderRadius: theme.radius,
                    boxShadow: focusLook ? `0 0 0 0.2rem #fff, 0 1.2rem 3rem rgba(0,0,0,.65), 0 0 2.6rem ${theme.accent}66` : "0 0.6rem 1.4rem rgba(0,0,0,.5)",
                    ...(t.kind === "app" && t.app ? appStyle(t.app) : t.kind === "action" ? actionStyle : {}),
                  }}
                >
                  {t.kind === "game" && t.game && <img src={t.game.cover} alt="" draggable={false} className="h-full w-full object-cover" />}
                  {t.kind === "app" && t.app && (
                    <div className="flex h-full w-full items-center justify-center">
                      <t.app.Icon className="h-[52%] w-[52%]" />
                    </div>
                  )}
                  {t.kind === "action" && (
                    <div className="flex h-full w-full flex-col items-center justify-center gap-2 text-white/85">
                      {t.action === "store" ? <ShoppingBag className="h-[36%] w-[36%]" strokeWidth={1.3} /> : <Plus className="h-[40%] w-[40%]" strokeWidth={1.2} />}
                    </div>
                  )}
                  {focusLook && <div className="pointer-events-none absolute inset-0 overflow-hidden"><div className="absolute inset-y-0 w-1/3 bg-gradient-to-r from-transparent via-white/25 to-transparent" style={{ animation: "sheen 1.1s ease 0.1s 1 both" }} /></div>}
                </div>
                {t.running && (
                  <span className="absolute -right-[0.4rem] -top-[0.5rem] flex items-center gap-1 rounded-full px-[0.55rem] py-[0.18rem] text-[0.62rem] font-bold uppercase tracking-wider text-black shadow-lg" style={{ background: theme.accent }}>
                    <span className="h-[0.4rem] w-[0.4rem] animate-pulse rounded-full bg-black" /> Running
                  </span>
                )}
              </div>
            );
          })}
        </div>
      </div>

      {/* info */}
      {tile && (
        <div key={tile.key} className="anim-rise absolute left-[4rem] top-[24.2rem] z-10 w-[40rem]" style={{ animationDuration: "0.45s" }}>
          {tile.game && tile.game.logo && !tile.game.url && tile.kind === "game" ? (
            <img src={tile.game.logo} alt={tile.title} className="mb-3 max-h-[5.5rem] max-w-[24rem] object-contain object-left drop-shadow-[0_0.3rem_1rem_rgba(0,0,0,.7)]" />
          ) : (
            <h2 className={`mb-1 truncate text-[2.1rem] font-semibold drop-shadow-lg ${upper}`}>{tile.title}</h2>
          )}
          {tile.game?.logo && !tile.game.url && <h2 className="sr-only">{tile.title}</h2>}
          <div className="mb-3 text-[0.9rem] font-medium text-white/65">{tile.subtitle}</div>
          <div className="flex items-center gap-4">
            <button
              onClick={() => go(tile)}
              className="flex items-center gap-2 rounded-full bg-white px-[1.7rem] py-[0.62rem] text-[1.02rem] font-bold text-black shadow-[0_0.5rem_1.6rem_rgba(0,0,0,.4)] transition-transform hover:scale-105"
            >
              {tile.kind === "action" ? (tile.action === "store" ? <ShoppingBag className="h-[1.1rem] w-[1.1rem]" /> : <ArrowDownToLine className="h-[1.1rem] w-[1.1rem]" />) : <Play className="h-[1.1rem] w-[1.1rem] fill-black" />}
              {tile.kind === "action" ? (tile.action === "store" ? "Open Store" : "Install") : tile.running ? "Resume" : tile.kind === "game" ? "Play" : "Open"}
            </button>
            {tile.kind !== "action" && (
              <button onClick={() => setOptions(true)} className="glass flex h-[2.6rem] w-[2.6rem] items-center justify-center rounded-full text-[1.3rem] leading-none text-white/90">
                ···
              </button>
            )}
          </div>
          <div className="mt-5 max-w-[34rem] text-[0.92rem] leading-relaxed text-white/75">
            {tile.game ? (
              <div className="flex flex-wrap items-center gap-x-6 gap-y-2">
                <span className="inline-flex items-center gap-2"><Gamepad2 className="h-4 w-4" />Last played: {fmtAgo(tile.game.lastPlayed)}</span>
                <span>Play time: {fmtTime(tile.game.playtime)}</span>
                <span>Trophies: {trophy}%</span>
                {tile.game.rating !== undefined && <span className="rounded border border-white/40 px-[0.4rem] text-[0.75rem] font-bold">{tile.game.rating > 0 ? `${tile.game.rating}+` : "E"}</span>}
              </div>
            ) : tile.app ? (
              <p>{tile.app.desc}</p>
            ) : (
              <p>{tile.action === "store" ? "Download free games and streaming apps like Spotify, YouTube and Disney+." : "Bring your own HTML game file with custom artwork and play it on this console."}</p>
            )}
            {tile.game?.desc && <p className="mt-3 text-white/60">{tile.game.desc}</p>}
          </div>
        </div>
      )}

      {tile && <div className="pointer-events-none absolute bottom-[1.2rem] left-[4rem] z-10 text-[0.78rem] text-white/45">{tab === "games" ? `${games.filter((g) => gameAllowed(g, restricted, parental)).length} games` : `${tiles.length - 1} apps`}</div>}

      <HintBar show={settings.hints && active}>
        <Hint k="Enter" glyph="cross">Select</Hint>
        <Hint k="Tab" glyph="triangle">Options</Hint>
        <Hint k="F1" glyph="circle">PS Button</Hint>
      </HintBar>

      {options && <OptionsPanel title={tile?.title ?? ""} items={optionItems} onClose={() => setOptions(false)} />}
      {profMenu && (
        <OptionsPanel
          title={profile.name}
          onClose={() => setProfMenu(false)}
          items={[
            { label: "Switch User", icon: <UserRound className="h-full w-full" />, onSelect: () => { setProfMenu(false); ctx.switchUser(); } },
            { label: "Settings", icon: <Gear className="h-full w-full" />, onSelect: () => { setProfMenu(false); ctx.openApp("settings"); } },
            { label: "Restart", icon: <LogOut className="h-full w-full" />, onSelect: () => { setProfMenu(false); ctx.restart(); } },
          ]}
        />
      )}
      {confirm && (
        <ConfirmDialog
          title={`Delete ${"title" in confirm ? confirm.title : confirm.name}?`}
          message={"title" in confirm ? "This game will be removed from your library. You can re-download store games from the PlayStation Store." : "This app will be removed from your Home screen. You can re-download it from the PlayStation Store."}
          confirmLabel="Delete"
          danger
          onCancel={() => setConfirm(null)}
          onConfirm={() => {
            if ("title" in confirm) ctx.deleteGame(confirm);
            else ctx.uninstall(confirm.id);
            setConfirm(null);
          }}
        />
      )}
    </div>
  );
}

export type { ReactNode };
