import { useEffect, useMemo, useRef, useState, type FormEvent } from "react";
import { ArrowLeft, ArrowRight, BookmarkCheck, BookmarkPlus, Clock, ExternalLink, Globe, History, Home, Lock, MoreVertical, Plus, RotateCw, Search, Star, Trash2, X } from "lucide-react";
import { useApp } from "../lib/ctx";
import { pget, pset } from "../lib/store";
import { getApp } from "../lib/apps";
import { sfx } from "../lib/sfx";
import { openWindow } from "../lib/popup";

interface Tab {
  id: number;
  hist: string[];
  idx: number;
  nonce: number;
}
interface Bookmark { title: string; url: string }
interface HistItem { url: string; at: number }

const NEWTAB = "about:newtab";
const ENGINES: Record<string, { name: string; url: string }> = {
  google: { name: "Google", url: "https://www.google.com/search?igu=1&q=%s" },
  wikipedia: { name: "Wikipedia", url: "https://en.wikipedia.org/wiki/Special:Search?search=%s" },
  archive: { name: "Internet Archive", url: "https://archive.org/search?query=%s" },
  wiby: { name: "Wiby", url: "https://wiby.me/?q=%s" },
};

/** Sites that forbid being shown inside a frame (X-Frame-Options / frame-ancestors). */
const BLOCKED = [
  "youtube.com", "youtu.be", "spotify.com", "netflix.com", "disneyplus.com", "twitch.tv", "facebook.com", "instagram.com", "twitter.com", "x.com",
  "github.com", "reddit.com", "linkedin.com", "amazon.com", "bing.com", "duckduckgo.com", "stackoverflow.com", "playstation.com", "bbc.com", "bbc.co.uk",
  "nytimes.com", "wikihow.com", "tiktok.com", "discord.com", "paypal.com", "accounts.google.com", "mail.google.com", "drive.google.com", "docs.google.com",
  "chess.com", "lichess.org", "pinterest.com", "whatsapp.com", "roblox.com", "ebay.com", "walmart.com", "nasa.gov", "primevideo.com", "hulu.com", "max.com",
  "apple.com", "microsoft.com", "live.com", "office.com", "zoom.us", "tumblr.com", "quora.com", "medium.com", "cnn.com", "foxnews.com", "reuters.com",
];
const APP_FOR_HOST: Record<string, string> = { "youtube.com": "youtube", "youtu.be": "youtube", "spotify.com": "spotify", "netflix.com": "netflix", "disneyplus.com": "disney", "twitch.tv": "twitch", "primevideo.com": "prime", "hulu.com": "hulu", "max.com": "max" };

const SHORTCUTS: { name: string; url: string; color: string }[] = [
  { name: "Wikipedia", url: "https://en.wikipedia.org/", color: "#ffffff" },
  { name: "Internet Archive", url: "https://archive.org/", color: "#e8e8e8" },
  { name: "Project Gutenberg", url: "https://www.gutenberg.org/", color: "#f3e5ab" },
  { name: "IGN", url: "https://www.ign.com/", color: "#ff3b3b" },
  { name: "Metacritic", url: "https://www.metacritic.com/", color: "#ffcc34" },
  { name: "Weather", url: "https://weather.com/", color: "#4aa3ff" },
  { name: "Hextris", url: "https://hextris.io/", color: "#5ad" },
  { name: "OpenStreetMap", url: "https://www.openstreetmap.org/export/embed.html", color: "#7ebc6f" },
  { name: "IMDb", url: "https://www.imdb.com/", color: "#f5c518" },
  { name: "Wiby", url: "https://wiby.me/", color: "#c8c8ff" },
];

const hostOf = (u: string) => {
  try {
    return new URL(u).hostname.replace(/^www\./, "");
  } catch {
    return "";
  }
};
const isBlocked = (u: string) => {
  const h = hostOf(u);
  return BLOCKED.some((b) => h === b || h.endsWith("." + b));
};
const favicon = (u: string) => `https://www.google.com/s2/favicons?domain=${hostOf(u)}&sz=64`;
const titleOf = (u: string) => (u === NEWTAB ? "New Tab" : u === "about:history" ? "History" : u === "about:bookmarks" ? "Bookmarks" : hostOf(u) || u);

export default function Browser({ active }: { active: boolean }) {
  const ctx = useApp();
  const pid = ctx.profile.id;
  const [tabs, setTabs] = useState<Tab[]>([{ id: 1, hist: [NEWTAB], idx: 0, nonce: 0 }]);
  const [cur, setCur] = useState(1);
  const [bookmarks, setBookmarks] = useState<Bookmark[]>(() => pget(pid, "bookmarks", [] as Bookmark[]));
  const [history, setHistory] = useState<HistItem[]>(() => pget(pid, "history", [] as HistItem[]));
  const [engine, setEngine] = useState<string>(() => pget(pid, "engine", "google"));
  const [menu, setMenu] = useState(false);
  const [text, setText] = useState("");
  const [focus, setFocus] = useState(false);
  const [loading, setLoading] = useState(false);
  const idc = useRef(2);
  const input = useRef<HTMLInputElement>(null);

  const tab = tabs.find((t) => t.id === cur) ?? tabs[0];
  const url = tab.hist[tab.idx];

  useEffect(() => { pset(pid, "bookmarks", bookmarks); }, [bookmarks, pid]);
  useEffect(() => { pset(pid, "history", history.slice(0, 300)); }, [history, pid]);
  useEffect(() => { pset(pid, "engine", engine); }, [engine, pid]);
  useEffect(() => { if (!focus) setText(url.startsWith("about:") ? "" : url); }, [url, focus, cur]);
  useEffect(() => {
    if (active && url === NEWTAB) {
      const t = window.setTimeout(() => input.current?.focus(), 400);
      return () => clearTimeout(t);
    }
  }, [active, cur, url]);

  const patch = (id: number, f: (t: Tab) => Tab) => setTabs((ts) => ts.map((t) => (t.id === id ? f(t) : t)));

  const normalize = (raw: string): string => {
    const q = raw.trim();
    if (!q) return NEWTAB;
    if (q.startsWith("about:")) return q;
    if (/^[a-z][a-z0-9+.-]*:\/\//i.test(q)) return q;
    if (!/\s/.test(q) && (/^localhost(:\d+)?(\/|$)/.test(q) || /^[^\s/]+\.[a-z]{2,}(:\d+)?([/?#].*)?$/i.test(q))) return "https://" + q;
    return ENGINES[engine].url.replace("%s", encodeURIComponent(q));
  };

  const go = (raw: string, newTab = false) => {
    const u = normalize(raw);
    sfx.move();
    setLoading(!u.startsWith("about:") && !isBlocked(u));
    if (!u.startsWith("about:")) setHistory((h) => [{ url: u, at: Date.now() }, ...h.filter((x) => x.url !== u)].slice(0, 300));
    if (newTab) {
      const id = idc.current++;
      setTabs((ts) => [...ts, { id, hist: [u], idx: 0, nonce: 0 }]);
      setCur(id);
    } else patch(tab.id, (t) => ({ ...t, hist: [...t.hist.slice(0, t.idx + 1), u], idx: t.idx + 1 }));
    setFocus(false);
    input.current?.blur();
  };

  const newTab = () => {
    const id = idc.current++;
    setTabs((ts) => [...ts, { id, hist: [NEWTAB], idx: 0, nonce: 0 }]);
    setCur(id);
    sfx.move();
  };
  const closeTab = (id: number) => {
    if (tabs.length === 1) { setTabs([{ id: idc.current++, hist: [NEWTAB], idx: 0, nonce: 0 }]); setCur(idc.current - 1); return; }
    const i = tabs.findIndex((t) => t.id === id);
    const rest = tabs.filter((t) => t.id !== id);
    setTabs(rest);
    if (id === cur) setCur(rest[Math.max(0, i - 1)].id);
  };

  const submit = (e: FormEvent) => {
    e.preventDefault();
    go(text);
  };
  const popup = (u: string) => {
    if (!openWindow(u)) ctx.notify("Pop-up blocked — allow pop-ups for this site");
  };

  const bookmarked = bookmarks.some((b) => b.url === url);
  const toggleBookmark = () => {
    if (url.startsWith("about:")) return;
    setBookmarks((bs) => (bookmarked ? bs.filter((b) => b.url !== url) : [...bs, { title: titleOf(url), url }]));
    ctx.notify(bookmarked ? "Bookmark removed" : "Bookmark added");
  };

  const blocked = !url.startsWith("about:") && isBlocked(url);
  const blockedApp = useMemo(() => {
    const h = hostOf(url);
    const k = Object.keys(APP_FOR_HOST).find((b) => h === b || h.endsWith("." + b));
    return k ? getApp(APP_FOR_HOST[k]) : undefined;
  }, [url]);

  const btn = "flex h-[2.1rem] w-[2.1rem] items-center justify-center rounded-full text-white/80 transition-colors hover:bg-white/10 disabled:opacity-30 disabled:hover:bg-transparent";

  return (
    <div className="absolute inset-0 flex flex-col bg-[#202124] text-[#e8eaed]" style={{ userSelect: "none" }}>
      {/* tab strip */}
      <div className="flex h-[2.6rem] shrink-0 items-end gap-[0.15rem] bg-[#202124] px-[0.8rem] pt-[0.4rem]">
        {tabs.map((t) => {
          const u = t.hist[t.idx];
          const on = t.id === cur;
          return (
            <div key={t.id} onClick={() => setCur(t.id)} className={`group relative flex h-[2.2rem] w-[13rem] cursor-default items-center gap-2 rounded-t-[0.7rem] px-3 text-[0.8rem] ${on ? "bg-[#35363a]" : "hover:bg-white/[0.07]"}`}>
              {u.startsWith("about:") ? <Globe className="h-4 w-4 shrink-0 text-white/60" /> : <img src={favicon(u)} alt="" className="h-4 w-4 shrink-0 rounded-sm" />}
              <span className="flex-1 truncate">{titleOf(u)}</span>
              <button onClick={(e) => { e.stopPropagation(); closeTab(t.id); }} className="flex h-5 w-5 items-center justify-center rounded-full hover:bg-white/15"><X className="h-3 w-3" /></button>
            </div>
          );
        })}
        <button onClick={newTab} className="mb-[0.15rem] ml-1 flex h-[1.9rem] w-[1.9rem] items-center justify-center rounded-full hover:bg-white/10"><Plus className="h-4 w-4" /></button>
        <div className="flex-1" />
        <button onClick={() => ctx.goHome()} className="mb-[0.2rem] mr-1 flex items-center gap-2 rounded-full bg-white/10 px-4 py-[0.28rem] text-[0.78rem] font-semibold hover:bg-white/20">
          <Home className="h-4 w-4" /> Home
        </button>
      </div>

      {/* toolbar */}
      <div className="flex h-[3.2rem] shrink-0 items-center gap-1 bg-[#35363a] px-[0.8rem]">
        <button className={btn} disabled={tab.idx === 0} onClick={() => patch(tab.id, (t) => ({ ...t, idx: t.idx - 1 }))} title="Back"><ArrowLeft className="h-[1.1rem] w-[1.1rem]" /></button>
        <button className={btn} disabled={tab.idx >= tab.hist.length - 1} onClick={() => patch(tab.id, (t) => ({ ...t, idx: t.idx + 1 }))} title="Forward"><ArrowRight className="h-[1.1rem] w-[1.1rem]" /></button>
        <button className={btn} onClick={() => { setLoading(true); patch(tab.id, (t) => ({ ...t, nonce: t.nonce + 1 })); }} title="Reload"><RotateCw className="h-4 w-4" /></button>
        <button className={btn} onClick={() => go(NEWTAB)} title="New tab page"><Home className="h-4 w-4" /></button>
        <form onSubmit={submit} className="mx-2 flex h-[2.2rem] flex-1 items-center gap-2 rounded-full bg-[#202124] px-4 ring-1 ring-transparent focus-within:ring-[#8ab4f8]">
          {url.startsWith("about:") ? <Search className="h-4 w-4 text-white/50" /> : <Lock className="h-[0.9rem] w-[0.9rem] text-white/60" />}
          <input
            ref={input}
            value={text}
            onChange={(e) => setText(e.target.value)}
            onFocus={(e) => { setFocus(true); e.currentTarget.select(); }}
            onBlur={() => setFocus(false)}
            placeholder="Search or type a URL"
            spellCheck={false}
            className="flex-1 bg-transparent text-[0.9rem] outline-none placeholder:text-white/40"
          />
          <button type="button" onClick={toggleBookmark} title="Bookmark this page" className="text-white/70 hover:text-[#8ab4f8]">
            {bookmarked ? <BookmarkCheck className="h-[1.1rem] w-[1.1rem] text-[#8ab4f8]" /> : <BookmarkPlus className="h-[1.1rem] w-[1.1rem]" />}
          </button>
        </form>
        <button className={btn} onClick={() => !url.startsWith("about:") && popup(url)} disabled={url.startsWith("about:")} title="Open in a new window"><ExternalLink className="h-4 w-4" /></button>
        <div className="relative">
          <button className={btn} onClick={() => setMenu((m) => !m)}><MoreVertical className="h-[1.1rem] w-[1.1rem]" /></button>
          {menu && (
            <div className="absolute right-0 top-[2.6rem] z-50 w-[17rem] rounded-xl bg-[#292a2d] p-2 text-[0.85rem] shadow-2xl ring-1 ring-white/10" onMouseLeave={() => setMenu(false)}>
              {[
                { l: "New tab", i: <Plus className="h-4 w-4" />, f: () => newTab() },
                { l: "History", i: <History className="h-4 w-4" />, f: () => go("about:history") },
                { l: "Bookmarks", i: <Star className="h-4 w-4" />, f: () => go("about:bookmarks") },
                { l: "Clear browsing data", i: <Trash2 className="h-4 w-4" />, f: () => { setHistory([]); ctx.notify("Browsing history cleared"); } },
              ].map((m) => (
                <button key={m.l} onClick={() => { m.f(); setMenu(false); }} className="flex w-full items-center gap-3 rounded-lg px-3 py-2 text-left hover:bg-white/10">{m.i}{m.l}</button>
              ))}
              <div className="my-1 h-px bg-white/10" />
              <div className="px-3 py-1 text-[0.7rem] uppercase tracking-wider text-white/45">Search engine</div>
              {Object.entries(ENGINES).map(([k, e]) => (
                <button key={k} onClick={() => { setEngine(k); setMenu(false); }} className="flex w-full items-center justify-between rounded-lg px-3 py-2 text-left hover:bg-white/10">
                  {e.name}{engine === k && <span className="text-[#8ab4f8]">●</span>}
                </button>
              ))}
            </div>
          )}
        </div>
      </div>
      {loading && !blocked && !url.startsWith("about:") && <div className="stripes h-[0.15rem] shrink-0 bg-[#8ab4f8]" />}

      {/* bookmarks bar */}
      {bookmarks.length > 0 && (
        <div className="no-scrollbar flex h-[2.1rem] shrink-0 items-center gap-1 overflow-x-auto bg-[#35363a] px-3 pb-1">
          {bookmarks.map((b) => (
            <button key={b.url} onClick={() => go(b.url)} onContextMenu={(e) => { e.preventDefault(); setBookmarks((bs) => bs.filter((x) => x.url !== b.url)); }} title="Right-click to remove" className="flex max-w-[11rem] items-center gap-2 rounded-full px-3 py-[0.2rem] text-[0.78rem] hover:bg-white/10">
              <img src={favicon(b.url)} alt="" className="h-4 w-4" /><span className="truncate">{b.title}</span>
            </button>
          ))}
        </div>
      )}

      {/* page */}
      <div className="relative flex-1 bg-white">
        {tabs.map((t) => {
          const u = t.hist[t.idx];
          const show = t.id === cur;
          if (u.startsWith("about:") || isBlocked(u)) return null;
          return (
            <iframe
              key={t.id + ":" + t.nonce}
              src={u}
              title={u}
              onLoad={() => show && setLoading(false)}
              sandbox="allow-scripts allow-same-origin allow-forms allow-popups allow-popups-to-escape-sandbox allow-presentation allow-downloads allow-modals"
              allow="autoplay; fullscreen; clipboard-write; geolocation; microphone; camera; encrypted-media"
              className="absolute inset-0 h-full w-full border-0 bg-white"
              style={{ visibility: show && active ? "visible" : "hidden", pointerEvents: show && active ? "auto" : "none" }}
            />
          );
        })}

        {url === NEWTAB && (
          <div className="absolute inset-0 flex flex-col items-center overflow-y-auto bg-[#202124] pt-[7vh] text-white">
            <div className="select-none text-[5rem] font-semibold tracking-tight" style={{ background: "linear-gradient(90deg,#8ab4f8,#c58af9,#f28b82,#fdd663,#81c995)", WebkitBackgroundClip: "text", color: "transparent" }}>Web</div>
            <form onSubmit={(e) => { e.preventDefault(); go((e.currentTarget.elements.namedItem("q") as HTMLInputElement).value); }} className="mt-4 flex h-[3.2rem] w-[38rem] items-center gap-3 rounded-full bg-[#303134] px-5 ring-1 ring-white/10 focus-within:ring-[#8ab4f8]">
              <Search className="h-5 w-5 text-white/50" />
              <input name="q" autoComplete="off" placeholder={`Search ${ENGINES[engine].name} or type a URL`} className="flex-1 bg-transparent text-[1.05rem] outline-none placeholder:text-white/40" />
            </form>
            <div className="mt-10 grid grid-cols-5 gap-x-8 gap-y-6">
              {SHORTCUTS.map((s) => (
                <button key={s.url} onClick={() => go(s.url)} className="group flex w-[7.5rem] flex-col items-center gap-2">
                  <div className="flex h-[4.2rem] w-[4.2rem] items-center justify-center rounded-full bg-[#303134] transition-colors group-hover:bg-[#3c4043]">
                    <img src={favicon(s.url)} alt="" className="h-8 w-8 rounded-md" />
                  </div>
                  <span className="max-w-full truncate text-[0.8rem] text-white/80">{s.name}</span>
                </button>
              ))}
            </div>
            {history.length > 0 && (
              <div className="mt-10 w-[44rem]">
                <div className="mb-2 flex items-center gap-2 text-[0.75rem] uppercase tracking-wider text-white/45"><Clock className="h-3.5 w-3.5" /> Recently visited</div>
                <div className="flex flex-wrap gap-2">
                  {history.slice(0, 6).map((h) => (
                    <button key={h.url} onClick={() => go(h.url)} className="flex max-w-[14rem] items-center gap-2 rounded-full bg-[#303134] px-4 py-[0.4rem] text-[0.8rem] hover:bg-[#3c4043]">
                      <img src={favicon(h.url)} alt="" className="h-4 w-4" /><span className="truncate">{titleOf(h.url)}</span>
                    </button>
                  ))}
                </div>
              </div>
            )}
            <p className="mt-10 max-w-[34rem] pb-10 text-center text-[0.75rem] leading-relaxed text-white/35">Some sites don't allow being shown inside other pages. When that happens, use <span className="text-white/60">Open in a new window</span> in the toolbar to launch the page in a full browser window.</p>
          </div>
        )}

        {url === "about:history" && (
          <div className="absolute inset-0 overflow-y-auto bg-[#202124] px-[8vw] py-8">
            <div className="mb-4 flex items-center justify-between"><h2 className="text-[1.5rem] font-medium">History</h2><button onClick={() => setHistory([])} className="rounded-full bg-white/10 px-4 py-2 text-[0.82rem] hover:bg-white/20">Clear all</button></div>
            {history.length === 0 && <p className="text-white/50">Your browsing history is empty.</p>}
            {history.map((h) => (
              <button key={h.url} onClick={() => go(h.url)} className="flex w-full items-center gap-4 rounded-lg px-3 py-2 text-left hover:bg-white/[0.06]">
                <span className="w-[5rem] text-[0.78rem] text-white/45">{new Date(h.at).toLocaleTimeString([], { hour: "numeric", minute: "2-digit" })}</span>
                <img src={favicon(h.url)} alt="" className="h-4 w-4" /><span className="w-[12rem] truncate text-[0.88rem]">{titleOf(h.url)}</span><span className="truncate text-[0.78rem] text-white/40">{h.url}</span>
              </button>
            ))}
          </div>
        )}

        {url === "about:bookmarks" && (
          <div className="absolute inset-0 overflow-y-auto bg-[#202124] px-[8vw] py-8">
            <h2 className="mb-4 text-[1.5rem] font-medium">Bookmarks</h2>
            {bookmarks.length === 0 && <p className="text-white/50">No bookmarks yet. Click the bookmark icon in the address bar to add one.</p>}
            {bookmarks.map((b) => (
              <div key={b.url} className="flex items-center gap-4 rounded-lg px-3 py-2 hover:bg-white/[0.06]">
                <button onClick={() => go(b.url)} className="flex flex-1 items-center gap-4 text-left"><img src={favicon(b.url)} alt="" className="h-4 w-4" /><span className="w-[12rem] truncate text-[0.88rem]">{b.title}</span><span className="truncate text-[0.78rem] text-white/40">{b.url}</span></button>
                <button onClick={() => setBookmarks((bs) => bs.filter((x) => x.url !== b.url))} className="rounded-full p-2 hover:bg-white/10"><Trash2 className="h-4 w-4" /></button>
              </div>
            ))}
          </div>
        )}

        {blocked && (
          <div className="absolute inset-0 flex flex-col items-center justify-center bg-[#202124] px-10 text-center">
            <div className="text-[5rem] leading-none text-white/25">☹</div>
            <h2 className="mt-4 text-[1.5rem] font-medium">{hostOf(url)} refused to connect.</h2>
            <p className="mt-2 max-w-[34rem] text-[0.92rem] leading-relaxed text-white/55">This website doesn't allow itself to be displayed inside another page. You can open it in a full browser window instead.</p>
            <div className="mt-6 flex flex-wrap justify-center gap-3">
              <button onClick={() => popup(url)} className="flex items-center gap-2 rounded-full bg-[#8ab4f8] px-6 py-[0.65rem] text-[0.9rem] font-semibold text-[#202124]"><ExternalLink className="h-4 w-4" /> Open in new window</button>
              <button onClick={() => go("https://web.archive.org/web/2/" + url)} className="rounded-full bg-white/12 px-6 py-[0.65rem] text-[0.9rem] font-semibold">View archived copy</button>
              {blockedApp && (
                <button onClick={() => (ctx.installed.includes(blockedApp.id) ? ctx.openApp(blockedApp.id) : ctx.openApp("store"))} className="flex items-center gap-2 rounded-full bg-white/12 px-6 py-[0.65rem] text-[0.9rem] font-semibold">
                  <blockedApp.Icon className="h-4 w-4" /> {ctx.installed.includes(blockedApp.id) ? `Open ${blockedApp.name} app` : `Get ${blockedApp.name} in the Store`}
                </button>
              )}
            </div>
            <div className="mt-8 text-[0.72rem] uppercase tracking-widest text-white/30">ERR_BLOCKED_BY_RESPONSE</div>
          </div>
        )}

        {!url.startsWith("about:") && !blocked && (
          <button onClick={() => popup(url)} className="absolute bottom-3 right-3 z-10 flex items-center gap-2 rounded-full bg-black/60 px-4 py-[0.4rem] text-[0.75rem] text-white/80 opacity-60 backdrop-blur-md transition-opacity hover:opacity-100">
            <ExternalLink className="h-3.5 w-3.5" /> Page not loading? Open in window
          </button>
        )}
      </div>
    </div>
  );
}
