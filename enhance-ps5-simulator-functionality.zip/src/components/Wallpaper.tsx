import { useEffect, useRef, useState } from "react";
import type { Theme } from "../lib/themes";

function rgba(hex: string, a: number) {
  const n = parseInt(hex.slice(1), 16);
  return `rgba(${(n >> 16) & 255},${(n >> 8) & 255},${n & 255},${a})`;
}

interface P {
  x: number; y: number; vx: number; vy: number; r: number; a: number; ph: number; rot: number; vr: number; k: number; c: string;
}

const CONFETTI = ["#38bdf8", "#f472b6", "#facc15", "#4ade80", "#fb923c", "#a78bfa", "#ffffff"];
const PSC = ["#78aaff", "#ff6f7d", "#ff9bd5", "#4fe3a8"];

function spawn(fx: string, w: number, h: number, first: boolean): P {
  const r = Math.random;
  const base: P = { x: r() * w, y: r() * h, vx: 0, vy: 0, r: 1, a: 1, ph: r() * 6.28, rot: r() * 6.28, vr: (r() - 0.5) * 0.02, k: Math.floor(r() * 4), c: "#fff" };
  switch (fx) {
    case "spores":
    case "dust":
      base.r = 0.8 + r() * (fx === "spores" ? 3.2 : 2);
      base.vx = (r() - 0.5) * 0.25;
      base.vy = -0.08 - r() * 0.3;
      base.a = 0.25 + r() * 0.6;
      base.c = fx === "spores" ? (r() > 0.4 ? "#d6e48a" : "#9fbf5a") : r() > 0.5 ? "#ffd9a0" : "#fff1d6";
      if (!first) base.y = h + 10;
      break;
    case "stars":
      base.r = 0.4 + r() * 1.8;
      base.vx = -0.03 - r() * 0.05;
      base.a = 0.3 + r() * 0.7;
      base.c = r() > 0.8 ? "#9be7ff" : r() > 0.6 ? "#ffd6f2" : "#ffffff";
      break;
    case "snow":
      base.r = 1 + r() * 3;
      base.vx = -0.2 + r() * 0.1;
      base.vy = 0.4 + r() * 1.1;
      base.a = 0.4 + r() * 0.6;
      if (!first) base.y = -10;
      break;
    case "embers":
      base.r = 0.8 + r() * 2.4;
      base.vx = (r() - 0.5) * 0.5;
      base.vy = -0.4 - r() * 0.9;
      base.a = 0.5 + r() * 0.5;
      base.c = r() > 0.5 ? "#ff8a3d" : "#ffc36b";
      if (!first) base.y = h + 10;
      break;
    case "rain":
      base.r = 10 + r() * 18;
      base.vx = -2.2;
      base.vy = 11 + r() * 9;
      base.a = 0.15 + r() * 0.3;
      if (!first) base.y = -30;
      break;
    case "leaves":
      base.r = 5 + r() * 8;
      base.vx = -0.6 - r() * 1.1;
      base.vy = 0.6 + r() * 1.1;
      base.a = 0.7 + r() * 0.3;
      base.c = ["#c0392b", "#e0583a", "#a82a1f", "#e8903a"][base.k];
      if (!first) { base.y = -20; base.x = w + 20 - r() * w * 0.7; }
      break;
    case "confetti":
      base.r = 4 + r() * 7;
      base.vx = (r() - 0.5) * 0.35;
      base.vy = -0.2 - r() * 0.4;
      base.a = 0.8;
      base.c = CONFETTI[Math.floor(r() * CONFETTI.length)];
      if (!first) base.y = h + 20;
      break;
    case "shapes":
      base.r = 14 + r() * 26;
      base.vx = (r() - 0.5) * 0.2;
      base.vy = -0.15 - r() * 0.3;
      base.a = 0.12 + r() * 0.25;
      base.c = PSC[base.k];
      if (!first) base.y = h + 50;
      break;
    case "speed":
      base.r = 60 + r() * 220;
      base.vx = 14 + r() * 26;
      base.a = 0.08 + r() * 0.25;
      base.c = r() > 0.8 ? "#ff3b5c" : "#9fdcff";
      if (!first) base.x = -base.r;
      break;
    case "fog":
      base.r = 200 + r() * 320;
      base.vx = 0.08 + r() * 0.2;
      base.a = 0.05 + r() * 0.09;
      base.y = h * (0.35 + r() * 0.65);
      if (!first) base.x = -base.r;
      break;
  }
  return base;
}

/** Themed animated background: wallpaper image + overlay + a particle/ribbon canvas that reacts to the pointer. */
export default function Wallpaper({ theme, image, animate, paused }: { theme: Theme; image: string | null; animate: boolean; paused: boolean }) {
  const ref = useRef<HTMLCanvasElement>(null);
  const [loaded, setLoaded] = useState<string | null>(null);

  useEffect(() => {
    setLoaded(null);
    if (!image) return;
    const im = new Image();
    im.onload = () => setLoaded(image);
    im.src = image;
  }, [image]);

  useEffect(() => {
    const cv = ref.current!;
    const ctx = cv.getContext("2d")!;
    const fx = theme.fx;
    const [, c1, c2] = theme.colors;
    let w = 0, h = 0;
    const resize = () => {
      w = cv.width = window.innerWidth;
      h = cv.height = window.innerHeight;
    };
    resize();
    window.addEventListener("resize", resize);
    const mouse = { x: -9999, y: -9999, px: 0.5, py: 0.5 };
    const mv = (e: PointerEvent) => {
      mouse.x = e.clientX;
      mouse.y = e.clientY;
      mouse.px = e.clientX / window.innerWidth;
      mouse.py = e.clientY / window.innerHeight;
    };
    window.addEventListener("pointermove", mv);

    const count: Record<string, number> = { spores: 90, dust: 70, stars: 150, snow: 140, embers: 70, rain: 120, leaves: 34, confetti: 46, shapes: 22, speed: 40, fog: 9 };
    const parts: P[] = Array.from({ length: count[fx] ?? 0 }, () => spawn(fx, w, h, true));
    let raf = 0;
    let last = performance.now();
    const t0 = last;

    const ribbons = (t: number, alpha: number) => {
      ctx.globalCompositeOperation = "lighter";
      const cols = [c1, c2, c1, c2];
      for (let i = 0; i < 4; i++) {
        const baseY = h * (0.5 + i * 0.11) + (mouse.py - 0.5) * 30 * (i + 1);
        const amp = h * (0.07 + i * 0.025);
        const g = ctx.createLinearGradient(0, baseY - amp, w, baseY + amp);
        g.addColorStop(0, rgba(cols[i], 0.0));
        g.addColorStop(0.35, rgba(cols[i], alpha * (0.35 - i * 0.05)));
        g.addColorStop(0.7, rgba(cols[(i + 1) % 4], alpha * (0.3 - i * 0.04)));
        g.addColorStop(1, rgba(cols[i], 0));
        ctx.fillStyle = g;
        ctx.beginPath();
        ctx.moveTo(0, h);
        for (let x = 0; x <= w; x += 16) {
          const y = baseY + Math.sin(x * 0.0035 + t * (0.25 + i * 0.07) + i * 1.7) * amp + Math.sin(x * 0.009 - t * 0.4 + i) * amp * 0.35;
          ctx.lineTo(x, y);
        }
        ctx.lineTo(w, h);
        ctx.closePath();
        ctx.fill();
      }
      ctx.globalCompositeOperation = "source-over";
    };

    const shape = (p: P) => {
      ctx.save();
      ctx.translate(p.x, p.y);
      ctx.rotate(p.rot);
      ctx.strokeStyle = p.c;
      ctx.lineWidth = 3;
      ctx.globalAlpha = p.a;
      ctx.beginPath();
      const r = p.r;
      if (p.k === 0) { ctx.moveTo(0, -r); ctx.lineTo(r * 0.9, r * 0.7); ctx.lineTo(-r * 0.9, r * 0.7); ctx.closePath(); }
      else if (p.k === 1) ctx.arc(0, 0, r * 0.8, 0, 6.3);
      else if (p.k === 2) { ctx.moveTo(-r * 0.7, -r * 0.7); ctx.lineTo(r * 0.7, r * 0.7); ctx.moveTo(r * 0.7, -r * 0.7); ctx.lineTo(-r * 0.7, r * 0.7); }
      else ctx.rect(-r * 0.7, -r * 0.7, r * 1.4, r * 1.4);
      ctx.stroke();
      ctx.restore();
    };

    const loop = (now: number) => {
      raf = requestAnimationFrame(loop);
      const dt = Math.min(2.5, (now - last) / 16.67);
      last = now;
      const t = (now - t0) / 1000;
      ctx.clearRect(0, 0, w, h);

      if (fx === "ribbons") ribbons(t, 1);
      else if (fx === "embers" && !theme.image) ribbons(t, 0.6);
      else if (fx === "towers") {
        for (let i = 0; i < 46; i++) {
          const x = (i / 46) * w + Math.sin(i * 12.9) * 8;
          const bw = w / 46 * 0.55;
          const hh = h * (0.18 + 0.5 * Math.abs(Math.sin(i * 3.1 + t * (0.15 + (i % 5) * 0.03))) * (0.5 + 0.5 * Math.sin(i * 1.7)));
          const g = ctx.createLinearGradient(0, h - hh, 0, h);
          g.addColorStop(0, rgba(c2, 0));
          g.addColorStop(1, rgba(c1, 0.55));
          ctx.fillStyle = g;
          ctx.fillRect(x, h - hh, bw, hh);
        }
        const gl = ctx.createRadialGradient(w / 2, h, 0, w / 2, h, w * 0.6);
        gl.addColorStop(0, rgba(c2, 0.35));
        gl.addColorStop(1, "rgba(0,0,0,0)");
        ctx.fillStyle = gl;
        ctx.fillRect(0, 0, w, h);
      } else if (fx === "grid") {
        ctx.strokeStyle = rgba(c2, 0.28);
        ctx.lineWidth = 1;
        const hor = h * 0.5;
        for (let i = 0; i < 14; i++) {
          const y = hor + Math.pow(((i + (t * 0.6) % 1) / 14), 2.2) * (h - hor);
          ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(w, y); ctx.stroke();
        }
        for (let i = -16; i <= 16; i++) {
          ctx.beginPath(); ctx.moveTo(w / 2 + i * 14, hor); ctx.lineTo(w / 2 + i * w * 0.09, h); ctx.stroke();
        }
      }

      for (let i = 0; i < parts.length; i++) {
        const p = parts[i];
        // pointer interaction: gently push particles away
        const dx = p.x - mouse.x, dy = p.y - mouse.y;
        const d2 = dx * dx + dy * dy;
        if (d2 < 22000 && fx !== "rain" && fx !== "speed" && fx !== "fog") {
          const f = (1 - d2 / 22000) * 2.2;
          const d = Math.sqrt(d2) || 1;
          p.x += (dx / d) * f * dt;
          p.y += (dy / d) * f * dt;
        }
        p.x += p.vx * dt;
        p.y += p.vy * dt;
        p.rot += p.vr * dt;
        const sway = Math.sin(t * 0.8 + p.ph);

        switch (fx) {
          case "spores":
          case "dust":
          case "embers": {
            p.x += sway * 0.25 * dt;
            const tw = 0.6 + 0.4 * Math.sin(t * 2 + p.ph);
            const gr = ctx.createRadialGradient(p.x, p.y, 0, p.x, p.y, p.r * 4);
            gr.addColorStop(0, rgba(p.c, p.a * tw));
            gr.addColorStop(1, rgba(p.c, 0));
            ctx.fillStyle = gr;
            ctx.fillRect(p.x - p.r * 4, p.y - p.r * 4, p.r * 8, p.r * 8);
            if (p.y < -20 || p.x < -20 || p.x > w + 20) parts[i] = spawn(fx, w, h, false);
            break;
          }
          case "stars": {
            const tw = 0.5 + 0.5 * Math.sin(t * 1.6 + p.ph);
            ctx.fillStyle = rgba(p.c, p.a * (0.4 + tw * 0.6));
            const ox = (mouse.px - 0.5) * p.r * 14;
            ctx.beginPath();
            ctx.arc(p.x + ox, p.y, p.r, 0, 6.3);
            ctx.fill();
            if (p.x < -5) { p.x = w + 5; p.y = Math.random() * h; }
            break;
          }
          case "snow": {
            p.x += sway * 0.6 * dt;
            ctx.fillStyle = `rgba(235,245,255,${p.a})`;
            ctx.beginPath(); ctx.arc(p.x, p.y, p.r, 0, 6.3); ctx.fill();
            if (p.y > h + 10 || p.x < -10) parts[i] = spawn(fx, w, h, false);
            break;
          }
          case "rain": {
            ctx.strokeStyle = `rgba(190,215,255,${p.a})`;
            ctx.lineWidth = 1.2;
            ctx.beginPath(); ctx.moveTo(p.x, p.y); ctx.lineTo(p.x + p.vx * 1.8, p.y - p.r); ctx.stroke();
            if (p.y > h + 20) parts[i] = spawn(fx, w, h, false);
            if (p.x < -20) p.x = w + 20;
            break;
          }
          case "leaves": {
            p.x += sway * 0.8 * dt;
            ctx.save();
            ctx.translate(p.x, p.y);
            ctx.rotate(p.rot + sway * 0.6);
            ctx.fillStyle = p.c;
            ctx.globalAlpha = p.a;
            ctx.beginPath();
            ctx.moveTo(0, -p.r);
            ctx.bezierCurveTo(p.r * 0.9, -p.r * 0.3, p.r * 0.7, p.r * 0.7, 0, p.r);
            ctx.bezierCurveTo(-p.r * 0.7, p.r * 0.7, -p.r * 0.9, -p.r * 0.3, 0, -p.r);
            ctx.fill();
            ctx.restore();
            if (p.y > h + 30 || p.x < -30) parts[i] = spawn(fx, w, h, false);
            break;
          }
          case "confetti": {
            p.x += sway * 0.4 * dt;
            ctx.save();
            ctx.translate(p.x, p.y);
            ctx.rotate(p.rot * 6);
            ctx.fillStyle = p.c;
            ctx.globalAlpha = p.a;
            if (p.k === 0) ctx.fillRect(-p.r / 2, -p.r / 4, p.r, p.r / 2);
            else if (p.k === 1) { ctx.beginPath(); ctx.arc(0, 0, p.r / 2, 0, 6.3); ctx.fill(); }
            else if (p.k === 2) { ctx.beginPath(); for (let s = 0; s < 5; s++) { const a = (s * 4 * Math.PI) / 5 - Math.PI / 2; ctx.lineTo(Math.cos(a) * p.r * 0.7, Math.sin(a) * p.r * 0.7); } ctx.closePath(); ctx.fill(); }
            else { ctx.beginPath(); ctx.moveTo(0, -p.r / 2); ctx.lineTo(p.r / 2, p.r / 2); ctx.lineTo(-p.r / 2, p.r / 2); ctx.closePath(); ctx.fill(); }
            ctx.restore();
            if (p.y < -30) parts[i] = spawn(fx, w, h, false);
            break;
          }
          case "shapes":
            shape(p);
            if (p.y < -60) parts[i] = spawn(fx, w, h, false);
            break;
          case "speed": {
            const g = ctx.createLinearGradient(p.x - p.r, 0, p.x, 0);
            g.addColorStop(0, rgba(p.c, 0));
            g.addColorStop(1, rgba(p.c, p.a));
            ctx.fillStyle = g;
            ctx.fillRect(p.x - p.r, p.y, p.r, 1.5);
            if (p.x - p.r > w) { parts[i] = spawn(fx, w, h, false); parts[i].y = Math.random() * h; }
            break;
          }
          case "fog": {
            const gr = ctx.createRadialGradient(p.x, p.y, 0, p.x, p.y, p.r);
            gr.addColorStop(0, `rgba(190,195,205,${p.a})`);
            gr.addColorStop(1, "rgba(190,195,205,0)");
            ctx.fillStyle = gr;
            ctx.fillRect(p.x - p.r, p.y - p.r, p.r * 2, p.r * 2);
            if (p.x - p.r > w) parts[i] = spawn(fx, w, h, false);
            break;
          }
        }
      }
    };

    if (animate && !paused) raf = requestAnimationFrame(loop);
    else {
      last = performance.now();
      loop(last);
      cancelAnimationFrame(raf);
    }
    return () => {
      cancelAnimationFrame(raf);
      window.removeEventListener("resize", resize);
      window.removeEventListener("pointermove", mv);
    };
  }, [theme, animate, paused]);

  const [c0, c1, c2] = theme.colors;
  return (
    <div className="absolute inset-0 overflow-hidden" style={{ background: `radial-gradient(ellipse at 70% 30%, ${c1}55, transparent 60%), radial-gradient(ellipse at 20% 90%, ${c2}33, transparent 55%), ${c0}` }}>
      {image && (
        <div
          className={`absolute inset-0 transition-opacity duration-[1200ms] ${loaded === image ? "opacity-100" : "opacity-0"}`}
        >
          <div
            className={`absolute -inset-[3%] bg-cover bg-center ${animate && !paused ? "anim-kenburns" : ""}`}
            style={{ backgroundImage: `url("${image}")`, filter: theme.imgFilter }}
          />
        </div>
      )}
      <div className="absolute inset-0" style={{ background: theme.overlay }} />
      <canvas ref={ref} className="absolute inset-0 h-full w-full" />
    </div>
  );
}
