import { useState, type ReactNode } from "react";
import { Home, Maximize, Minimize, Music, Music2, Play, RotateCw, Settings as Gear, Sun, UserRound, Volume2, VolumeX, X } from "lucide-react";
import type { Running } from "../types";
import { getApp } from "../lib/apps";
import { useApp } from "../lib/ctx";
import { useNav } from "../lib/useNav";
import { sfx } from "../lib/sfx";
import { Hint, HintBar, PSLogo } from "./ui";

interface Act {
  id: string;
  label: string;
  icon: ReactNode;
  on?: boolean;
}

/** The PS-button control center. Shows quick actions, running apps/games and sliders. */
export default function ControlCenter({ foreground, onClose }: { foreground: Running | null; onClose: () => void }) {
  const ctx = useApp();
  const { settings, running, games, theme } = ctx;
  const [row, setRow] = useState(0); // 0 actions · 1 running · 2 volume · 3 brightness
  const [col, setCol] = useState(0);
  const [rcol, setRcol] = useState(0);
  const ic = "h-[1.55rem] w-[1.55rem]";

  const acts: Act[] = [
    ...(foreground ? [{ id: "home", label: "Go to Home", icon: <Home className={ic} /> }] : []),
    ...(foreground ? [{ id: "resume", label: "Resume", icon: <Play className={ic} /> }] : []),
    { id: "settings", label: "Settings", icon: <Gear className={ic} /> },
    { id: "sfx", label: settings.sfx ? "Sounds On" : "Sounds Off", icon: settings.sfx ? <Volume2 className={ic} /> : <VolumeX className={ic} />, on: settings.sfx },
    { id: "music", label: settings.music ? "Music On" : "Music Off", icon: settings.music ? <Music2 className={ic} /> : <Music className={ic} />, on: settings.music },
    { id: "fs", label: ctx.fullscreen ? "Exit Fullscreen" : "Fullscreen", icon: ctx.fullscreen ? <Minimize className={ic} /> : <Maximize className={ic} /> },
    { id: "user", label: "Switch User", icon: <UserRound className={ic} /> },
    { id: "restart", label: "Restart", icon: <RotateCw className={ic} /> },
  ];

  const info = (r: Running) => {
    if (r.kind === "game") {
      const g = games.find((x) => x.id === r.id);
      return { title: g?.title ?? "Game", sub: "Game", art: g?.cover, icon: null as ReactNode };
    }
    const a = getApp(r.id);
    return { title: a?.name ?? "App", sub: a?.category ?? "App", art: undefined, icon: a ? <a.Icon className="h-[55%] w-[55%]" /> : null, bg: a?.bg, fg: a?.fg };
  };

  const doAct = (id: string) => {
    sfx.select();
    switch (id) {
      case "home": ctx.goHome(); onClose(); break;
      case "resume": onClose(); break;
      case "settings": onClose(); ctx.openApp("settings"); break;
      case "sfx": ctx.update({ sfx: !settings.sfx }); break;
      case "music": ctx.update({ music: !settings.music }); break;
      case "fs": ctx.toggleFullscreen(); break;
      case "user": onClose(); ctx.switchUser(); break;
      case "restart": onClose(); ctx.restart(); break;
    }
  };
  const open = (r: Running) => {
    onClose();
    if (r.kind === "game") {
      const g = games.find((x) => x.id === r.id);
      if (g) ctx.launchGame(g);
    } else ctx.openApp(r.id);
  };

  const rows = [0, ...(running.length ? [1] : []), 2, 3];
  const rowPos = rows.indexOf(row);

  useNav(
    (a) => {
      if (a === "back" || a === "ps") { sfx.back(); onClose(); return; }
      if (a === "up" && rowPos > 0) { setRow(rows[rowPos - 1]); sfx.move(); return; }
      if (a === "down" && rowPos < rows.length - 1) { setRow(rows[rowPos + 1]); sfx.move(); return; }
      if (row === 0) {
        if (a === "left" && col > 0) { setCol(col - 1); sfx.move(); }
        else if (a === "right" && col < acts.length - 1) { setCol(col + 1); sfx.move(); }
        else if (a === "confirm") doAct(acts[col].id);
      } else if (row === 1) {
        if (a === "left" && rcol > 0) { setRcol(rcol - 1); sfx.move(); }
        else if (a === "right" && rcol < running.length - 1) { setRcol(rcol + 1); sfx.move(); }
        else if (a === "confirm") open(running[rcol]);
        else if (a === "options") { ctx.closeRunning(running[rcol]); setRcol(0); sfx.back(); }
      } else if (row === 2) {
        const v = settings.volume;
        if (a === "left") { ctx.update({ volume: Math.max(0, +(v - 0.05).toFixed(2)), sfx: true }); sfx.move(); }
        else if (a === "right") { ctx.update({ volume: Math.min(1, +(v + 0.05).toFixed(2)), sfx: true }); sfx.move(); }
      } else if (row === 3) {
        const v = settings.brightness;
        if (a === "left") ctx.update({ brightness: Math.max(0.5, +(v - 0.05).toFixed(2)) });
        else if (a === "right") ctx.update({ brightness: Math.min(1.25, +(v + 0.05).toFixed(2)) });
      }
    },
    true,
    true
  );

  return (
    <div className="anim-fade-in absolute inset-0 z-[100]" onClick={onClose}>
      <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/55 to-black/25 backdrop-blur-md" />
      <div onClick={(e) => e.stopPropagation()} className="absolute inset-x-0 bottom-0 px-[4rem] pb-[3.6rem]" style={{ animation: "slide-up 0.35s cubic-bezier(.2,.8,.2,1) both" }}>
        <div className="mb-6 flex items-center gap-3 text-white/90">
          <PSLogo className="h-[1.6rem] w-[1.6rem]" />
          <span className="text-[1.25rem] font-semibold">Control Center</span>
        </div>

        {/* actions */}
        <div className="flex gap-[1.1rem]">
          {acts.map((a, i) => {
            const f = row === 0 && col === i;
            return (
              <button key={a.id} onMouseEnter={() => { setRow(0); setCol(i); }} onClick={() => doAct(a.id)} className="flex w-[5.6rem] flex-col items-center gap-2">
                <div className={`relative flex h-[4.2rem] w-[4.2rem] items-center justify-center rounded-full transition-all duration-150 ${f ? "scale-110 bg-white text-black" : a.on === false ? "bg-white/10 text-white/50" : "bg-white/15 text-white"}`}>
                  {a.icon}
                  {f && <span className="focus-ring absolute -inset-[0.2rem] rounded-full" />}
                </div>
                <span className={`text-center text-[0.74rem] font-medium leading-tight ${f ? "text-white" : "text-white/60"}`}>{a.label}</span>
              </button>
            );
          })}
        </div>

        {/* running */}
        {running.length > 0 && (
          <div className="mt-6">
            <div className="mb-2 text-[0.72rem] font-semibold uppercase tracking-[0.2em] text-white/50">Running in background</div>
            <div className="flex gap-4">
              {running.map((r, i) => {
                const d = info(r);
                const f = row === 1 && rcol === i;
                const isFg = foreground?.id === r.id && foreground.kind === r.kind;
                return (
                  <div key={r.kind + r.id} onMouseEnter={() => { setRow(1); setRcol(i); }} className={`relative flex w-[16rem] items-center gap-3 rounded-2xl p-3 transition-all ${f ? "scale-[1.03] bg-white text-black" : "bg-white/10"}`}>
                    <button onClick={() => open(r)} className="flex flex-1 items-center gap-3 text-left">
                      <div className="flex h-[3.4rem] w-[3.4rem] items-center justify-center overflow-hidden rounded-xl" style={{ background: d.art ? undefined : (d as { bg?: string }).bg ?? "#333", color: (d as { fg?: string }).fg }}>
                        {d.art ? <img src={d.art} alt="" className="h-full w-full object-cover" /> : d.icon}
                      </div>
                      <div className="min-w-0">
                        <div className="truncate text-[0.95rem] font-semibold">{d.title}</div>
                        <div className={`text-[0.74rem] ${f ? "text-black/60" : "text-white/55"}`}>{isFg ? "Now showing" : "Running"} · {d.sub}</div>
                      </div>
                    </button>
                    <button title="Close" onClick={() => { ctx.closeRunning(r); setRcol(0); }} className={`flex h-8 w-8 items-center justify-center rounded-full ${f ? "bg-black/10 hover:bg-black/20" : "bg-white/10 hover:bg-white/20"}`}>
                      <X className="h-4 w-4" />
                    </button>
                    {f && <span className="focus-ring pointer-events-none absolute inset-0 rounded-2xl" />}
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* sliders */}
        <div className="mt-6 grid max-w-[44rem] grid-cols-2 gap-x-8">
          {[
            { r: 2, label: "Volume", icon: settings.sfx && settings.volume > 0 ? <Volume2 className="h-4 w-4" /> : <VolumeX className="h-4 w-4" />, v: settings.sfx ? settings.volume : 0, set: (v: number) => ctx.update({ volume: v, sfx: true }), min: 0, max: 1 },
            { r: 3, label: "Brightness", icon: <Sun className="h-4 w-4" />, v: settings.brightness, set: (v: number) => ctx.update({ brightness: v }), min: 0.5, max: 1.25 },
          ].map((s) => (
            <div key={s.label} className={`rounded-xl px-4 py-3 transition-all ${row === s.r ? "bg-white/15 ring-1 ring-white/40" : "bg-white/[0.06]"}`} onMouseEnter={() => setRow(s.r)}>
              <div className="mb-2 flex items-center justify-between text-[0.85rem] font-medium"><span className="flex items-center gap-2">{s.icon}{s.label}</span><span className="text-white/60">{Math.round(((s.v - s.min) / (s.max - s.min)) * 100)}%</span></div>
              <input type="range" className="ps-range w-full" min={s.min} max={s.max} step={0.01} value={s.v} onChange={(e) => s.set(parseFloat(e.target.value))} style={{ accentColor: theme.accent }} />
            </div>
          ))}
        </div>
      </div>
      <HintBar show={settings.hints} className="!bottom-[1.1rem]">
        <Hint k="Enter" glyph="cross">Select</Hint>
        {running.length > 0 && <Hint k="Tab" glyph="triangle">Close Running</Hint>}
        <Hint k="Esc" glyph="circle">Back</Hint>
      </HintBar>
    </div>
  );
}
