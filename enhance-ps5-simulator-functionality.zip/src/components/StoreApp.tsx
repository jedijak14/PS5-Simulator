import { useEffect, useMemo, useRef, useState } from "react";
import { Check, Download, Home, Lock, Play, Search, Trash2 } from "lucide-react";
import type { Game } from "../types";
import { APPS, type AppDef } from "../lib/apps";
import { GAME_GENRES, STORE_GAMES } from "../lib/catalog";
import { useApp } from "../lib/ctx";
import { useNav } from "../lib/useNav";
import { sfx } from "../lib/sfx";
import { appAllowed, gameAllowed } from "../lib/rules";
import { Hint, HintBar, PSLogo } from "./ui";

type Item = { kind: "game"; id: string; title: string; game: Game } | { kind: "app"; id: string; title: string; app: AppDef };

const TABS = ["Featured", "Games", "Apps", "Search"] as const;
type TabName = (typeof TABS)[number];
const COLS = 5;

export default function StoreApp() {
  const ctx = useApp();
  const { installed, restricted, parental, settings, theme } = ctx;
  const [tab, setTab] = useState<TabName>("Featured");
  const [zone, setZone] = useState<"top" | "grid">("grid");
  const [sel, setSel] = useState(0);
  const [genre, setGenre] = useState("All");
  const [query, setQuery] = useState("");
  const [detail, setDetail] = useState<Item | null>(null);
  const [dl, setDl] = useState<Record<string, number>>({});
  const [slide, setSlide] = useState(0);
  const search = useRef<HTMLInputElement>(null);

  const all: Item[] = useMemo(
    () => [
      ...STORE_GAMES.map((g): Item => ({ kind: "game", id: g.id, title: g.title, game: g })),
      ...APPS.filter((a) => !a.builtin).map((a): Item => ({ kind: "app", id: a.id, title: a.name, app: a })),
    ],
    []
  );

  const items = useMemo(() => {
    let l = all;
    if (tab === "Games") l = l.filter((i) => i.kind === "game" && (genre === "All" || i.game.genre === genre));
    else if (tab === "Apps") l = l.filter((i) => i.kind === "app");
    else if (tab === "Featured") l = [...all.filter((i) => i.kind === "app").slice(0, 5), ...all.filter((i) => i.kind === "game").slice(0, 10)];
    else if (tab === "Search") l = query.trim() ? all.filter((i) => i.title.toLowerCase().includes(query.trim().toLowerCase()) || (i.kind === "game" ? i.game.genre ?? "" : i.app.category).toLowerCase().includes(query.trim().toLowerCase())) : all;
    return l;
  }, [all, tab, genre, query]);

  useEffect(() => { setSel(0); }, [tab, genre, query]);
  useEffect(() => {
    if (tab === "Search") { setZone("top"); const t = window.setTimeout(() => search.current?.focus(), 80); return () => clearTimeout(t); }
    else search.current?.blur();
  }, [tab]);

  const hero = useMemo(() => [STORE_GAMES.find((g) => g.id === "web-hexgl")!, STORE_GAMES.find((g) => g.id === "web-pacman")!, STORE_GAMES.find((g) => g.id === "web-2048")!], []);
  useEffect(() => {
    if (tab !== "Featured") return;
    const t = window.setInterval(() => setSlide((s) => (s + 1) % 3), 5500);
    return () => clearInterval(t);
  }, [tab]);

  const allowed = (i: Item) => (i.kind === "game" ? gameAllowed(i.game, restricted, parental) : appAllowed(i.app, restricted, parental));
  const has = (id: string) => installed.includes(id);

  const startDownload = (i: Item) => {
    if (dl[i.id] !== undefined || has(i.id)) return;
    if (!allowed(i)) { sfx.error(); ctx.notify("Blocked by Parental Controls"); return; }
    sfx.select();
    setDl((d) => ({ ...d, [i.id]: 0 }));
    const speed = 0.04 + Math.random() * 0.05;
    const t = window.setInterval(() => {
      setDl((d) => {
        const v = (d[i.id] ?? 0) + speed + Math.random() * 0.03;
        if (v >= 1) {
          clearInterval(t);
          window.setTimeout(() => { ctx.install(i.id); setDl((x) => { const n = { ...x }; delete n[i.id]; return n; }); ctx.notify(`${i.title} is ready to play`); }, 200);
          return { ...d, [i.id]: 1 };
        }
        return { ...d, [i.id]: v };
      });
    }, 160);
  };

  const primary = (i: Item) => {
    if (has(i.id)) {
      setDetail(null);
      if (i.kind === "game") ctx.launchGame(ctx.games.find((g) => g.id === i.id) ?? i.game);
      else ctx.openApp(i.id);
    } else startDownload(i);
  };

  const topCount = TABS.length;
  const [topIdx, setTopIdx] = useState(0);
  useNav(
    (a) => {
      if (a === "back") { sfx.back(); ctx.goHome(); return; }
      if (zone === "top") {
        if (a === "left" && topIdx > 0) { setTopIdx(topIdx - 1); setTab(TABS[topIdx - 1]); sfx.move(); }
        else if (a === "right" && topIdx < topCount - 1) { setTopIdx(topIdx + 1); setTab(TABS[topIdx + 1]); sfx.move(); }
        else if (a === "down" || a === "confirm") { setZone("grid"); search.current?.blur(); sfx.move(); }
        return;
      }
      if (a === "left" && sel > 0) { setSel(sel - 1); sfx.move(); }
      else if (a === "right" && sel < items.length - 1) { setSel(sel + 1); sfx.move(); }
      else if (a === "down" && sel + COLS < items.length) { setSel(sel + COLS); sfx.move(); }
      else if (a === "up") { if (sel - COLS >= 0) setSel(sel - COLS); else { setZone("top"); setTopIdx(TABS.indexOf(tab)); if (tab === "Search") search.current?.focus(); } sfx.move(); }
      else if (a === "confirm" && items[sel]) { sfx.select(); setDetail(items[sel]); }
    },
    !detail
  );

  const gridRef = useRef<HTMLDivElement>(null);
  useEffect(() => {
    gridRef.current?.querySelector<HTMLElement>(`[data-i="${sel}"]`)?.scrollIntoView({ block: "nearest", behavior: "smooth" });
  }, [sel, tab]);

  const g = hero[slide];
  const progressOf = (i: Item) => dl[i.id];

  return (
    <div className="absolute inset-0 flex flex-col text-white" style={{ background: "linear-gradient(180deg,#05091a 0%,#0a1230 55%,#070b1c 100%)" }}>
      <div className="absolute inset-0 opacity-40" style={{ background: "radial-gradient(ellipse at 75% 0%, #1d5be8 0%, transparent 55%)" }} />
      {/* top bar */}
      <div className="relative z-10 flex items-center gap-8 px-[3.5rem] pb-3 pt-[1.5rem]">
        <div className="flex items-center gap-3 pr-4"><PSLogo className="h-[1.8rem] w-[1.8rem]" /><span className="text-[1.15rem] font-semibold tracking-tight">PlayStation Store</span></div>
        {TABS.map((t, i) => {
          const on = tab === t;
          const f = zone === "top" && topIdx === i;
          return (
            <button key={t} onClick={() => { setTab(t); setTopIdx(i); setZone(t === "Search" ? "top" : "grid"); sfx.move(); }} className={`relative pb-1 text-[1.1rem] transition-all ${on ? "font-semibold text-white" : "text-white/50 hover:text-white/80"} ${f ? "scale-110" : ""}`}>
              {t === "Search" ? <span className="flex items-center gap-2"><Search className="h-[1.1rem] w-[1.1rem]" />Search</span> : t}
              <span className={`absolute -bottom-px left-0 h-[0.18rem] rounded-full transition-all ${on ? "w-full" : "w-0"}`} style={{ background: theme.accent }} />
              {f && <span className="focus-ring absolute -inset-x-3 -inset-y-1 rounded-full" />}
            </button>
          );
        })}
        <div className="flex-1" />
        <span className="text-[0.82rem] text-white/50">{installed.filter((id) => all.some((a) => a.id === id)).length} installed</span>
        <button onClick={() => ctx.goHome()} className="glass flex items-center gap-2 rounded-full px-4 py-[0.4rem] text-[0.82rem] font-semibold"><Home className="h-4 w-4" /> Home</button>
      </div>

      <div ref={gridRef} className="no-scrollbar relative z-10 flex-1 overflow-y-auto px-[3.5rem] pb-[4rem]">
        {tab === "Featured" && (
          <div key={slide} className="anim-fade-in relative mb-8 h-[16rem] overflow-hidden rounded-[1.4rem] shadow-2xl ring-1 ring-white/10" style={{ animationDuration: "0.8s" }}>
            <img src={g.background} alt="" className="absolute inset-0 h-full w-full object-cover" />
            <div className="absolute inset-0 bg-gradient-to-r from-black/85 via-black/40 to-transparent" />
            <div className="absolute bottom-7 left-9 max-w-[28rem]">
              <div className="mb-2 inline-flex rounded bg-white/90 px-2 py-[0.1rem] text-[0.68rem] font-bold uppercase tracking-widest text-black">Free · Play now</div>
              <h2 className="text-[2.4rem] font-bold leading-tight">{g.title}</h2>
              <p className="mt-1 line-clamp-2 text-[0.92rem] text-white/75">{g.desc}</p>
              <button onClick={() => setDetail(all.find((i) => i.id === g.id) ?? null)} className="mt-4 rounded-full bg-white px-7 py-[0.55rem] text-[0.95rem] font-bold text-black">View</button>
            </div>
            <div className="absolute bottom-4 right-6 flex gap-2">{hero.map((_, i) => <button key={i} onClick={() => setSlide(i)} className={`h-[0.4rem] rounded-full transition-all ${i === slide ? "w-8 bg-white" : "w-3 bg-white/40"}`} />)}</div>
          </div>
        )}

        {tab === "Games" && (
          <div className="mb-5 flex flex-wrap gap-2">
            {GAME_GENRES.map((x) => <button key={x} onClick={() => setGenre(x)} className={`rounded-full px-4 py-[0.35rem] text-[0.85rem] font-medium ${genre === x ? "bg-white text-black" : "bg-white/10 hover:bg-white/20"}`}>{x}</button>)}
          </div>
        )}

        {tab === "Search" && (
          <div className="mb-6">
            <input ref={search} value={query} onChange={(e) => setQuery(e.target.value)} onFocus={() => setZone("top")} onKeyDown={(e) => { if (e.key === "ArrowDown" || e.key === "Enter") { e.preventDefault(); setZone("grid"); search.current?.blur(); } }} placeholder="Search games, apps and streaming services" className="w-full max-w-[40rem] rounded-full bg-white/10 px-6 py-[0.8rem] text-[1.1rem] outline-none ring-1 ring-white/15 focus:ring-2 focus:ring-white" />
          </div>
        )}

        <div className="mb-4 flex items-baseline justify-between">
          <h3 className="text-[1.3rem] font-semibold">{tab === "Featured" ? "Top Picks" : tab === "Games" ? "All Games" : tab === "Apps" ? "Apps & Streaming Services" : query ? "Results" : "Everything"}</h3>
          <span className="text-[0.8rem] text-white/45">{items.length} items</span>
        </div>

        <div className="grid gap-x-[1.6rem] gap-y-[1.8rem]" style={{ gridTemplateColumns: `repeat(${COLS}, minmax(0,1fr))` }}>
          {items.map((it, i) => {
            const on = zone === "grid" && sel === i;
            const ok = allowed(it);
            const p = progressOf(it);
            return (
              <button
                key={it.id}
                data-i={i}
                onMouseEnter={() => { setSel(i); }}
                onClick={() => { setSel(i); setZone("grid"); sfx.select(); setDetail(it); }}
                className={`group relative text-left transition-transform duration-200 ${on ? "scale-[1.05]" : ""}`}
              >
                <div
                  className="relative aspect-square w-full overflow-hidden"
                  style={{
                    borderRadius: theme.radius,
                    background: it.kind === "app" ? it.app.bg : "#111",
                    color: it.kind === "app" ? it.app.fg : undefined,
                    boxShadow: on ? "0 0 0 0.2rem #fff, 0 1rem 2.4rem rgba(0,0,0,.6)" : "0 0.4rem 1rem rgba(0,0,0,.45)",
                  }}
                >
                  {it.kind === "game" ? <img src={it.game.cover} alt="" className={`h-full w-full object-cover ${ok ? "" : "grayscale"}`} /> : <div className="flex h-full w-full items-center justify-center"><it.app.Icon className="h-[52%] w-[52%]" /></div>}
                  {!ok && <div className="absolute inset-0 flex items-center justify-center bg-black/60"><Lock className="h-8 w-8" /></div>}
                  {has(it.id) && <div className="absolute right-2 top-2 flex h-6 w-6 items-center justify-center rounded-full bg-[#4ade80] text-black"><Check className="h-4 w-4" strokeWidth={3.5} /></div>}
                  {p !== undefined && (
                    <div className="absolute inset-x-0 bottom-0 bg-black/70 p-2"><div className="h-[0.35rem] overflow-hidden rounded-full bg-white/20"><div className="stripes h-full rounded-full bg-[#4aa3ff]" style={{ width: `${Math.min(1, p) * 100}%` }} /></div></div>
                  )}
                </div>
                <div className="mt-2 truncate text-[0.95rem] font-semibold">{it.title}</div>
                <div className="flex items-center justify-between text-[0.76rem] text-white/55"><span>{it.kind === "game" ? it.game.genre : it.app.category}</span><span className="font-semibold text-white/80">{has(it.id) ? "Installed" : "Free"}</span></div>
              </button>
            );
          })}
        </div>
        {items.length === 0 && <div className="mt-16 text-center text-white/45">Nothing matches your search.</div>}
      </div>

      <HintBar show={settings.hints && !detail}>
        <Hint k="Enter" glyph="cross">Select</Hint>
        <Hint k="Esc" glyph="circle">Home</Hint>
      </HintBar>

      {detail && <Detail item={detail} installed={has(detail.id)} progress={progressOf(detail)} allowed={allowed(detail)} onClose={() => setDetail(null)} onPrimary={() => primary(detail)} onDelete={() => { ctx.uninstall(detail.id); }} />}
    </div>
  );
}

function Detail({ item, installed, progress, allowed, onClose, onPrimary, onDelete }: { item: Item; installed: boolean; progress?: number; allowed: boolean; onClose: () => void; onPrimary: () => void; onDelete: () => void }) {
  const [btn, setBtn] = useState(0);
  const downloading = progress !== undefined;
  const hasDelete = installed;
  useNav(
    (a) => {
      if (a === "back") { sfx.back(); onClose(); }
      else if (a === "left" || a === "right") { if (hasDelete) { setBtn((b) => 1 - b); sfx.move(); } }
      else if (a === "confirm") { btn === 1 && hasDelete ? onDelete() : onPrimary(); }
    },
    true,
    true
  );
  const app = item.kind === "app" ? item.app : null;
  const game = item.kind === "game" ? item.game : null;
  const rating = game?.rating ?? app?.rating ?? 0;
  return (
    <div className="anim-fade-in absolute inset-0 z-[60] overflow-hidden bg-black/80 backdrop-blur-xl" onClick={onClose}>
      {game && <img src={game.background} alt="" className="absolute inset-0 h-full w-full object-cover opacity-35" />}
      <div className="absolute inset-0 bg-gradient-to-r from-black/90 via-black/60 to-black/30" />
      <div className="anim-pop absolute inset-0 flex items-center gap-[3.5rem] px-[6rem]" onClick={(e) => e.stopPropagation()}>
        <div className="flex h-[19rem] w-[19rem] shrink-0 items-center justify-center overflow-hidden rounded-[1.6rem] shadow-2xl ring-1 ring-white/15" style={{ background: app?.bg ?? "#111", color: app?.fg }}>
          {game ? <img src={game.cover} alt="" className="h-full w-full object-cover" /> : app ? <app.Icon className="h-[10rem] w-[10rem]" /> : null}
        </div>
        <div className="max-w-[36rem]">
          <div className="text-[0.75rem] font-semibold uppercase tracking-[0.2em] text-white/55">{game ? `Game · ${game.genre}` : `App · ${app!.category}`}</div>
          <h2 className="mt-1 text-[2.6rem] font-bold leading-tight">{item.title}</h2>
          <div className="mt-3 flex items-center gap-3 text-[0.82rem] text-white/70">
            <span className="rounded border border-white/50 px-2 py-[0.05rem] font-bold">{rating > 0 ? `${rating}+` : "E"}</span>
            <span>Free</span><span>·</span><span>{app ? app.size : "Web game"}</span><span>·</span><span>{game ? "Single-player & online" : "Entertainment"}</span>
          </div>
          <p className="mt-5 text-[1rem] leading-relaxed text-white/80">{game?.desc ?? app!.desc}</p>
          <div className="mt-7 flex items-center gap-4">
            {!allowed ? (
              <div className="flex items-center gap-2 rounded-full bg-white/15 px-7 py-[0.75rem] font-semibold"><Lock className="h-5 w-5" /> Restricted by Parental Controls</div>
            ) : (
              <button onClick={onPrimary} onMouseEnter={() => setBtn(0)} className={`relative flex min-w-[12rem] items-center justify-center gap-2 overflow-hidden rounded-full px-8 py-[0.8rem] text-[1.05rem] font-bold transition-transform ${btn === 0 ? "scale-105 bg-white text-black" : "bg-white/90 text-black"}`}>
                {downloading && <span className="stripes absolute inset-y-0 left-0 bg-[#4aa3ff]/60" style={{ width: `${Math.min(1, progress!) * 100}%` }} />}
                <span className="relative flex items-center gap-2">
                  {downloading ? `Downloading… ${Math.round(Math.min(1, progress!) * 100)}%` : installed ? <><Play className="h-5 w-5 fill-black" />{game ? "Play" : "Open"}</> : <><Download className="h-5 w-5" />Download</>}
                </span>
              </button>
            )}
            {hasDelete && (
              <button onClick={onDelete} onMouseEnter={() => setBtn(1)} className={`flex items-center gap-2 rounded-full px-6 py-[0.8rem] text-[0.95rem] font-semibold transition-transform ${btn === 1 ? "scale-105 bg-[#ff5d6c] text-white" : "bg-white/15"}`}><Trash2 className="h-4 w-4" /> Delete</button>
            )}
          </div>
          <div className="mt-6 text-[0.78rem] text-white/45">Press Esc to go back</div>
        </div>
      </div>
    </div>
  );
}
