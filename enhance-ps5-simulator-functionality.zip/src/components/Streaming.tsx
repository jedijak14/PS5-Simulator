import { useEffect, useState, type ReactNode } from "react";
import { ArrowLeft, Check, ExternalLink, Home, Library, LogOut, Play, Plus, Search, Trash2, Heart, Globe } from "lucide-react";
import type { AppDef } from "../lib/apps";
import { useApp } from "../lib/ctx";
import { DISNEY_VIDEOS, SPOTIFY_PLAYLISTS } from "../lib/catalog";
import { pget, pset } from "../lib/store";
import { openWindow } from "../lib/popup";
import { sfx } from "../lib/sfx";
import { AvatarIcon } from "../lib/avatars";

/* ------------------------------------------------------------------ *
 *  shared: auth state per profile + sign-in screen
 * ------------------------------------------------------------------ */
interface Auth { in: boolean; name: string; guest?: boolean }

export function useAuth(appId: string) {
  const { profile } = useApp();
  const key = `auth.${appId}`;
  const [auth, setAuth] = useState<Auth>(() => pget<Auth>(profile.id, key, { in: false, name: "" }));
  const set = (a: Auth) => {
    setAuth(a);
    pset(profile.id, key, a);
  };
  return { auth, signIn: (name: string, guest = false) => set({ in: true, name, guest }), signOut: () => set({ in: false, name: "" }) };
}

function SignIn({ app, onDone, guestLabel }: { app: AppDef; onDone: (name: string, guest: boolean) => void; guestLabel?: string }) {
  const ctx = useApp();
  const [step, setStep] = useState(0);
  const [name, setName] = useState("");
  const brand = app.brand ?? "#2e7bff";

  const open = () => {
    sfx.select();
    if (!openWindow(app.login ?? app.site ?? "https://example.com")) ctx.notify("Pop-up blocked — allow pop-ups to sign in");
    setStep(1);
  };

  return (
    <div className="absolute inset-0 flex items-center justify-center overflow-hidden" style={{ background: `radial-gradient(ellipse at 30% 20%, ${brand}55, transparent 60%), radial-gradient(ellipse at 80% 90%, ${brand}33, transparent 55%), #0b0b10` }}>
      <button onClick={() => ctx.goHome()} className="glass absolute left-6 top-5 flex items-center gap-2 rounded-full px-4 py-[0.45rem] text-[0.82rem] font-semibold"><Home className="h-4 w-4" /> Home</button>
      <div className="anim-pop flex w-[50rem] overflow-hidden rounded-[1.6rem] bg-black/55 shadow-2xl ring-1 ring-white/10 backdrop-blur-xl">
        <div className="flex w-[18rem] flex-col items-center justify-center gap-4 p-8" style={{ background: app.bg, color: app.fg }}>
          <app.Icon className="h-[8rem] w-[8rem]" />
          <div className="text-[1.3rem] font-semibold">{app.name}</div>
          <div className="text-center text-[0.8rem] opacity-80">{app.tagline}</div>
        </div>
        <div className="flex flex-1 flex-col justify-center p-10">
          <h2 className="text-[1.8rem] font-semibold">Sign in to {app.name}</h2>
          <p className="mt-2 text-[0.9rem] leading-relaxed text-white/60">
            {step === 0 ? `Sign in with your ${app.name} account. The official sign-in page opens in a secure window — your password is never shared with this console.` : `Finish signing in in the ${app.name} window, then come back here and continue.`}
          </p>
          {step === 0 ? (
            <button onClick={open} className="mt-7 flex items-center justify-center gap-2 rounded-full px-6 py-[0.85rem] text-[1.02rem] font-bold text-black transition-transform hover:scale-[1.03]" style={{ background: brand === "#ffffff" ? "#fff" : brand, color: ["#1ed760", "#1ce783", "#e5a00d", "#ffffff"].includes(brand) ? "#000" : "#fff" }}>
              <ExternalLink className="h-5 w-5" /> Sign in with {app.name}
            </button>
          ) : (
            <div className="mt-6 flex flex-col gap-3">
              <input value={name} onChange={(e) => setName(e.target.value)} placeholder={`Your ${app.name} name (optional)`} maxLength={24} className="rounded-xl bg-white/10 px-4 py-[0.75rem] text-[1rem] outline-none ring-1 ring-white/15 focus:ring-white/60" />
              <button onClick={() => { sfx.select(); onDone(name.trim() || ctx.profile.name, false); }} className="flex items-center justify-center gap-2 rounded-full bg-white px-6 py-[0.8rem] text-[1rem] font-bold text-black"><Check className="h-5 w-5" /> I've signed in — Continue</button>
              <button onClick={open} className="rounded-full bg-white/10 px-6 py-[0.65rem] text-[0.88rem] font-medium">Reopen sign-in window</button>
            </div>
          )}
          {guestLabel && (
            <button onClick={() => onDone(ctx.profile.name, true)} className="mt-5 self-start text-[0.85rem] text-white/50 underline-offset-4 hover:text-white hover:underline">{guestLabel}</button>
          )}
        </div>
      </div>
    </div>
  );
}

function UserChip({ name, onOut }: { name: string; onOut: () => void }) {
  const { profile } = useApp();
  return (
    <div className="flex items-center gap-3">
      <AvatarIcon id={profile.avatar} size="2rem" ring={false} />
      <span className="text-[0.88rem] font-medium">{name}</span>
      <button onClick={onOut} title="Sign out" className="flex items-center gap-2 rounded-full bg-white/10 px-3 py-[0.3rem] text-[0.75rem] font-semibold hover:bg-white/20"><LogOut className="h-3.5 w-3.5" /> Sign out</button>
    </div>
  );
}

/* ------------------------------------------------------------------ *
 *  Spotify
 * ------------------------------------------------------------------ */
interface Item { type: string; id: string; title: string }
const thumbCache = new Map<string, { thumb?: string; title?: string }>();

function parseSpotify(s: string): { type: string; id: string } | null {
  const m = s.match(/(?:open\.spotify\.com\/(?:intl-[a-z]+\/)?|spotify:)(track|album|playlist|artist|show|episode)[/:]([A-Za-z0-9]{22})/);
  return m ? { type: m[1], id: m[2] } : null;
}

function useThumb(type: string, id: string) {
  const [d, setD] = useState(thumbCache.get(type + id));
  useEffect(() => {
    if (thumbCache.has(type + id)) return;
    let live = true;
    fetch(`https://open.spotify.com/oembed?url=${encodeURIComponent(`https://open.spotify.com/${type}/${id}`)}`)
      .then((r) => r.json())
      .then((j: { thumbnail_url?: string; title?: string }) => {
        thumbCache.set(type + id, { thumb: j.thumbnail_url, title: j.title });
        if (live) setD({ thumb: j.thumbnail_url, title: j.title });
      })
      .catch(() => thumbCache.set(type + id, {}));
    return () => { live = false; };
  }, [type, id]);
  return d;
}

function SpCard({ title, type, id, color, active, onPlay, sub }: { title: string; type: string; id: string; color: string; active: boolean; onPlay: () => void; sub: string }) {
  const d = useThumb(type, id);
  return (
    <button onClick={onPlay} className={`group rounded-xl bg-white/[0.06] p-3 text-left transition-colors hover:bg-white/[0.12] ${active ? "ring-2 ring-[#1ed760]" : ""}`}>
      <div className="relative aspect-square w-full overflow-hidden rounded-lg" style={{ background: `linear-gradient(135deg, ${color}, #111)` }}>
        {d?.thumb ? <img src={d.thumb} alt="" className="h-full w-full object-cover" /> : <div className="flex h-full items-center justify-center p-3 text-center text-[1.1rem] font-bold">{title}</div>}
        <div className="absolute bottom-2 right-2 flex h-11 w-11 translate-y-2 items-center justify-center rounded-full bg-[#1ed760] text-black opacity-0 shadow-xl transition-all group-hover:translate-y-0 group-hover:opacity-100"><Play className="h-5 w-5 fill-black" /></div>
      </div>
      <div className="mt-3 truncate text-[0.95rem] font-semibold">{title}</div>
      <div className="truncate text-[0.78rem] text-white/50">{sub}</div>
    </button>
  );
}

export function SpotifyApp({ app }: { app: AppDef }) {
  const ctx = useApp();
  const { auth, signIn, signOut } = useAuth("spotify");
  const [view, setView] = useState<"home" | "search" | "library">("home");
  const [cat, setCat] = useState("All");
  const [now, setNow] = useState<Item | null>(() => pget(ctx.profile.id, "spotify.now", null as Item | null));
  const [lib, setLib] = useState<Item[]>(() => pget(ctx.profile.id, "spotify.lib", [] as Item[]));
  const [q, setQ] = useState("");
  const [err, setErr] = useState("");

  useEffect(() => { pset(ctx.profile.id, "spotify.now", now); }, [now, ctx.profile.id]);
  useEffect(() => { pset(ctx.profile.id, "spotify.lib", lib); }, [lib, ctx.profile.id]);

  if (!auth.in) return <SignIn app={app} onDone={(n, g) => signIn(n, g)} guestLabel="Continue without signing in (30-second previews)" />;

  const cats = ["All", ...Array.from(new Set(SPOTIFY_PLAYLISTS.map((p) => p.cat)))];
  const shown = SPOTIFY_PLAYLISTS.filter((p) => cat === "All" || p.cat === cat);
  const saved = now ? lib.some((l) => l.id === now.id) : false;

  const play = (it: Item) => { sfx.select(); setNow(it); };
  const submit = () => {
    const p = parseSpotify(q);
    if (!p) { setErr("Paste a Spotify link, e.g. https://open.spotify.com/playlist/…"); sfx.error(); return; }
    setErr("");
    const it = { ...p, title: thumbCache.get(p.type + p.id)?.title ?? `${p.type[0].toUpperCase()}${p.type.slice(1)}` };
    play(it);
    setQ("");
  };

  const NavBtn = ({ id, icon, label }: { id: typeof view; icon: ReactNode; label: string }) => (
    <button onClick={() => setView(id)} className={`flex items-center gap-4 rounded-lg px-4 py-3 text-left text-[1rem] font-semibold transition-colors ${view === id ? "bg-white/10 text-white" : "text-white/60 hover:text-white"}`}>{icon}{label}</button>
  );

  return (
    <div className="absolute inset-0 flex bg-black text-white">
      <aside className="flex w-[15rem] shrink-0 flex-col gap-1 bg-black p-4">
        <div className="mb-4 flex items-center gap-3 px-2 text-[1.5rem] font-bold"><app.Icon className="h-9 w-9 text-[#1ed760]" /> Spotify</div>
        <NavBtn id="home" icon={<Home className="h-6 w-6" />} label="Home" />
        <NavBtn id="search" icon={<Search className="h-6 w-6" />} label="Search & Paste" />
        <NavBtn id="library" icon={<Library className="h-6 w-6" />} label="Your Library" />
        <div className="mt-auto flex flex-col gap-2">
          <button onClick={() => { if (!openWindow(app.site!)) ctx.notify("Pop-up blocked"); }} className="flex items-center gap-3 rounded-lg bg-white/10 px-4 py-3 text-[0.88rem] font-semibold hover:bg-white/15"><ExternalLink className="h-4 w-4" /> Open Web Player</button>
          <button onClick={() => ctx.goHome()} className="flex items-center gap-3 rounded-lg bg-white/10 px-4 py-3 text-[0.88rem] font-semibold hover:bg-white/15"><Home className="h-4 w-4" /> Back to Home</button>
        </div>
      </aside>

      <main className="m-2 ml-0 flex min-w-0 flex-1 flex-col overflow-hidden rounded-2xl bg-gradient-to-b from-[#2a2a2a] to-[#121212]">
        <div className="flex items-center justify-between px-8 py-5">
          <h1 className="text-[1.7rem] font-bold">{view === "home" ? `Good ${new Date().getHours() < 12 ? "morning" : new Date().getHours() < 18 ? "afternoon" : "evening"}` : view === "search" ? "Search & Paste" : "Your Library"}</h1>
          <UserChip name={auth.guest ? `${auth.name} (guest)` : auth.name} onOut={signOut} />
        </div>
        <div className="no-scrollbar flex-1 overflow-y-auto px-8 pb-8">
          {view === "home" && (
            <>
              <div className="mb-5 flex flex-wrap gap-2">
                {cats.map((c) => <button key={c} onClick={() => setCat(c)} className={`rounded-full px-4 py-[0.4rem] text-[0.85rem] font-medium ${cat === c ? "bg-white text-black" : "bg-white/10 hover:bg-white/15"}`}>{c}</button>)}
              </div>
              <div className="grid grid-cols-4 gap-4 xl:grid-cols-5">
                {shown.map((p) => <SpCard key={p.id} title={p.title} type="playlist" id={p.id} color={p.color} sub={`Playlist · ${p.cat}`} active={now?.id === p.id} onPlay={() => play({ type: "playlist", id: p.id, title: p.title })} />)}
              </div>
            </>
          )}
          {view === "search" && (
            <div className="max-w-[44rem]">
              <p className="mb-4 text-[0.95rem] text-white/60">Paste any Spotify link (track, album, playlist, artist, podcast) and it will start playing in the player.</p>
              <div className="flex gap-3">
                <input value={q} onChange={(e) => setQ(e.target.value)} onKeyDown={(e) => e.key === "Enter" && submit()} placeholder="https://open.spotify.com/track/…" className="flex-1 rounded-full bg-white/10 px-5 py-3 text-[1rem] outline-none ring-1 ring-white/10 focus:ring-white/60" />
                <button onClick={submit} className="rounded-full bg-[#1ed760] px-7 py-3 font-bold text-black">Play</button>
              </div>
              {err && <div className="mt-2 text-[0.85rem] text-[#ff8a95]">{err}</div>}
              <div className="mt-6 text-[0.85rem] text-white/50">Tip: in Spotify, choose Share → Copy link, then paste it here. Use <b>Open Web Player</b> to browse the full Spotify catalog in its own window.</div>
            </div>
          )}
          {view === "library" && (
            lib.length === 0 ? (
              <div className="mt-16 text-center text-white/50"><Heart className="mx-auto mb-3 h-10 w-10" /> Nothing saved yet. Play something and tap <b>Save to Library</b>.</div>
            ) : (
              <div className="grid grid-cols-4 gap-4 xl:grid-cols-5">
                {lib.map((l) => (
                  <div key={l.id} className="relative">
                    <SpCard title={l.title} type={l.type} id={l.id} color="#444" sub={l.type} active={now?.id === l.id} onPlay={() => play(l)} />
                    <button onClick={() => setLib((x) => x.filter((i) => i.id !== l.id))} className="absolute right-4 top-4 flex h-8 w-8 items-center justify-center rounded-full bg-black/70 hover:bg-black"><Trash2 className="h-4 w-4" /></button>
                  </div>
                ))}
              </div>
            )
          )}
        </div>
      </main>

      {now && (
        <aside className="anim-slide-left m-2 ml-0 flex w-[26rem] shrink-0 flex-col overflow-hidden rounded-2xl bg-[#121212]">
          <div className="flex items-center justify-between px-4 py-3">
            <div className="min-w-0"><div className="text-[0.7rem] font-semibold uppercase tracking-widest text-[#1ed760]">Now playing</div><div className="truncate text-[0.95rem] font-semibold">{now.title}</div></div>
            <div className="flex gap-2">
              <button onClick={() => { setLib((l) => (saved ? l.filter((i) => i.id !== now.id) : [...l, { ...now, title: thumbCache.get(now.type + now.id)?.title ?? now.title }])); ctx.notify(saved ? "Removed from library" : "Saved to library"); }} className={`flex items-center gap-2 rounded-full px-3 py-[0.35rem] text-[0.75rem] font-semibold ${saved ? "bg-[#1ed760] text-black" : "bg-white/10"}`}><Heart className={`h-3.5 w-3.5 ${saved ? "fill-black" : ""}`} />{saved ? "Saved" : "Save"}</button>
              <button onClick={() => setNow(null)} className="flex h-8 w-8 items-center justify-center rounded-full bg-white/10 hover:bg-white/20"><ArrowLeft className="h-4 w-4 rotate-180" /></button>
            </div>
          </div>
          <iframe
            key={now.type + now.id}
            title="Spotify player"
            src={`https://open.spotify.com/embed/${now.type}/${now.id}?utm_source=generator&theme=0`}
            allow="autoplay; clipboard-write; encrypted-media; fullscreen; picture-in-picture"
            className="min-h-0 flex-1 border-0"
            style={{ colorScheme: "normal" }}
          />
        </aside>
      )}
    </div>
  );
}

/* ------------------------------------------------------------------ *
 *  Disney+
 * ------------------------------------------------------------------ */
const FRANCHISES = [
  { name: "All", bg: "linear-gradient(135deg,#0b2a7a,#1a56e8)" },
  { name: "Disney", bg: "linear-gradient(135deg,#0d2a8f,#2d63ff)" },
  { name: "Pixar", bg: "linear-gradient(135deg,#0a5a9c,#38b6ff)" },
  { name: "Marvel", bg: "linear-gradient(135deg,#7a0a14,#e23636)" },
  { name: "Star Wars", bg: "linear-gradient(135deg,#111,#3a3a3a)" },
];

export function DisneyApp({ app }: { app: AppDef }) {
  const ctx = useApp();
  const { auth, signIn, signOut } = useAuth("disney");
  const [fr, setFr] = useState("All");
  const [vid, setVid] = useState<string | null>(null);
  if (!auth.in) return <SignIn app={app} onDone={(n, g) => signIn(n, g)} guestLabel="Browse trailers without signing in" />;

  const list = DISNEY_VIDEOS.filter((v) => fr === "All" || v.franchise === fr);
  const hero = DISNEY_VIDEOS[0];
  const current = vid ? DISNEY_VIDEOS.find((v) => v.id === vid) : null;

  return (
    <div className="absolute inset-0 overflow-y-auto text-white" style={{ background: "radial-gradient(ellipse at 50% -10%, #1c3bb0 0%, #0b1650 40%, #040818 100%)" }}>
      <div className="sticky top-0 z-20 flex items-center justify-between bg-gradient-to-b from-[#040818] to-transparent px-10 py-4">
        <div className="flex items-center gap-8">
          <app.Icon className="h-[3.2rem] w-[5.6rem] text-white" />
          <button onClick={() => { setVid(null); setFr("All"); }} className="text-[0.9rem] font-semibold tracking-widest text-white/90">HOME</button>
          {FRANCHISES.slice(1).map((f) => <button key={f.name} onClick={() => { setFr(f.name); setVid(null); }} className={`text-[0.9rem] font-semibold tracking-widest ${fr === f.name ? "text-white" : "text-white/55 hover:text-white"}`}>{f.name.toUpperCase()}</button>)}
        </div>
        <div className="flex items-center gap-4">
          <button onClick={() => { if (!openWindow(app.site!)) ctx.notify("Pop-up blocked"); }} className="flex items-center gap-2 rounded-full bg-white px-5 py-[0.45rem] text-[0.85rem] font-bold text-[#0b1650]"><ExternalLink className="h-4 w-4" /> Open Disney+</button>
          <button onClick={() => ctx.goHome()} className="glass flex items-center gap-2 rounded-full px-4 py-[0.45rem] text-[0.82rem] font-semibold"><Home className="h-4 w-4" /> Home</button>
          <UserChip name={auth.guest ? `${auth.name} (guest)` : auth.name} onOut={signOut} />
        </div>
      </div>

      {current ? (
        <div className="anim-fade-in px-10 pb-10">
          <button onClick={() => setVid(null)} className="mb-3 flex items-center gap-2 text-[0.9rem] text-white/70 hover:text-white"><ArrowLeft className="h-4 w-4" /> Back</button>
          <div className="mx-auto aspect-video w-full max-w-[64rem] overflow-hidden rounded-2xl bg-black shadow-2xl">
            <iframe title={current.title} src={`https://www.youtube-nocookie.com/embed/${current.id}?autoplay=1&rel=0`} allow="autoplay; encrypted-media; fullscreen; picture-in-picture" allowFullScreen className="h-full w-full border-0" />
          </div>
          <h2 className="mx-auto mt-5 max-w-[64rem] text-[1.7rem] font-semibold">{current.title}</h2>
          <p className="mx-auto max-w-[64rem] text-white/60">{current.franchise} · Official trailer · To watch the full movie or series, tap <b>Open Disney+</b>.</p>
        </div>
      ) : (
        <>
          <div className="relative mx-10 mt-2 overflow-hidden rounded-2xl" style={{ height: "21rem" }}>
            <img src={`https://i.ytimg.com/vi/${hero.id}/maxresdefault.jpg`} alt="" className="absolute inset-0 h-full w-full object-cover" />
            <div className="absolute inset-0 bg-gradient-to-r from-[#040818] via-[#040818]/60 to-transparent" />
            <div className="absolute bottom-8 left-10 max-w-[28rem]">
              <div className="text-[0.75rem] font-bold uppercase tracking-[0.3em] text-white/70">Featured trailer</div>
              <h2 className="mt-1 text-[2.8rem] font-bold leading-none" style={{ fontFamily: "Georgia, serif", fontStyle: "italic" }}>{hero.title}</h2>
              <div className="mt-5 flex gap-3">
                <button onClick={() => setVid(hero.id)} className="flex items-center gap-2 rounded-full bg-white px-7 py-3 font-bold text-[#0b1650]"><Play className="h-5 w-5 fill-[#0b1650]" /> Watch Trailer</button>
                <button onClick={() => { if (!openWindow(app.site!)) ctx.notify("Pop-up blocked"); }} className="flex items-center gap-2 rounded-full bg-white/20 px-6 py-3 font-semibold backdrop-blur"><Plus className="h-5 w-5" /> Full Catalog</button>
              </div>
            </div>
          </div>
          <div className="mx-10 mt-6 grid grid-cols-5 gap-4">
            {FRANCHISES.slice(1).concat([{ name: "National Geographic", bg: "linear-gradient(135deg,#7a5a00,#ffd23f)" }]).map((f) => (
              <button key={f.name} onClick={() => f.name === "National Geographic" ? (openWindow(app.site!) || ctx.notify("Pop-up blocked")) : setFr(f.name)} className={`flex h-[5.5rem] items-center justify-center rounded-xl text-[1.1rem] font-bold tracking-wide shadow-lg ring-2 transition-transform hover:scale-105 ${fr === f.name ? "ring-white" : "ring-white/20"}`} style={{ background: f.bg }}>{f.name}</button>
            ))}
          </div>
          <h3 className="mx-10 mt-8 text-[1.3rem] font-semibold">{fr === "All" ? "Trailers & Previews" : `${fr} Trailers`}</h3>
          <div className="mx-10 mt-3 grid grid-cols-3 gap-5 pb-12">
            {list.map((v) => (
              <button key={v.id} onClick={() => setVid(v.id)} className="group overflow-hidden rounded-xl bg-white/[0.07] text-left ring-2 ring-transparent transition-all hover:scale-[1.03] hover:ring-white">
                <div className="relative aspect-video">
                  <img src={`https://i.ytimg.com/vi/${v.id}/hqdefault.jpg`} alt="" className="h-full w-full object-cover" />
                  <div className="absolute inset-0 flex items-center justify-center bg-black/30 opacity-0 transition-opacity group-hover:opacity-100"><Play className="h-12 w-12 fill-white" /></div>
                </div>
                <div className="p-3"><div className="truncate text-[1rem] font-semibold">{v.title}</div><div className="text-[0.78rem] text-white/55">{v.franchise} · Trailer</div></div>
              </button>
            ))}
          </div>
        </>
      )}
    </div>
  );
}

/* ------------------------------------------------------------------ *
 *  Generic streaming service (Netflix, Twitch, Prime, …)
 * ------------------------------------------------------------------ */
export function GenericStreamApp({ app }: { app: AppDef }) {
  const ctx = useApp();
  const { auth, signIn, signOut } = useAuth(app.id);
  if (!auth.in) return <SignIn app={app} onDone={(n, g) => signIn(n, g)} />;
  const brand = app.brand ?? "#2e7bff";
  return (
    <div className="absolute inset-0 flex flex-col items-center justify-center text-center" style={{ background: `radial-gradient(ellipse at 50% 30%, ${brand}66, transparent 60%), #08080c` }}>
      <div className="absolute right-8 top-6"><UserChip name={auth.guest ? `${auth.name} (guest)` : auth.name} onOut={signOut} /></div>
      <button onClick={() => ctx.goHome()} className="glass absolute left-6 top-5 flex items-center gap-2 rounded-full px-4 py-[0.45rem] text-[0.82rem] font-semibold"><Home className="h-4 w-4" /> Home</button>
      <div className="anim-pop flex h-[11rem] w-[11rem] items-center justify-center rounded-[2rem] shadow-2xl" style={{ background: app.bg, color: app.fg }}><app.Icon className="h-[6.4rem] w-[6.4rem]" /></div>
      <h1 className="mt-6 text-[2.3rem] font-semibold">Welcome back, {auth.name}</h1>
      <p className="mt-2 max-w-[34rem] text-[1rem] leading-relaxed text-white/60">{app.name} plays best in its own full window. Launch it now — it opens with your signed-in session.</p>
      <div className="mt-8 flex gap-4">
        <button onClick={() => { sfx.select(); if (!openWindow(app.site!)) ctx.notify("Pop-up blocked — allow pop-ups"); }} className="flex items-center gap-2 rounded-full bg-white px-8 py-[0.85rem] text-[1.05rem] font-bold text-black"><ExternalLink className="h-5 w-5" /> Launch {app.name}</button>
        <button onClick={() => ctx.openApp("browser")} className="flex items-center gap-2 rounded-full bg-white/12 px-7 py-[0.85rem] text-[1rem] font-semibold"><Globe className="h-5 w-5" /> Web Browser</button>
      </div>
    </div>
  );
}
