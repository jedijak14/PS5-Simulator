import { useRef, useState, type ReactNode } from "react";
import { ArrowLeft, BookOpen, Clapperboard, Gamepad2, Globe, Home, Keyboard, Layers, Music2, Palette, Settings2, ShieldCheck, ShoppingBag, Users, Wrench, HardDrive } from "lucide-react";
import { useApp } from "../lib/ctx";
import { useNav } from "../lib/useNav";
import { sfx } from "../lib/sfx";
import { Hint, HintBar } from "./ui";

const K = ({ children }: { children: ReactNode }) => <span className="keycap mx-[0.15rem]">{children}</span>;
const P = ({ children }: { children: ReactNode }) => <p className="mb-4 text-[1rem] leading-[1.7] text-white/80">{children}</p>;
const H = ({ children }: { children: ReactNode }) => <h3 className="mb-2 mt-6 text-[1.15rem] font-semibold text-white">{children}</h3>;
const Li = ({ children }: { children: ReactNode }) => <li className="mb-2 leading-relaxed text-white/80">{children}</li>;

const SECTIONS: { id: string; title: string; icon: ReactNode; body: ReactNode }[] = [
  {
    id: "welcome", title: "Welcome", icon: <BookOpen className="h-5 w-5" />,
    body: (
      <>
        <P>This simulator recreates the feel of a PlayStation 5 console in your browser: a Home screen with Games and Media, a PlayStation Store, user profiles, themes, settings, a web browser, streaming apps and playable games.</P>
        <P>You can use your <b>keyboard</b> or your <b>mouse</b> for everything. Everything you change — users, themes, wallpapers, installed games and apps, bookmarks, sign-ins — is saved automatically on this device, and you can erase it any time from <b>Settings → Saved Data and Storage</b>.</P>
        <H>Quick start</H>
        <ol className="ml-5 list-decimal">
          <Li>Choose a user on the <b>Who's Playing?</b> screen (or add your own).</Li>
          <Li>Open the <b>PlayStation Store</b> from the Media tab and download games or apps like Spotify, YouTube and Disney+.</Li>
          <Li>Press <K>F1</K> any time to open the Control Center.</Li>
          <Li>Pick a new look in <b>Settings → Themes</b>.</Li>
        </ol>
      </>
    ),
  },
  {
    id: "controls", title: "Controls", icon: <Keyboard className="h-5 w-5" />,
    body: (
      <>
        <P>The keyboard mimics a controller:</P>
        <div className="grid grid-cols-2 gap-x-8 gap-y-3 text-[0.95rem]">
          {[
            [<><K>↑</K><K>↓</K><K>←</K><K>→</K> / <K>W</K><K>A</K><K>S</K><K>D</K></>, "Move the focus (D-pad)"],
            [<K>Enter</K>, "Select  ✕"],
            [<><K>Esc</K> / <K>Backspace</K></>, "Back  ○"],
            [<><K>Tab</K> / <K>O</K></>, "Options  △"],
            [<><K>F1</K> / <K>Home</K></>, "PS button — Control Center"],
            [<K>Mouse</K>, "Click anything, hover to focus"],
          ].map(([k, v], i) => (
            <div key={i} className="flex items-center justify-between rounded-xl bg-white/[0.06] px-4 py-3"><span>{k}</span><span className="text-white/65">{v as string}</span></div>
          ))}
        </div>
        <P>&nbsp;</P>
        <P>Inside web pages, videos and games, the keyboard goes to that content. A small <b>PS button</b> in the bottom-left corner is always available with your mouse so you can open the Control Center.</P>
      </>
    ),
  },
  {
    id: "home", title: "The Home Screen", icon: <Home className="h-5 w-5" />,
    body: (
      <>
        <P>The Home screen has two tabs. <b>Games</b> shows your library — the most recently played comes first. <b>Media</b> holds your apps: PlayStation Store, Web Browser, Media Player, this guide, and any streaming apps you've installed.</P>
        <P>Move up to the top bar to switch tabs, open <b>Settings</b>, or open your user menu (switch user, restart). Press <K>Tab</K> on a tile for <b>Options</b>: resume, close, or delete.</P>
        <H>Ambient music</H>
        <P>The Home screen has gentle generative background music. Each theme has its own mood — calm, tense, playful, epic, retro or cosmic. Change it in <b>Settings → Sound</b>. Entering a game plays a start-up sound.</P>
      </>
    ),
  },
  {
    id: "bg", title: "Background Apps & Games", icon: <Layers className="h-5 w-5" />,
    body: (
      <>
        <P>Leaving a game or app does <b>not</b> close it. Press <K>F1</K> (or the PS button) and choose <b>Go to Home</b> — the game, browser tab, Spotify or YouTube keeps running behind the Home screen. Running items show a <b>Running</b> badge, and the Control Center lists them so you can switch back instantly or close them.</P>
        <P>Games stay in memory, so you'll resume exactly where you left off. Apps like Spotify keep playing music while you browse the Home screen. When something is playing in the background, the Home ambient music pauses so they don't overlap.</P>
        <H>Closing things</H>
        <ul className="ml-5 list-disc"><Li>Control Center → the <b>✕</b> on a running card.</Li><Li>Home → <K>Tab</K> on a running tile → <b>Close</b>.</Li></ul>
      </>
    ),
  },
  {
    id: "profiles", title: "Users & Profiles", icon: <Users className="h-5 w-5" />,
    body: (
      <>
        <P>On start-up you choose who's playing. Each user has their own name, avatar, theme, wallpaper, browser bookmarks, YouTube favorites and streaming sign-ins.</P>
        <ul className="ml-5 list-disc">
          <Li>Press <K>Tab</K> on a user to edit or delete them, or choose <b>Add User</b>.</Li>
          <Li>Pick from 36 avatars. You can clear and retype your name freely — it only saves when you confirm.</Li>
          <Li>Switch users any time from the Home profile menu or Control Center.</Li>
        </ul>
      </>
    ),
  },
  {
    id: "themes", title: "Themes & Wallpapers", icon: <Palette className="h-5 w-5" />,
    body: (
      <>
        <P>Open <b>Settings → Themes</b> to choose a look. Themes change the wallpaper, animated effects (spores, snow, rain, leaves, confetti…), icon style, fonts, corner shapes and the Home music.</P>
        <ul className="ml-5 list-disc">
          <Li><b>PlayStation Games:</b> The Last of Us, Astro Bot, God of War, Marvel's Spider-Man, Ghost of Tsushima, Horizon, Gran Turismo, Bloodborne, Ratchet &amp; Clank.</Li>
          <Li><b>PlayStation Heritage:</b> Shapes, PlayStation 1, 2, 3 and 4 inspired looks.</Li>
          <Li>Move your mouse over the wallpaper — particles react to it.</Li>
        </ul>
        <H>Upload your own wallpaper</H>
        <P>Go to <b>Settings → Wallpapers</b>, choose <b>Upload wallpaper</b> and pick any image. It's saved on the device, and you can switch back to the theme's wallpaper at any time.</P>
      </>
    ),
  },
  {
    id: "store", title: "PlayStation Store", icon: <ShoppingBag className="h-5 w-5" />,
    body: (
      <>
        <P>The Store has a collection of free web games and entertainment apps. Select an item to see its page, then choose <b>Download</b>. When it finishes it appears on your Home screen.</P>
        <ul className="ml-5 list-disc">
          <Li><b>Games:</b> Hextris, 2048, Pac-Man, HexGL, Space Invaders, Celeste Classic and more.</Li>
          <Li><b>Apps:</b> every streaming service — Spotify, YouTube, Disney+, Netflix, Twitch, Prime Video, Apple TV, Max, Hulu, Crunchyroll, Paramount+, Plex, YouTube Music and Apple Music.</Li>
          <Li>Delete installed items from the Store page or from Home with <K>Tab</K>.</Li>
        </ul>
        <P>Games from the web load from their original websites, so an internet connection is required.</P>
      </>
    ),
  },
  {
    id: "stream", title: "Streaming Apps", icon: <Music2 className="h-5 w-5" />,
    body: (
      <>
        <H>Spotify</H>
        <P>Opens full screen on a sign-in page. Choose <b>Sign in with Spotify</b> — the official Spotify login opens in its own secure window. Once you're signed in, pick a playlist or paste any Spotify link and listen in the player. Music keeps playing when you go Home.</P>
        <H>YouTube</H>
        <P>Browse featured videos, search, paste a video link, save favorites and see your history. No sign-in needed.</P>
        <H>Disney+ and other services</H>
        <P>Sign in through the official page, then browse trailers inside the app and launch the full service in its own window. Streaming services restrict where their full players can be embedded, so they open in a real browser window for playback.</P>
      </>
    ),
  },
  {
    id: "browser", title: "Web Browser", icon: <Globe className="h-5 w-5" />,
    body: (
      <>
        <P>A Chromium-style browser with tabs, an address bar, back/forward, bookmarks and history. Type a web address or a search and press <K>Enter</K>.</P>
        <P>Many big websites forbid being displayed inside another page. When that happens you'll see a "refused to connect" page — use <b>Open in new window</b> (also in the toolbar) to open it in a full browser window, or try the archived copy. Wikipedia, Internet Archive, Project Gutenberg, IGN and many others load right inside.</P>
      </>
    ),
  },
  {
    id: "media", title: "Media Player", icon: <Clapperboard className="h-5 w-5" />,
    body: <P>Add audio, video or photos from your device and play them on the big screen with a visualizer. Files are available while the app is open.</P>,
  },
  {
    id: "games", title: "Games", icon: <Gamepad2 className="h-5 w-5" />,
    body: (
      <>
        <P>Two games come pre-installed: <b>Starfall</b> and <b>Neon Serpent</b>. You can bring your own: choose <b>Add Your Own Game</b> at the end of the Games row, pick an HTML game file and optionally add cover, background and logo artwork.</P>
        <P>Play time and last-played are tracked per game. Games run in a sandboxed frame; press <K>F1</K> to leave without quitting.</P>
      </>
    ),
  },
  {
    id: "parental", title: "Parental Controls", icon: <ShieldCheck className="h-5 w-5" />,
    body: (
      <>
        <P>In <b>Settings → Family and Parental Controls</b> you can turn restrictions on, set a PIN (default <b>0000</b>), choose an age-rating limit, and block the browser, the Store, streaming apps or uploads.</P>
        <P>Restrictions only apply to users marked as a <b>Child account</b> in Users and Accounts. Turning off the child flag or changing the settings requires the PIN.</P>
      </>
    ),
  },
  {
    id: "data", title: "Saved Data", icon: <HardDrive className="h-5 w-5" />,
    body: (
      <>
        <P>Your data lives in your browser's local storage and IndexedDB on this device. Nothing is sent anywhere. In <b>Settings → Saved Data and Storage</b> you can delete all games, wallpapers, browser data, app sign-ins or erase everything for a factory reset.</P>
      </>
    ),
  },
  {
    id: "help", title: "Troubleshooting", icon: <Wrench className="h-5 w-5" />,
    body: (
      <>
        <ul className="ml-5 list-disc">
          <Li><b>No sound:</b> browsers wait for your first click or key press before playing audio. Press any key, then check Settings → Sound.</Li>
          <Li><b>A game or website shows blank:</b> that site may block embedding. Use the “Open in new window” button.</Li>
          <Li><b>Pop-up blocked:</b> allow pop-ups for this page so sign-in windows can open.</Li>
          <Li><b>Looks too big or small:</b> the interface scales with the window. Use fullscreen from the Control Center.</Li>
          <Li><b>Forgot the PIN?</b> Erase everything in Settings → Saved Data and Storage (this needs the PIN only for parental settings).</Li>
        </ul>
        <div className="mt-6 flex items-center gap-2 text-white/40"><Settings2 className="h-4 w-4" /> Version 11.20.00 · PS5 Simulator</div>
      </>
    ),
  },
];

export default function Guide({ active }: { active: boolean }) {
  const ctx = useApp();
  const [sel, setSel] = useState(0);
  const body = useRef<HTMLDivElement>(null);
  const s = SECTIONS[sel];
  const choose = (i: number) => { setSel(i); body.current?.scrollTo({ top: 0 }); sfx.move(); };

  useNav((a) => {
    if (a === "up" && sel > 0) choose(sel - 1);
    else if (a === "down" && sel < SECTIONS.length - 1) choose(sel + 1);
    else if (a === "right") body.current?.scrollBy({ top: 160, behavior: "smooth" });
    else if (a === "left") body.current?.scrollBy({ top: -160, behavior: "smooth" });
    else if (a === "back") { sfx.back(); ctx.goHome(); }
  }, active);

  return (
    <div className="absolute inset-0 flex flex-col bg-[#071311]/80 text-white backdrop-blur-2xl">
      <div className="absolute inset-0" style={{ background: "radial-gradient(ellipse at 80% 0%, rgba(20,184,166,.25), transparent 60%)" }} />
      <div className="relative z-10 flex items-center gap-4 px-[4rem] pb-3 pt-[1.8rem]">
        <button onClick={() => ctx.goHome()} className="flex h-10 w-10 items-center justify-center rounded-full bg-white/10 hover:bg-white/20"><ArrowLeft className="h-5 w-5" /></button>
        <div className="flex h-[2.6rem] w-[2.6rem] items-center justify-center rounded-full bg-[#14b8a6]"><BookOpen className="h-[1.5rem] w-[1.5rem]" /></div>
        <div><h1 className="text-[1.7rem] font-semibold leading-tight">User's Guide</h1><div className="text-[0.82rem] text-white/50">Learn how to use the simulator</div></div>
      </div>
      <div className="relative z-10 flex min-h-0 flex-1 gap-8 px-[4rem] pb-[3.5rem] pt-2">
        <nav className="no-scrollbar flex w-[17rem] shrink-0 flex-col gap-1 overflow-y-auto">
          {SECTIONS.map((x, i) => (
            <button key={x.id} onClick={() => choose(i)} className={`flex items-center gap-3 rounded-xl px-4 py-[0.7rem] text-left text-[0.95rem] font-medium transition-all ${i === sel ? "bg-white text-black shadow-lg" : "text-white/70 hover:bg-white/10"}`}>
              {x.icon}{x.title}
            </button>
          ))}
        </nav>
        <div ref={body} key={s.id} className="no-scrollbar anim-fade-in min-w-0 flex-1 overflow-y-auto rounded-[1.4rem] bg-white/[0.06] p-8 ring-1 ring-white/10" style={{ animationDuration: "0.3s" }}>
          <h2 className="mb-5 flex items-center gap-3 text-[1.9rem] font-semibold">{s.icon}{s.title}</h2>
          {s.body}
        </div>
      </div>
      <HintBar show={ctx.settings.hints && active}>
        <Hint k="↑↓">Section</Hint>
        <Hint k="←→">Scroll</Hint>
        <Hint k="Esc" glyph="circle">Home</Hint>
      </HintBar>
    </div>
  );
}
