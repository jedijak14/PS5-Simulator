import { useEffect, useRef, useState } from "react";
import { ExternalLink } from "lucide-react";
import type { Game } from "../types";
import { addPlaytime } from "../lib/store";
import { sfx } from "../lib/sfx";
import { Spinner } from "./ui";

/* Injected into every built-in game: PS button (F1) bridge + background audio control. */
const BRIDGE =
  "<script>(function(){var cs=[];var AC=window.AudioContext||window.webkitAudioContext;" +
  "if(AC){var P=class extends AC{constructor(o){super(o);cs.push(this)}};window.AudioContext=P;window.webkitAudioContext=P}" +
  'addEventListener("message",function(e){var d=e.data;if(d&&typeof d.ps5bg==="boolean"){cs.forEach(function(c){try{d.ps5bg?c.suspend():c.resume()}catch(_){}});' +
  'document.querySelectorAll("audio,video").forEach(function(m){if(d.ps5bg){m.dataset.wasPlaying=m.paused?"":"1";m.pause()}else if(m.dataset.wasPlaying){m.play()}})}});' +
  'addEventListener("keydown",function(e){if(e.key==="F1"){e.preventDefault();e.stopPropagation();parent.postMessage({ps5:"ps"},"*")}},true)})();<' +
  "/script>";

function inject(html: string): string {
  const m = html.match(/<head[^>]*>/i) || html.match(/<html[^>]*>/i);
  if (m && m.index !== undefined) {
    const at = m.index + m[0].length;
    return html.slice(0, at) + BRIDGE + html.slice(at);
  }
  const dt = html.match(/<!doctype[^>]*>/i);
  if (dt && dt.index !== undefined) {
    const at = dt.index + dt[0].length;
    return html.slice(0, at) + BRIDGE + html.slice(at);
  }
  return BRIDGE + html;
}

/** A running game. Stays mounted while you're on the Home screen so it keeps running in the background. */
export default function GameRunner({ game, active, launchSound, onPS }: { game: Game; active: boolean; launchSound: boolean; onPS: () => void }) {
  const [mounted, setMounted] = useState(false);
  const [splash, setSplash] = useState<"show" | "fade" | "gone">("show");
  const [tip, setTip] = useState(false);
  const frame = useRef<HTMLIFrameElement>(null);
  const activeSince = useRef(0);
  const onPSRef = useRef(onPS);
  onPSRef.current = onPS;
  const activeRef = useRef(active);
  activeRef.current = active;

  const flush = () => {
    if (activeSince.current) {
      const s = Math.round((Date.now() - activeSince.current) / 1000);
      if (s > 0) addPlaytime(game.id, s);
      activeSince.current = activeRef.current ? Date.now() : 0;
    }
  };

  useEffect(() => {
    if (launchSound) sfx.gameStart();
    const t1 = window.setTimeout(() => setMounted(true), 2300);
    const t2 = window.setTimeout(() => setSplash("fade"), 2700);
    const t3 = window.setTimeout(() => { setSplash("gone"); setTip(true); }, 3500);
    const t4 = window.setTimeout(() => setTip(false), 8500);
    const onMsg = (e: MessageEvent) => {
      if (e.data && e.data.ps5 === "ps" && activeRef.current) onPSRef.current();
    };
    window.addEventListener("message", onMsg);
    const tick = window.setInterval(flush, 30000);
    return () => {
      [t1, t2, t3, t4].forEach(clearTimeout);
      clearInterval(tick);
      window.removeEventListener("message", onMsg);
      const was = activeSince.current;
      if (was) addPlaytime(game.id, Math.round((Date.now() - was) / 1000));
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [game.id]);

  useEffect(() => {
    if (active) {
      activeSince.current = Date.now();
      frame.current?.contentWindow?.postMessage({ ps5bg: false }, "*");
      if (mounted) {
        const t = window.setTimeout(() => { frame.current?.focus(); frame.current?.contentWindow?.focus(); }, 60);
        return () => clearTimeout(t);
      }
    } else {
      flush();
      activeSince.current = 0;
      frame.current?.contentWindow?.postMessage({ ps5bg: true }, "*");
      (document.activeElement as HTMLElement | null)?.blur();
      window.focus();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [active, mounted]);

  return (
    <div className="absolute inset-0 bg-black">
      {mounted && (
        <iframe
          ref={frame}
          title={game.title}
          {...(game.url ? { src: game.url } : { srcDoc: inject(game.html) })}
          sandbox="allow-scripts allow-same-origin allow-pointer-lock allow-forms allow-modals allow-popups allow-popups-to-escape-sandbox allow-downloads"
          allow="autoplay; fullscreen; gamepad; clipboard-write; accelerometer; gyroscope"
          className="anim-fade-in absolute inset-0 h-full w-full border-0 bg-black"
          onLoad={() => {
            frame.current?.focus();
            frame.current?.contentWindow?.focus();
            if (!activeRef.current) frame.current?.contentWindow?.postMessage({ ps5bg: true }, "*");
          }}
        />
      )}

      {game.url && splash === "gone" && active && (
        <div className="group absolute inset-x-0 top-0 z-20 flex h-[3.4rem] justify-end px-4 pt-3">
          <a
            href={game.url}
            target="_blank"
            rel="noreferrer"
            className="flex h-fit items-center gap-2 rounded-full bg-black/70 px-4 py-[0.4rem] text-[0.8rem] font-medium text-white/90 opacity-0 backdrop-blur-md transition-opacity hover:bg-black/85 group-hover:opacity-100"
          >
            <ExternalLink className="h-4 w-4" /> Not loading? Open in new window
          </a>
        </div>
      )}

      {splash !== "gone" && (
        <div className={`absolute inset-0 z-10 overflow-hidden bg-black transition-opacity duration-[800ms] ${splash === "fade" ? "opacity-0" : "opacity-100"}`}>
          <img src={game.background} alt="" className="absolute inset-0 h-full w-full object-cover" style={{ animation: "zoom-slow 6s ease-out both" }} />
          <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,rgba(0,0,0,0.1),rgba(0,0,0,0.75))]" />
          <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-transparent to-black/40" />
          <div className="absolute inset-0 flex items-center justify-center">
            <img src={game.logo} alt={game.title} className="max-h-[14rem] max-w-[34rem] object-contain drop-shadow-[0_0.5rem_2rem_rgba(0,0,0,0.7)]" style={{ animation: "logo-in 1.2s cubic-bezier(.2,.8,.2,1) 0.25s both" }} />
          </div>
          <div className="anim-fade-in absolute bottom-[2.4rem] right-[3.2rem] flex items-center gap-4" style={{ animationDelay: "0.6s" }}>
            <span className="text-[0.95rem] font-medium text-white/80">Starting {game.title}…</span>
            <Spinner />
          </div>
        </div>
      )}

      {tip && active && (
        <div className="anim-fade-in pointer-events-none absolute bottom-[2rem] left-1/2 z-20 flex -translate-x-1/2 items-center gap-3 rounded-full bg-black/60 px-5 py-[0.55rem] text-[0.85rem] text-white/90 backdrop-blur-md">
          Press <span className="keycap">F1</span> or click the PS button to open the Control Center — your game keeps running in the background
        </div>
      )}
    </div>
  );
}
