import { useEffect, useRef, useState } from "react";
import { ArrowLeft, Clock, ExternalLink, Heart, Home, Loader2, Search, Trash2 } from "lucide-react";
import type { AppDef } from "../lib/apps";
import { useApp } from "../lib/ctx";
import { YT_VIDEOS, type Vid } from "../lib/catalog";
import { pget, pset } from "../lib/store";
import { openWindow } from "../lib/popup";
import { sfx } from "../lib/sfx";

const PIPED = ["https://api.piped.private.coffee", "https://pipedapi.kavin.rocks", "https://pipedapi.adminforge.de", "https://api.piped.yt"];

async function searchVideos(q: string): Promise<Vid[]> {
  for (const base of PIPED) {
    try {
      const ctl = new AbortController();
      const t = window.setTimeout(() => ctl.abort(), 7000);
      const r = await fetch(`${base}/search?q=${encodeURIComponent(q)}&filter=videos`, { signal: ctl.signal });
      clearTimeout(t);
      if (!r.ok) continue;
      const j = (await r.json()) as { items?: { url: string; title: string; uploaderName?: string; type?: string }[] };
      const out: Vid[] = (j.items ?? [])
        .filter((i) => i.url?.includes("watch?v="))
        .map((i) => ({ id: i.url.split("v=")[1].slice(0, 11), title: i.title, channel: i.uploaderName ?? "YouTube", cat: "Search" }));
      if (out.length) return out;
    } catch {
      /* try next */
    }
  }
  throw new Error("search unavailable");
}

const parseId = (s: string) => s.match(/(?:v=|youtu\.be\/|embed\/|shorts\/|live\/)([\w-]{11})/)?.[1] ?? (/^[\w-]{11}$/.test(s.trim()) ? s.trim() : null);
const CATS = ["All", "PlayStation", "Movies", "Music", "Relax & Live", "Favorites", "History"];

export default function YouTube({ app }: { app: AppDef }) {
  const ctx = useApp();
  const pid = ctx.profile.id;
  const [cat, setCat] = useState("All");
  const [q, setQ] = useState("");
  const [results, setResults] = useState<Vid[] | null>(null);
  const [busy, setBusy] = useState(false);
  const [msg, setMsg] = useState("");
  const [now, setNow] = useState<Vid | null>(null);
  const [favs, setFavs] = useState<Vid[]>(() => pget(pid, "yt.favs", [] as Vid[]));
  const [hist, setHist] = useState<Vid[]>(() => pget(pid, "yt.hist", [] as Vid[]));
  const seq = useRef(0);

  useEffect(() => { pset(pid, "yt.favs", favs); }, [favs, pid]);
  useEffect(() => { pset(pid, "yt.hist", hist.slice(0, 40)); }, [hist, pid]);

  const play = (v: Vid) => {
    sfx.select();
    setNow(v);
    setHist((h) => [v, ...h.filter((x) => x.id !== v.id)].slice(0, 40));
  };

  const submit = async () => {
    const text = q.trim();
    if (!text) return;
    const id = parseId(text);
    if (id) {
      play({ id, title: "YouTube video", channel: "YouTube", cat: "Link" });
      setQ("");
      return;
    }
    const my = ++seq.current;
    setBusy(true);
    setMsg("");
    setNow(null);
    try {
      const r = await searchVideos(text);
      if (my === seq.current) setResults(r);
    } catch {
      if (my === seq.current) {
        const local = YT_VIDEOS.filter((v) => (v.title + v.channel).toLowerCase().includes(text.toLowerCase()));
        setResults(local);
        setMsg(local.length ? "Live search is unavailable right now — showing matching featured videos." : "Live search is unavailable right now. Try pasting a YouTube link, or browse the featured videos.");
      }
    }
    if (my === seq.current) setBusy(false);
  };

  const fav = (v: Vid) => (favs.some((f) => f.id === v.id) ? setFavs((f) => f.filter((x) => x.id !== v.id)) : setFavs((f) => [v, ...f]));
  const isFav = (v: Vid) => favs.some((f) => f.id === v.id);

  const base = cat === "Favorites" ? favs : cat === "History" ? hist : cat === "All" ? YT_VIDEOS : YT_VIDEOS.filter((v) => v.cat === cat);
  const list = results ?? base;

  const Card = ({ v }: { v: Vid }) => (
    <div className="group relative text-left">
      <button onClick={() => play(v)} className="block w-full text-left">
        <div className="relative aspect-video overflow-hidden rounded-xl bg-[#222]">
          <img src={`https://i.ytimg.com/vi/${v.id}/hqdefault.jpg`} alt="" loading="lazy" className="h-full w-full object-cover transition-transform duration-300 group-hover:scale-105" />
        </div>
        <div className="mt-2 line-clamp-2 text-[0.92rem] font-semibold leading-snug">{v.title}</div>
        <div className="text-[0.76rem] text-white/55">{v.channel}</div>
      </button>
      <button onClick={() => fav(v)} className="absolute right-2 top-2 flex h-8 w-8 items-center justify-center rounded-full bg-black/65 opacity-0 transition-opacity group-hover:opacity-100"><Heart className={`h-4 w-4 ${isFav(v) ? "fill-[#ff3b4e] text-[#ff3b4e]" : ""}`} /></button>
    </div>
  );

  return (
    <div className="absolute inset-0 flex flex-col bg-[#0f0f0f] text-white">
      <div className="flex shrink-0 items-center gap-6 px-6 py-3">
        <button onClick={() => { setNow(null); setResults(null); setMsg(""); setQ(""); }} className="flex items-center gap-2 text-[1.35rem] font-bold tracking-tight"><app.Icon className="h-9 w-9 text-[#ff0000]" /> YouTube</button>
        <form onSubmit={(e) => { e.preventDefault(); void submit(); }} className="mx-auto flex h-[2.5rem] w-[40rem] items-center overflow-hidden rounded-full bg-[#121212] ring-1 ring-white/20 focus-within:ring-[#3ea6ff]">
          <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search YouTube or paste a video link" className="h-full flex-1 bg-transparent px-5 text-[0.95rem] outline-none placeholder:text-white/40" />
          <button type="submit" className="flex h-full w-[4rem] items-center justify-center bg-white/10 hover:bg-white/20">{busy ? <Loader2 className="h-5 w-5 animate-spin" /> : <Search className="h-5 w-5" />}</button>
        </form>
        <button onClick={() => ctx.goHome()} className="glass flex items-center gap-2 rounded-full px-4 py-[0.45rem] text-[0.82rem] font-semibold"><Home className="h-4 w-4" /> Home</button>
      </div>

      {now ? (
        <div className="flex min-h-0 flex-1 gap-6 px-6 pb-6">
          <div className="flex min-w-0 flex-1 flex-col">
            <button onClick={() => setNow(null)} className="mb-2 flex w-fit items-center gap-2 text-[0.85rem] text-white/70 hover:text-white"><ArrowLeft className="h-4 w-4" /> Back to browsing</button>
            <div className="relative min-h-0 flex-1 overflow-hidden rounded-2xl bg-black">
              <iframe key={now.id} title={now.title} src={`https://www.youtube-nocookie.com/embed/${now.id}?autoplay=1&rel=0&modestbranding=1`} allow="autoplay; encrypted-media; fullscreen; picture-in-picture; clipboard-write" allowFullScreen className="absolute inset-0 h-full w-full border-0" />
            </div>
            <div className="mt-3 flex items-start justify-between gap-6">
              <div className="min-w-0"><h2 className="truncate text-[1.25rem] font-semibold">{now.title}</h2><div className="text-[0.85rem] text-white/55">{now.channel}</div></div>
              <div className="flex shrink-0 gap-2">
                <button onClick={() => fav(now)} className={`flex items-center gap-2 rounded-full px-4 py-2 text-[0.85rem] font-semibold ${isFav(now) ? "bg-white text-black" : "bg-white/10"}`}><Heart className={`h-4 w-4 ${isFav(now) ? "fill-[#ff3b4e] text-[#ff3b4e]" : ""}`} />{isFav(now) ? "Saved" : "Save"}</button>
                <button onClick={() => openWindow(`https://www.youtube.com/watch?v=${now.id}`)} className="flex items-center gap-2 rounded-full bg-white/10 px-4 py-2 text-[0.85rem] font-semibold"><ExternalLink className="h-4 w-4" /> YouTube</button>
              </div>
            </div>
          </div>
          <div className="no-scrollbar flex w-[21rem] shrink-0 flex-col gap-3 overflow-y-auto">
            <div className="text-[0.75rem] font-semibold uppercase tracking-widest text-white/45">Up next</div>
            {(YT_VIDEOS.filter((v) => v.id !== now.id)).slice(0, 12).map((v) => (
              <button key={v.id} onClick={() => play(v)} className="flex gap-3 text-left">
                <img src={`https://i.ytimg.com/vi/${v.id}/mqdefault.jpg`} alt="" className="aspect-video w-[9rem] shrink-0 rounded-lg object-cover" />
                <div className="min-w-0"><div className="line-clamp-2 text-[0.82rem] font-semibold leading-snug">{v.title}</div><div className="mt-1 text-[0.7rem] text-white/50">{v.channel}</div></div>
              </button>
            ))}
          </div>
        </div>
      ) : (
        <>
          <div className="no-scrollbar flex shrink-0 gap-2 overflow-x-auto px-6 pb-3">
            {CATS.map((c) => (
              <button key={c} onClick={() => { setCat(c); setResults(null); setMsg(""); }} className={`shrink-0 rounded-lg px-4 py-[0.4rem] text-[0.88rem] font-medium ${cat === c && !results ? "bg-white text-black" : "bg-white/10 hover:bg-white/20"}`}>{c === "History" && <Clock className="mr-1 inline h-3.5 w-3.5" />}{c}</button>
            ))}
            {cat === "History" && hist.length > 0 && !results && <button onClick={() => setHist([])} className="ml-auto flex shrink-0 items-center gap-2 rounded-lg bg-white/10 px-4 py-[0.4rem] text-[0.82rem]"><Trash2 className="h-3.5 w-3.5" /> Clear history</button>}
          </div>
          {msg && <div className="mx-6 mb-2 rounded-lg bg-white/10 px-4 py-2 text-[0.82rem] text-white/70">{msg}</div>}
          {results && <div className="mx-6 mb-2 text-[0.85rem] text-white/60">{busy ? "Searching…" : `Results for "${q || "search"}"`}</div>}
          <div className="no-scrollbar min-h-0 flex-1 overflow-y-auto px-6 pb-8">
            {list.length === 0 ? (
              <div className="mt-20 text-center text-white/45">{cat === "Favorites" ? "No favorites yet — hover a video and tap the heart." : cat === "History" ? "Nothing watched yet." : "No videos found."}</div>
            ) : (
              <div className="grid grid-cols-4 gap-x-5 gap-y-7">{list.map((v) => <Card key={v.id + v.cat} v={v} />)}</div>
            )}
          </div>
        </>
      )}
    </div>
  );
}
