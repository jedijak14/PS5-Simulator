import type { Game } from "../types";
import { buildArt } from "./art";

type Motif = NonNullable<NonNullable<Parameters<typeof buildArt>[1]>["motif"]>;

interface Def {
  id: string;
  title: string;
  url: string;
  genre: string;
  rating: number;
  desc: string;
  hueA: number;
  hueB: number;
  motif: Motif;
}

const DEFS: Def[] = [
  { id: "web-hextris", title: "Hextris", url: "https://hextris.io/", genre: "Puzzle", rating: 3, desc: "Fast-paced hexagonal puzzle inspired by Tetris. Rotate the hexagon to match colors before the stack overflows.", hueA: 200, hueB: 320, motif: "abstract" },
  { id: "web-2048", title: "2048", url: "https://gabrielecirulli.github.io/2048/", genre: "Puzzle", rating: 3, desc: "Slide numbered tiles and combine them to reach the 2048 tile. Simple to learn, hard to master.", hueA: 35, hueB: 15, motif: "grid" },
  { id: "web-dino", title: "T-Rex Runner", url: "https://wayou.github.io/t-rex-runner/", genre: "Runner", rating: 3, desc: "The classic offline dinosaur run. Jump cacti, duck pterodactyls, beat your best distance.", hueA: 150, hueB: 190, motif: "waves" },
  { id: "web-tetris", title: "React Tetris", url: "https://chvin.github.io/react-tetris/", genre: "Puzzle", rating: 3, desc: "A polished, faithful take on Tetris with ghost pieces, hold-free scoring and neat sound effects.", hueA: 260, hueB: 200, motif: "grid" },
  { id: "web-pacman", title: "Pac-Man Canvas", url: "https://pacman.platzh1rsch.ch/", genre: "Arcade", rating: 3, desc: "Munch the dots, avoid the ghosts. A canvas recreation of the arcade legend.", hueA: 55, hueB: 270, motif: "grid" },
  { id: "web-invaders", title: "Space Invaders", url: "https://freeinvaders.org/", genre: "Arcade", rating: 7, desc: "Defend Earth from descending waves of retro aliens.", hueA: 120, hueB: 180, motif: "space" },
  { id: "web-hexgl", title: "HexGL", url: "https://hexgl.bkcore.com/play/", genre: "Racing", rating: 7, desc: "A futuristic anti-gravity racer built with WebGL. Chase the best lap time through neon tracks.", hueA: 195, hueB: 300, motif: "space" },
  { id: "web-ztype", title: "ZType", url: "https://zty.pe/", genre: "Shooter", rating: 7, desc: "Destroy enemy ships by typing their names. A typing shooter with a driving soundtrack.", hueA: 20, hueB: 340, motif: "space" },
  { id: "web-celeste", title: "Celeste Classic", url: "https://www.lexaloffle.com/bbs/widget.php?pid=celeste_classic", genre: "Platformer", rating: 7, desc: "The original PICO-8 prototype of Celeste. Climb the mountain, one pixel-perfect jump at a time.", hueA: 340, hueB: 220, motif: "waves" },
  { id: "web-swooop", title: "Swooop", url: "https://playcanv.as/p/MflWvdTW/", genre: "Flight", rating: 3, desc: "Soar through a bright low-poly sky, collecting fuel and dodging obstacles.", hueA: 190, hueB: 40, motif: "waves" },
  { id: "web-darkroom", title: "A Dark Room", url: "https://adarkroom.doublespeakgames.com/", genre: "Adventure", rating: 12, desc: "A minimalist text adventure. Stoke the fire, gather wood and discover what waits in the dark.", hueA: 20, hueB: 0, motif: "abstract" },
  { id: "web-cube", title: "The Cube", url: "https://bsehovac.github.io/the-cube/", genre: "Puzzle", rating: 3, desc: "A beautiful, fully 3D Rubik's-style cube you can twist, scramble and solve.", hueA: 15, hueB: 220, motif: "grid" },
  { id: "web-alchemy", title: "Little Alchemy 2", url: "https://littlealchemy2.com/", genre: "Puzzle", rating: 3, desc: "Combine elements to discover over 700 new items, from life to the universe.", hueA: 280, hueB: 170, motif: "abstract" },
  { id: "web-solitaire", title: "Solitaire", url: "https://www.solitr.com/", genre: "Cards", rating: 3, desc: "Classic Klondike solitaire with smooth drag-and-drop cards.", hueA: 140, hueB: 100, motif: "grid" },
  { id: "web-clumsy", title: "Clumsy Bird", url: "https://ellisonleao.github.io/clumsy-bird/", genre: "Arcade", rating: 3, desc: "Flap through the pipes. Just one more try…", hueA: 190, hueB: 50, motif: "waves" },
  { id: "web-floppy", title: "Floppy Bird", url: "https://nebez.github.io/floppybird/", genre: "Arcade", rating: 3, desc: "A faithful, charming take on the famously hard flapping game.", hueA: 90, hueB: 200, motif: "waves" },
  { id: "web-slither", title: "Slither.io", url: "https://slither.io/", genre: "Multiplayer", rating: 7, desc: "Grow the longest snake in a massive online arena. Eat, dodge and outmaneuver.", hueA: 130, hueB: 300, motif: "abstract" },
  { id: "web-shell", title: "Shell Shockers", url: "https://shellshock.io/", genre: "Shooter", rating: 12, desc: "A cartoony multiplayer shooter where you play as heavily armed eggs.", hueA: 30, hueB: 350, motif: "abstract" },
  { id: "web-paperio", title: "Paper.io", url: "https://paper-io.com/", genre: "Multiplayer", rating: 3, desc: "Capture territory by drawing loops. Don't let anyone cut your trail.", hueA: 210, hueB: 150, motif: "grid" },
  { id: "web-mahjong", title: "Mahjong", url: "https://mahjongg.io/", genre: "Puzzle", rating: 3, desc: "Relaxing tile-matching Mahjong solitaire.", hueA: 160, hueB: 30, motif: "grid" },
];

export const STORE_GAMES: Game[] = DEFS.map((d, i) => ({
  id: d.id,
  title: d.title,
  html: "",
  url: d.url,
  rating: d.rating,
  genre: d.genre,
  desc: d.desc,
  ...buildArt(d.title, { hueA: d.hueA, hueB: d.hueB, motif: d.motif }),
  addedAt: 100 + i,
  playtime: 0,
}));

export const getStoreGame = (id: string) => STORE_GAMES.find((g) => g.id === id);
export const GAME_GENRES = ["All", ...Array.from(new Set(DEFS.map((d) => d.genre)))];

/** Curated YouTube videos (verified IDs). */
export interface Vid {
  id: string;
  title: string;
  channel: string;
  cat: string;
}
export const YT_VIDEOS: Vid[] = [
  { id: "unYFdcEjV9k", title: "Astro Bot – Launch Trailer", channel: "PlayStation", cat: "PlayStation" },
  { id: "eOiUtRF8k28", title: "The Last of Us Part II – Launch Trailer", channel: "PlayStation", cat: "PlayStation" },
  { id: "g1wr0DfV73E", title: "God of War Ragnarök – Launch Trailer", channel: "PlayStation", cat: "PlayStation" },
  { id: "9fVYKsEmuRo", title: "Marvel's Spider-Man 2 – Launch Trailer", channel: "PlayStation", cat: "PlayStation" },
  { id: "WuDsI63TiQM", title: "Horizon Forbidden West – Cinematic Trailer", channel: "PlayStation", cat: "PlayStation" },
  { id: "0HTfLqHoTmg", title: "Ghost of Tsushima – Launch Trailer", channel: "PlayStation", cat: "PlayStation" },
  { id: "55PRv_e00wc", title: "Ratchet & Clank: Rift Apart – Launch Trailer", channel: "PlayStation", cat: "PlayStation" },
  { id: "RkC0l4iekYo", title: "PS5 Hardware Reveal Trailer", channel: "PlayStation", cat: "PlayStation" },
  { id: "ULfjoCqEo6I", title: "Gran Turismo 7 – Opening Movie", channel: "PlayStation", cat: "PlayStation" },
  { id: "442nxULH_E4", title: "Bloodborne – Official Launch Trailer", channel: "PlayStation", cat: "PlayStation" },
  { id: "hDZ7y8RP5HE", title: "Moana 2 – Official Trailer", channel: "Disney", cat: "Movies" },
  { id: "LEjhY15eCx0", title: "Inside Out 2 – Official Trailer", channel: "Disney", cat: "Movies" },
  { id: "wJO_vIDZn-I", title: "A Minecraft Movie – Official Trailer", channel: "Warner Bros.", cat: "Movies" },
  { id: "cqGjhVJWtEg", title: "Spider-Man: Across the Spider-Verse – Trailer", channel: "Sony Pictures", cat: "Movies" },
  { id: "CaimKeDcudo", title: "Encanto – Official Trailer", channel: "Disney", cat: "Movies" },
  { id: "rFZHOHl-L8A", title: "lofi hip hop radio – beats to relax/study to", channel: "Lofi Girl", cat: "Music" },
  { id: "CCHdMIEGaaM", title: "Daft Punk – Get Lucky (Official Video)", channel: "Daft Punk", cat: "Music" },
  { id: "2YA0OK7OFkk", title: "Hans Zimmer – Interstellar Theme Live in Prague", channel: "Hans Zimmer", cat: "Music" },
  { id: "g55XEx2oFaE", title: "Gaming Music 2026 – NCS, Trap, Electronic & House", channel: "Gaming Mix", cat: "Music" },
  { id: "dQw4w9WgXcQ", title: "Rick Astley – Never Gonna Give You Up", channel: "Rick Astley", cat: "Music" },
  { id: "tj4knR4r1UU", title: "Live: 24/7 NASA Stream of Earth from Space", channel: "NASA", cat: "Relax & Live" },
  { id: "a-8XiE7W7u4", title: "Most Beautiful Places in the World in 4K", channel: "Cinematic Nature", cat: "Relax & Live" },
  { id: "UV0mhY2Dxr0", title: "Nature Relaxation Film 4K – Peaceful Music", channel: "Relaxation", cat: "Relax & Live" },
];

export const SPOTIFY_PLAYLISTS = [
  { id: "37i9dQZF1DXcBWIGoYBM5M", title: "Today's Top Hits", cat: "Pop", color: "#e8115b" },
  { id: "37i9dQZF1DX4JAvHpjipBk", title: "New Music Friday", cat: "Pop", color: "#f59b23" },
  { id: "37i9dQZF1DX5Ejj0EkURtP", title: "All Out 2010s", cat: "Pop", color: "#8d67ab" },
  { id: "37i9dQZF1DX0XUsuxWHRQd", title: "RapCaviar", cat: "Hip-Hop", color: "#b49bc8" },
  { id: "37i9dQZF1DWXRqgorJj26U", title: "Rock Classics", cat: "Rock", color: "#e13300" },
  { id: "37i9dQZF1DX2sUQwD7tbmL", title: "Feel-Good Indie Rock", cat: "Rock", color: "#1e3264" },
  { id: "37i9dQZF1DX4WYpdgoIcn6", title: "Chill Hits", cat: "Chill", color: "#477d95" },
  { id: "37i9dQZF1DWWQRwui0ExPn", title: "lofi beats", cat: "Chill", color: "#7358ff" },
  { id: "37i9dQZF1DX4sWSpwq3LiO", title: "Peaceful Piano", cat: "Focus", color: "#509bf5" },
  { id: "37i9dQZF1DWZeKCadgRdKQ", title: "Deep Focus", cat: "Focus", color: "#503750" },
  { id: "37i9dQZF1DXaXB8fQg7xif", title: "Dance Party", cat: "Dance", color: "#ba5d07" },
  { id: "37i9dQZF1DX6J5NfMJS675", title: "TECHNO BUNKER", cat: "Dance", color: "#1e3264" },
  { id: "37i9dQZF1DX10zKzsJ2jva", title: "Viva Latino", cat: "Latin", color: "#e8115b" },
  { id: "37i9dQZF1DXdPec7aLTmlC", title: "Happy Hits!", cat: "Mood", color: "#f037a5" },
  { id: "37i9dQZF1DWTkxQvqMy4WW", title: "Chillin' on a Dirt Road", cat: "Country", color: "#27856a" },
];

export const DISNEY_VIDEOS: (Vid & { franchise: string })[] = [
  { id: "hDZ7y8RP5HE", title: "Moana 2", channel: "Disney", cat: "Trailers", franchise: "Disney" },
  { id: "CaimKeDcudo", title: "Encanto", channel: "Disney", cat: "Trailers", franchise: "Disney" },
  { id: "LEjhY15eCx0", title: "Inside Out 2", channel: "Pixar", cat: "Trailers", franchise: "Pixar" },
  { id: "yM7ECLIhsAc", title: "Marvel Studios | Look Ahead", channel: "Marvel", cat: "Trailers", franchise: "Marvel" },
  { id: "cKOegEuCcfw", title: "Andor", channel: "Star Wars", cat: "Trailers", franchise: "Star Wars" },
  { id: "Znsa4Deavgg", title: "The Mandalorian – Season 3", channel: "Star Wars", cat: "Trailers", franchise: "Star Wars" },
];
