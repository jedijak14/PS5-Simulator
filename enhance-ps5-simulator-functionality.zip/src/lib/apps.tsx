import type { CSSProperties, ComponentType } from "react";
import { BookOpen, Clapperboard, Globe, Settings as Gear, Info } from "lucide-react";
import {
  SiSpotify, SiYoutube, SiNetflix, SiTwitch, SiAppletv, SiHbomax, SiCrunchyroll, SiParamountplus, SiPlex, SiYoutubemusic, SiApplemusic,
} from "react-icons/si";
import { PS_PATH } from "../components/ui";

export type IconC = ComponentType<{ className?: string; style?: CSSProperties }>;

export const DisneyPlusIcon: IconC = ({ className, style }) => (
  <svg viewBox="0 0 120 64" className={className} style={style} fill="none">
    <path d="M8 36C24 6 82 -4 104 26" stroke="currentColor" strokeWidth="3.2" strokeLinecap="round" />
    <text x="50" y="50" textAnchor="middle" fontFamily="Georgia,'Times New Roman',serif" fontStyle="italic" fontWeight="700" fontSize="28" fill="currentColor" letterSpacing="-1">Disney</text>
    <path d="M108 30v14M101 37h14" stroke="currentColor" strokeWidth="4" strokeLinecap="round" />
  </svg>
);

export const PrimeVideoIcon: IconC = ({ className, style }) => (
  <svg viewBox="0 0 120 70" className={className} style={style} fill="none">
    <text x="60" y="30" textAnchor="middle" fontFamily="Arial,Helvetica,sans-serif" fontWeight="700" fontSize="27" fill="currentColor">prime</text>
    <text x="60" y="52" textAnchor="middle" fontFamily="Arial,Helvetica,sans-serif" fontWeight="600" fontSize="19" fill="currentColor">video</text>
    <path d="M22 58C48 70 82 70 104 56" stroke="currentColor" strokeWidth="4" strokeLinecap="round" />
    <path d="M96 55l9 1-3-9" stroke="currentColor" strokeWidth="3.5" strokeLinecap="round" strokeLinejoin="round" />
  </svg>
);

export const HuluIcon: IconC = ({ className, style }) => (
  <svg viewBox="0 0 120 56" className={className} style={style} fill="none">
    <text x="60" y="44" textAnchor="middle" fontFamily="'Arial Black',Arial,sans-serif" fontWeight="900" fontSize="46" fill="currentColor" letterSpacing="-2">hulu</text>
  </svg>
);

export const StoreIcon: IconC = ({ className, style }) => (
  <svg viewBox="0 0 48 48" className={className} style={style} fill="none">
    <path d="M10 16h28l2.5 26H7.5z" stroke="currentColor" strokeWidth="2.6" strokeLinejoin="round" />
    <path d="M17 20v-4a7 7 0 0 1 14 0v4" stroke="currentColor" strokeWidth="2.6" strokeLinecap="round" />
    <g transform="translate(14.4 20.5) scale(0.8)" fill="currentColor"><path transform="translate(0 -2.2)" d={PS_PATH} /></g>
  </svg>
);

export const GuideIcon: IconC = ({ className, style }) => <BookOpen className={className} style={style} strokeWidth={1.5} />;
export const BrowserIcon: IconC = ({ className, style }) => <Globe className={className} style={style} strokeWidth={1.4} />;
export const MediaIcon: IconC = ({ className, style }) => <Clapperboard className={className} style={style} strokeWidth={1.4} />;
export const SettingsIcon: IconC = ({ className, style }) => <Gear className={className} style={style} strokeWidth={1.5} />;
export const AboutIcon: IconC = ({ className, style }) => <Info className={className} style={style} strokeWidth={1.5} />;

export type AppGroup = "browser" | "store" | "streaming" | "none";

export interface AppDef {
  id: string;
  name: string;
  tagline: string;
  desc: string;
  category: "System" | "TV & Video" | "Music" | "Utilities";
  bg: string;
  fg: string;
  Icon: IconC;
  /** always on the Home screen */
  builtin?: boolean;
  /** keeps running in the background when you go Home */
  persist: boolean;
  group: AppGroup;
  rating: number;
  size: string;
  site?: string;
  login?: string;
  /** brand colour used by sign-in screens */
  brand?: string;
}

export const APPS: AppDef[] = [
  {
    id: "store", name: "PlayStation Store", tagline: "Games & apps", category: "System", builtin: true, persist: false, group: "store", rating: 0, size: "—",
    desc: "Browse and download games, streaming services and entertainment apps.",
    bg: "linear-gradient(135deg,#0b3aa8,#1d78ff 60%,#6bc1ff)", fg: "#fff", Icon: StoreIcon,
  },
  {
    id: "browser", name: "Web Browser", tagline: "Chromium-style browser", category: "System", builtin: true, persist: true, group: "browser", rating: 0, size: "—",
    desc: "Browse the web with tabs, bookmarks, history and a real address bar.",
    bg: "linear-gradient(135deg,#0a3a8a,#2b7fff 60%,#7cc4ff)", fg: "#fff", Icon: BrowserIcon,
  },
  {
    id: "media", name: "Media Player", tagline: "Your music, video & photos", category: "System", builtin: true, persist: true, group: "none", rating: 0, size: "—",
    desc: "Play your own music, videos and photos on the big screen.",
    bg: "linear-gradient(135deg,#3b0a6b,#a23cff 60%,#ff7ad0)", fg: "#fff", Icon: MediaIcon,
  },
  {
    id: "guide", name: "User's Guide", tagline: "Learn the simulator", category: "System", builtin: true, persist: false, group: "none", rating: 0, size: "—",
    desc: "Everything you need to know: controls, themes, the Store, background apps and more.",
    bg: "linear-gradient(135deg,#0f766e,#14b8a6 60%,#99f6e4)", fg: "#fff", Icon: GuideIcon,
  },
  {
    id: "spotify", name: "Spotify", tagline: "Music & podcasts", category: "Music", persist: true, group: "streaming", rating: 0, size: "112 MB",
    desc: "Sign in with your Spotify account and listen to playlists in full screen. Keeps playing in the background while you browse the Home screen.",
    bg: "linear-gradient(135deg,#191414,#050505)", fg: "#1ed760", Icon: SiSpotify, brand: "#1ed760",
    site: "https://open.spotify.com/", login: "https://accounts.spotify.com/login?continue=https%3A%2F%2Fopen.spotify.com%2F",
  },
  {
    id: "youtube", name: "YouTube", tagline: "Watch anything", category: "TV & Video", persist: true, group: "streaming", rating: 0, size: "86 MB",
    desc: "Search and watch videos in full screen. Trailers, music, gaming and live streams — no sign-in needed.",
    bg: "linear-gradient(135deg,#ffffff,#e9e9ec)", fg: "#ff0000", Icon: SiYoutube, brand: "#ff0000",
    site: "https://www.youtube.com/",
  },
  {
    id: "disney", name: "Disney+", tagline: "Stories that matter", category: "TV & Video", persist: true, group: "streaming", rating: 0, size: "148 MB",
    desc: "Sign in to Disney+ and explore Disney, Pixar, Marvel, Star Wars and National Geographic.",
    bg: "linear-gradient(135deg,#0a1650,#113ccf 70%,#2a6bff)", fg: "#fff", Icon: DisneyPlusIcon, brand: "#113ccf",
    site: "https://www.disneyplus.com/", login: "https://www.disneyplus.com/login",
  },
  {
    id: "netflix", name: "Netflix", tagline: "Movies & TV shows", category: "TV & Video", persist: true, group: "streaming", rating: 0, size: "132 MB",
    desc: "Sign in to Netflix to watch award-winning series, films and documentaries.",
    bg: "linear-gradient(135deg,#141414,#000)", fg: "#e50914", Icon: SiNetflix, brand: "#e50914",
    site: "https://www.netflix.com/", login: "https://www.netflix.com/login",
  },
  {
    id: "twitch", name: "Twitch", tagline: "Live streaming", category: "TV & Video", persist: true, group: "streaming", rating: 12, size: "98 MB",
    desc: "Watch live streams of your favorite games and creators.",
    bg: "linear-gradient(135deg,#9146ff,#5a2cb3)", fg: "#fff", Icon: SiTwitch, brand: "#9146ff",
    site: "https://www.twitch.tv/", login: "https://www.twitch.tv/login",
  },
  {
    id: "prime", name: "Prime Video", tagline: "Included with Prime", category: "TV & Video", persist: true, group: "streaming", rating: 0, size: "121 MB",
    desc: "Sign in to Prime Video for movies, series and Amazon Originals.",
    bg: "linear-gradient(135deg,#00a8e1,#0f5e9c)", fg: "#fff", Icon: PrimeVideoIcon, brand: "#00a8e1",
    site: "https://www.primevideo.com/", login: "https://www.primevideo.com/",
  },
  {
    id: "appletv", name: "Apple TV", tagline: "Apple Originals", category: "TV & Video", persist: true, group: "streaming", rating: 0, size: "104 MB",
    desc: "Watch Apple Originals, movies and live sports.",
    bg: "linear-gradient(135deg,#1c1c1e,#000)", fg: "#fff", Icon: SiAppletv, brand: "#ffffff",
    site: "https://tv.apple.com/", login: "https://tv.apple.com/",
  },
  {
    id: "max", name: "Max", tagline: "Everything HBO", category: "TV & Video", persist: true, group: "streaming", rating: 12, size: "117 MB",
    desc: "Stream HBO originals, blockbuster movies and more.",
    bg: "linear-gradient(135deg,#0022e0,#6a2bd9)", fg: "#fff", Icon: SiHbomax, brand: "#5a2bd9",
    site: "https://www.max.com/", login: "https://auth.max.com/login",
  },
  {
    id: "hulu", name: "Hulu", tagline: "Stream TV & movies", category: "TV & Video", persist: true, group: "streaming", rating: 12, size: "109 MB",
    desc: "Sign in to Hulu for current TV hits and original series.",
    bg: "linear-gradient(135deg,#1ce783,#0aa65a)", fg: "#0b0c0f", Icon: HuluIcon, brand: "#1ce783",
    site: "https://www.hulu.com/", login: "https://auth.hulu.com/web/login",
  },
  {
    id: "crunchyroll", name: "Crunchyroll", tagline: "Anime streaming", category: "TV & Video", persist: true, group: "streaming", rating: 12, size: "94 MB",
    desc: "The world's largest anime library, in one app.",
    bg: "linear-gradient(135deg,#f47521,#c2410c)", fg: "#fff", Icon: SiCrunchyroll, brand: "#f47521",
    site: "https://www.crunchyroll.com/", login: "https://sso.crunchyroll.com/login",
  },
  {
    id: "paramount", name: "Paramount+", tagline: "Live TV, sports & more", category: "TV & Video", persist: true, group: "streaming", rating: 0, size: "103 MB",
    desc: "Movies, live sports and shows from Paramount and CBS.",
    bg: "linear-gradient(135deg,#0064ff,#003a99)", fg: "#fff", Icon: SiParamountplus, brand: "#0064ff",
    site: "https://www.paramountplus.com/", login: "https://www.paramountplus.com/account/signin/",
  },
  {
    id: "plex", name: "Plex", tagline: "Your media, everywhere", category: "TV & Video", persist: true, group: "streaming", rating: 0, size: "88 MB",
    desc: "Stream your own library plus free movies and live channels.",
    bg: "linear-gradient(135deg,#2a2a2a,#0c0c0c)", fg: "#e5a00d", Icon: SiPlex, brand: "#e5a00d",
    site: "https://app.plex.tv/", login: "https://app.plex.tv/",
  },
  {
    id: "ytmusic", name: "YouTube Music", tagline: "Songs & music videos", category: "Music", persist: true, group: "streaming", rating: 0, size: "76 MB",
    desc: "Music videos, albums and playlists from YouTube Music.",
    bg: "linear-gradient(135deg,#1a1a1a,#000)", fg: "#ff0000", Icon: SiYoutubemusic, brand: "#ff0000",
    site: "https://music.youtube.com/", login: "https://accounts.google.com/",
  },
  {
    id: "applemusic", name: "Apple Music", tagline: "100 million songs", category: "Music", persist: true, group: "streaming", rating: 0, size: "81 MB",
    desc: "Stream over 100 million songs, ad-free.",
    bg: "linear-gradient(135deg,#fa243c,#b0102a)", fg: "#fff", Icon: SiApplemusic, brand: "#fa243c",
    site: "https://music.apple.com/", login: "https://music.apple.com/",
  },
];

export const getApp = (id: string) => APPS.find((a) => a.id === id);
export const STREAM_APPS = APPS.filter((a) => a.group === "streaming");
