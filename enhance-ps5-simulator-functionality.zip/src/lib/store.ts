import type { Game, Parental, Profile, Settings, Wallpaper } from "../types";

/* ------------------------------------------------------------------ *
 *  IndexedDB: user games + uploaded wallpapers
 * ------------------------------------------------------------------ */
const DB_NAME = "ps5-sim";
const GAMES = "games";
const WALLS = "wallpapers";

function openDb(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    const req = indexedDB.open(DB_NAME, 2);
    req.onupgradeneeded = () => {
      const db = req.result;
      if (!db.objectStoreNames.contains(GAMES)) db.createObjectStore(GAMES, { keyPath: "id" });
      if (!db.objectStoreNames.contains(WALLS)) db.createObjectStore(WALLS, { keyPath: "id" });
    };
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}

async function getAll<T>(store: string): Promise<T[]> {
  try {
    const db = await openDb();
    return await new Promise((resolve, reject) => {
      const r = db.transaction(store).objectStore(store).getAll();
      r.onsuccess = () => resolve(r.result as T[]);
      r.onerror = () => reject(r.error);
    });
  } catch {
    return [];
  }
}
async function put<T>(store: string, v: T): Promise<void> {
  const db = await openDb();
  await new Promise<void>((resolve, reject) => {
    const tx = db.transaction(store, "readwrite");
    tx.objectStore(store).put(v);
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
  });
}
async function del(store: string, id: string): Promise<void> {
  const db = await openDb();
  await new Promise<void>((resolve, reject) => {
    const tx = db.transaction(store, "readwrite");
    tx.objectStore(store).delete(id);
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
  });
}
async function clear(store: string): Promise<void> {
  const db = await openDb();
  await new Promise<void>((resolve, reject) => {
    const tx = db.transaction(store, "readwrite");
    tx.objectStore(store).clear();
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
  });
}

export const loadUserGames = () => getAll<Game>(GAMES);
export const saveGame = (g: Game) => put(GAMES, g);
export const removeGame = (id: string) => del(GAMES, id);
export const clearGames = () => clear(GAMES);

export const loadWallpapers = () => getAll<Wallpaper>(WALLS);
export const saveWallpaper = (w: Wallpaper) => put(WALLS, w);
export const removeWallpaper = (id: string) => del(WALLS, id);
export const clearWallpapers = () => clear(WALLS);

/* ------------------------------------------------------------------ *
 *  localStorage helpers
 * ------------------------------------------------------------------ */
export function read<T>(key: string, fallback: T): T {
  try {
    const v = localStorage.getItem(key);
    return v ? ({ ...(typeof fallback === "object" && !Array.isArray(fallback) ? (fallback as object) : {}), ...(JSON.parse(v) as object) } as T) : fallback;
  } catch {
    return fallback;
  }
}
export function readRaw<T>(key: string, fallback: T): T {
  try {
    const v = localStorage.getItem(key);
    return v ? (JSON.parse(v) as T) : fallback;
  } catch {
    return fallback;
  }
}
export function write(key: string, v: unknown) {
  try {
    localStorage.setItem(key, JSON.stringify(v));
  } catch {
    /* quota */
  }
}

/* ---- meta (last played / playtime) and hidden built-in games ---- */
export type Meta = Record<string, { lastPlayed?: number; playtime: number }>;
export const getMeta = (): Meta => readRaw<Meta>("ps5.meta", {});
export function addPlaytime(id: string, seconds: number) {
  const m = getMeta();
  const cur = m[id] ?? { playtime: 0 };
  m[id] = { lastPlayed: Date.now(), playtime: cur.playtime + seconds };
  write("ps5.meta", m);
}
export const getHidden = (): string[] => readRaw<string[]>("ps5.hidden", []);
export const setHidden = (ids: string[]) => write("ps5.hidden", ids);

/* ---- store installs ---- */
export const getInstalled = (): string[] => readRaw<string[]>("ps5.installed", []);
export const setInstalled = (ids: string[]) => write("ps5.installed", ids);

/* ---- settings ---- */
export const DEFAULT_SETTINGS: Settings = {
  sfx: true,
  volume: 0.7,
  music: true,
  musicVolume: 0.5,
  gameSound: true,
  brightness: 1,
  hdr: false,
  hints: true,
  motion: true,
  largeText: false,
  clock24: false,
  notifications: true,
};
export const loadSettings = () => read<Settings>("ps5.settings2", DEFAULT_SETTINGS);
export const saveSettings = (s: Settings) => write("ps5.settings2", s);

/* ---- parental ---- */
export const DEFAULT_PARENTAL: Parental = {
  enabled: false,
  pin: "0000",
  maxAge: 12,
  blockBrowser: true,
  blockStore: false,
  blockStreaming: false,
  blockUpload: true,
};
export const loadParental = () => read<Parental>("ps5.parental", DEFAULT_PARENTAL);
export const saveParental = (p: Parental) => write("ps5.parental", p);

/* ---- profiles ---- */
export const newId = () => Math.random().toString(36).slice(2, 10) + Date.now().toString(36).slice(-4);
export function defaultProfile(): Profile {
  return { id: newId(), name: "Player_One", avatar: "astronaut", theme: "midnight", wallpaper: null, child: false, createdAt: Date.now() };
}
export function loadProfiles(): Profile[] {
  const p = readRaw<Profile[]>("ps5.profiles", []);
  return Array.isArray(p) ? p : [];
}
export const saveProfiles = (p: Profile[]) => write("ps5.profiles", p);
export const getLastProfile = () => readRaw<string | null>("ps5.lastProfile", null);
export const setLastProfile = (id: string) => write("ps5.lastProfile", id);

/* ---- per-profile key/value (streaming sign-in, favorites, etc.) ---- */
export const pget = <T,>(pid: string, key: string, fallback: T): T => readRaw<T>(`ps5.p.${pid}.${key}`, fallback);
export const pset = (pid: string, key: string, v: unknown) => write(`ps5.p.${pid}.${key}`, v);

/* ---- sizes / erase ---- */
export function localStorageBytes(prefix = "ps5."): number {
  let n = 0;
  for (let i = 0; i < localStorage.length; i++) {
    const k = localStorage.key(i)!;
    if (k.startsWith(prefix)) n += (k.length + (localStorage.getItem(k)?.length ?? 0)) * 2;
  }
  return n;
}
export function eraseKeys(match: (k: string) => boolean) {
  const keys: string[] = [];
  for (let i = 0; i < localStorage.length; i++) keys.push(localStorage.key(i)!);
  keys.filter((k) => k.startsWith("ps5.") && match(k)).forEach((k) => localStorage.removeItem(k));
}

export async function factoryReset() {
  eraseKeys(() => true);
  await clearGames().catch(() => undefined);
  await clearWallpapers().catch(() => undefined);
}
