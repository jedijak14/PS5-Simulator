import { createContext, useContext } from "react";
import type { Game, Parental, Profile, Running, Settings, Wallpaper } from "../types";
import type { Theme } from "./themes";

export interface AppCtx {
  settings: Settings;
  update: (p: Partial<Settings>) => void;
  profile: Profile;
  profiles: Profile[];
  theme: Theme;
  /** resolved wallpaper image (theme image or uploaded one) */
  wallpaperImage: string | null;
  updateProfile: (patch: Partial<Profile>, id?: string) => void;
  addProfile: (p: Partial<Profile>) => Profile;
  deleteProfile: (id: string) => void;
  switchUser: () => void;
  wallpapers: Wallpaper[];
  addWallpaper: (file: File) => Promise<void>;
  removeWallpaper: (id: string) => void;
  parental: Parental;
  setParental: (p: Partial<Parental>) => void;
  /** is this profile currently under parental restrictions */
  restricted: boolean;
  notify: (msg: string) => void;
  games: Game[];
  installed: string[];
  install: (id: string) => void;
  uninstall: (id: string) => void;
  running: Running[];
  openApp: (id: string) => void;
  launchGame: (g: Game) => void;
  closeRunning: (r: Running) => void;
  goHome: () => void;
  fullscreen: boolean;
  toggleFullscreen: () => void;
  deleteGame: (g: Game) => void;
  deleteAllGames: () => void;
  eraseAll: () => void;
  openControlCenter: () => void;
  restart: () => void;
}

export const Ctx = createContext<AppCtx | null>(null);
export function useApp(): AppCtx {
  const c = useContext(Ctx);
  if (!c) throw new Error("no ctx");
  return c;
}
