export type Fx =
  | "ribbons"
  | "spores"
  | "stars"
  | "snow"
  | "embers"
  | "rain"
  | "leaves"
  | "confetti"
  | "shapes"
  | "speed"
  | "fog"
  | "dust"
  | "towers"
  | "grid";

export type Mood = "calm" | "tense" | "playful" | "epic" | "retro" | "cosmic" | "warm" | "dark";

export interface Theme {
  id: string;
  name: string;
  group: "Classic" | "PlayStation Games" | "PlayStation Heritage" | "Colors";
  desc: string;
  colors: [string, string, string];
  image?: string;
  accent: string;
  fx: Fx;
  mood: Mood;
  font?: string;
  upper?: boolean;
  /** how app icons are drawn */
  icons: "brand" | "tint";
  tileBg?: string;
  tileFg?: string;
  tileBorder?: string;
  radius: string; // css length for tiles
  grain?: boolean;
  /** extra css filter on the wallpaper image */
  imgFilter?: string;
  overlay: string;
  bounce?: boolean;
}

const px = (id: number, ext = "jpeg") =>
  `https://images.pexels.com/photos/${id}/pexels-photo-${id}.${ext}?auto=compress&cs=tinysrgb&fit=crop&h=1080&w=1920`;


export const THEMES: Theme[] = [
  {
    id: "midnight", name: "PS5 Midnight", group: "Classic", desc: "The classic flowing PS5 home screen.",
    colors: ["#07123a", "#1d4ed8", "#0ea5e9"], accent: "#4aa3ff", fx: "ribbons", mood: "calm", icons: "brand", radius: "1.1rem", overlay: "none",
  },
  {
    id: "nebula", name: "Nebula", group: "Classic", desc: "Violet clouds drifting through deep space.",
    colors: ["#140a33", "#7c3aed", "#38bdf8"], accent: "#a78bfa", fx: "ribbons", mood: "cosmic", icons: "brand", radius: "1.1rem", overlay: "none",
  },
  {
    id: "aurora", name: "Aurora", group: "Classic", desc: "Northern lights in emerald and indigo.",
    colors: ["#04221f", "#10b981", "#6366f1"], accent: "#34d399", fx: "ribbons", mood: "calm", icons: "brand", radius: "1.1rem", overlay: "none",
  },
  {
    id: "ember", name: "Ember", group: "Classic", desc: "Warm glow of dying coals.",
    colors: ["#2a0a0a", "#ea580c", "#db2777"], accent: "#fb923c", fx: "embers", mood: "warm", icons: "brand", radius: "1.1rem", overlay: "none",
  },
  {
    id: "graphite", name: "Graphite", group: "Classic", desc: "Quiet, minimal and monochrome.",
    colors: ["#0c0c0e", "#3f4350", "#9ca3af"], accent: "#cbd5e1", fx: "ribbons", mood: "dark", icons: "brand", radius: "1.1rem", overlay: "none",
  },
  {
    id: "tlou", name: "The Last of Us", group: "PlayStation Games",
    desc: "Overgrown ruins, drifting spores and weathered stencil icons.",
    colors: ["#10140a", "#3d4a22", "#9aa35c"], image: px(30383704), accent: "#b9c46a", fx: "spores", mood: "tense",
    font: "'Oswald', 'Arial Narrow', sans-serif", upper: true, icons: "tint",
    tileBg: "linear-gradient(150deg,#454d2a 0%,#252a15 70%,#171a0d 100%)", tileFg: "#d3dc9a", tileBorder: "rgba(200,212,130,.35)",
    radius: "0.35rem", grain: true, imgFilter: "saturate(.75) contrast(1.05) sepia(.18)",
    overlay: "radial-gradient(ellipse at center,rgba(10,14,5,.15),rgba(6,8,3,.78)), linear-gradient(180deg,rgba(20,26,8,.35),rgba(0,0,0,.35))",
  },
  {
    id: "astrobot", name: "Astro Bot", group: "PlayStation Games",
    desc: "Bouncy, bright and playful with floating confetti.",
    colors: ["#0b1c4d", "#3b82f6", "#f472b6"], image: px(8294613), accent: "#38bdf8", fx: "confetti", mood: "playful",
    font: "'Fredoka', 'Albert Sans', sans-serif", icons: "brand", radius: "1.7rem", bounce: true,
    overlay: "linear-gradient(180deg,rgba(10,20,70,.35),rgba(30,10,70,.15) 45%,rgba(10,10,40,.6))",
  },
  {
    id: "astrogalaxy", name: "Astro Bot: Galaxy", group: "PlayStation Games",
    desc: "A candy-colored galaxy with twinkling stars.",
    colors: ["#0a0f3a", "#6d28d9", "#22d3ee"], image: px(34686777), accent: "#67e8f9", fx: "stars", mood: "playful",
    font: "'Fredoka', 'Albert Sans', sans-serif", icons: "brand", radius: "1.7rem", bounce: true,
    overlay: "linear-gradient(180deg,rgba(20,10,80,.4),rgba(0,0,0,.2) 50%,rgba(5,5,30,.65))",
  },
  {
    id: "gow", name: "God of War", group: "PlayStation Games",
    desc: "Frozen realms, falling snow and Nordic ember-gold.",
    colors: ["#0b0e14", "#7f1d1d", "#d9a441"], image: px(30207584), accent: "#e0a847", fx: "snow", mood: "epic",
    font: "'Cinzel', Georgia, serif", upper: true, icons: "tint",
    tileBg: "linear-gradient(150deg,#3b1010 0%,#1b0a0a 80%)", tileFg: "#e6b457", tileBorder: "rgba(224,168,71,.55)", radius: "0.5rem", grain: true,
    imgFilter: "saturate(.8) contrast(1.1)",
    overlay: "linear-gradient(180deg,rgba(60,10,10,.35),rgba(0,0,0,.15) 40%,rgba(0,0,0,.7))",
  },
  {
    id: "spiderman", name: "Marvel's Spider-Man", group: "PlayStation Games",
    desc: "Neon-lit New York at night. Red, blue and rain.",
    colors: ["#070b25", "#c8102e", "#1d4ed8"], image: px(30510169), accent: "#ff3b4e", fx: "rain", mood: "tense",
    font: "'Rajdhani', 'Albert Sans', sans-serif", upper: true, icons: "tint",
    tileBg: "linear-gradient(150deg,#d11a2f 0%,#7d0d1c 55%,#1b2f8a 130%)", tileFg: "#ffffff", tileBorder: "rgba(255,255,255,.4)", radius: "0.9rem",
    overlay: "linear-gradient(180deg,rgba(10,10,50,.35),rgba(120,0,20,.12) 50%,rgba(0,0,0,.65))",
  },
  {
    id: "tsushima", name: "Ghost of Tsushima", group: "PlayStation Games",
    desc: "Crimson maple leaves on the wind.",
    colors: ["#1a0808", "#9b1c1c", "#e8b86b"], image: px(29832308, "png"), accent: "#ef6a4c", fx: "leaves", mood: "calm",
    font: "'Cinzel', Georgia, serif", icons: "tint",
    tileBg: "linear-gradient(150deg,#2a0e0e,#120606)", tileFg: "#f2cf8b", tileBorder: "rgba(239,106,76,.5)", radius: "0.3rem",
    overlay: "linear-gradient(180deg,rgba(40,0,0,.3),rgba(0,0,0,.1) 45%,rgba(0,0,0,.6))",
  },
  {
    id: "horizon", name: "Horizon", group: "PlayStation Games",
    desc: "Sunrise over the wilds, drifting dust and light.",
    colors: ["#1a0f0a", "#c2410c", "#22d3ee"], image: px(28637780), accent: "#ff9a3d", fx: "dust", mood: "warm",
    font: "'Rajdhani', 'Albert Sans', sans-serif", upper: true, icons: "tint",
    tileBg: "linear-gradient(150deg,#ff9a3d 0%,#c2410c 60%,#7c2d12 100%)", tileFg: "#fff7ed", tileBorder: "rgba(255,255,255,.45)", radius: "1rem",
    overlay: "linear-gradient(180deg,rgba(40,10,0,.2),rgba(0,0,0,.05) 40%,rgba(10,0,0,.6))",
  },
  {
    id: "gt", name: "Gran Turismo", group: "PlayStation Games",
    desc: "Speed lines and race-day contrast.",
    colors: ["#04070f", "#0b3a8c", "#e11d48"], image: px(29772443), accent: "#2db4ff", fx: "speed", mood: "epic",
    font: "'Rajdhani', 'Albert Sans', sans-serif", upper: true, icons: "tint",
    tileBg: "linear-gradient(150deg,#0e1c33,#050912)", tileFg: "#e8f4ff", tileBorder: "rgba(45,180,255,.6)", radius: "0.25rem",
    overlay: "linear-gradient(180deg,rgba(0,10,40,.45),rgba(0,0,0,.1) 45%,rgba(0,0,0,.65))",
  },
  {
    id: "bloodborne", name: "Bloodborne", group: "PlayStation Games",
    desc: "A fog-bound gothic nightmare.",
    colors: ["#0a0507", "#5f0f1b", "#9ca3af"], image: px(10520862), accent: "#c0283c", fx: "fog", mood: "dark",
    font: "'Cinzel', Georgia, serif", upper: true, icons: "tint",
    tileBg: "linear-gradient(150deg,#2a0a10,#0b0305)", tileFg: "#d9c2c6", tileBorder: "rgba(192,40,60,.45)", radius: "0.2rem", grain: true,
    imgFilter: "saturate(.5) contrast(1.15) brightness(.85)",
    overlay: "radial-gradient(ellipse at center,rgba(20,0,5,.2),rgba(5,0,2,.85))",
  },
  {
    id: "ratchet", name: "Ratchet & Clank", group: "PlayStation Games",
    desc: "Dimension-hopping cosmic action.",
    colors: ["#06102e", "#0891b2", "#f59e0b"], image: px(37269529), accent: "#22d3ee", fx: "stars", mood: "cosmic",
    font: "'Orbitron', 'Albert Sans', sans-serif", icons: "tint",
    tileBg: "linear-gradient(150deg,#0e7490,#0a2a4a)", tileFg: "#fef3c7", tileBorder: "rgba(245,158,11,.6)", radius: "1.2rem",
    overlay: "linear-gradient(180deg,rgba(0,20,60,.4),rgba(0,0,0,.1) 50%,rgba(0,0,0,.6))",
  },
  {
    id: "shapes", name: "PlayStation Shapes", group: "PlayStation Heritage",
    desc: "Triangle, circle, cross and square drifting in the dark.",
    colors: ["#0a1030", "#2563eb", "#ec4899"], accent: "#78aaff", fx: "shapes", mood: "calm", icons: "brand", radius: "1.1rem", overlay: "none",
  },
  {
    id: "ps1", name: "PlayStation 1", group: "PlayStation Heritage",
    desc: "The grey BIOS grid of 1994.",
    colors: ["#15161a", "#3a3d45", "#8a8f9c"], accent: "#c9ced8", fx: "grid", mood: "retro",
    font: "'Orbitron', sans-serif", icons: "tint", tileBg: "linear-gradient(150deg,#4a4e58,#23252b)", tileFg: "#eceff4", tileBorder: "rgba(255,255,255,.4)", radius: "0.2rem",
    overlay: "none",
  },
  {
    id: "ps2", name: "PlayStation 2", group: "PlayStation Heritage",
    desc: "Glowing blue towers rising from the void.",
    colors: ["#000412", "#0b2a9e", "#3b82f6"], accent: "#60a5fa", fx: "towers", mood: "retro", icons: "brand", radius: "0.9rem", overlay: "none",
  },
  {
    id: "ps3", name: "PlayStation 3 XMB", group: "PlayStation Heritage",
    desc: "Silky waves, as seen on the Cross Media Bar.",
    colors: ["#06091f", "#2b4fd8", "#9fc4ff"], accent: "#9fc4ff", fx: "ribbons", mood: "calm", icons: "brand", radius: "0.8rem", overlay: "none",
  },
  {
    id: "ps4", name: "PlayStation 4 Dynamic", group: "PlayStation Heritage",
    desc: "Deep blue gradients inspired by the PS4 dynamic theme.",
    colors: ["#031026", "#0b4fb3", "#2fb0ff"], accent: "#2fb0ff", fx: "ribbons", mood: "calm", icons: "brand", radius: "0.6rem", overlay: "none",
  },
  {
    id: "wilds", name: "Overgrown Wilds", group: "Colors",
    desc: "A rusted van in a quiet forest.",
    colors: ["#06140c", "#14532d", "#84cc16"], image: px(40363222), accent: "#86efac", fx: "dust", mood: "warm", icons: "brand", radius: "1.1rem",
    overlay: "linear-gradient(180deg,rgba(0,20,5,.4),rgba(0,0,0,.05) 50%,rgba(0,0,0,.6))",
  },
  {
    id: "sunset", name: "Sunset Circuit", group: "Colors",
    desc: "Golden hour on an empty racetrack.",
    colors: ["#1c0a1f", "#be185d", "#fb923c"], image: px(29707622), accent: "#fb923c", fx: "dust", mood: "warm", icons: "brand", radius: "1.1rem",
    overlay: "linear-gradient(180deg,rgba(30,0,30,.3),rgba(0,0,0,.05) 50%,rgba(0,0,0,.6))",
  },
];

export const getTheme = (id: string) => THEMES.find((t) => t.id === id) ?? THEMES[0];
export const THEME_GROUPS = ["PlayStation Games", "PlayStation Heritage", "Classic", "Colors"] as const;
