import type { Game, Parental } from "../types";
import type { AppDef } from "./apps";

export const appAllowed = (a: AppDef, restricted: boolean, p: Parental) =>
  !restricted ||
  !(
    (a.group === "browser" && p.blockBrowser) ||
    (a.group === "store" && p.blockStore) ||
    (a.group === "streaming" && p.blockStreaming) ||
    a.rating > p.maxAge
  );

export const gameAllowed = (g: Game, restricted: boolean, p: Parental) => !restricted || (g.rating ?? 0) <= p.maxAge;

export const AGE_OPTIONS = [3, 7, 12, 16, 18];
export const ageLabel = (n: number) => (n >= 18 ? "All ages (18+)" : `Ages ${n} and under`);

export const fmtTime = (s: number) => {
  if (s < 60) return s < 5 ? "Just started" : `${Math.round(s)} sec`;
  if (s < 3600) return `${Math.round(s / 60)} min`;
  return `${(s / 3600).toFixed(1)} hrs`;
};
export const fmtAgo = (t?: number) => {
  if (!t) return "Never";
  const d = (Date.now() - t) / 1000;
  if (d < 60) return "Just now";
  if (d < 3600) return `${Math.round(d / 60)} min ago`;
  if (d < 86400) return `${Math.round(d / 3600)} hr ago`;
  return new Date(t).toLocaleDateString();
};
