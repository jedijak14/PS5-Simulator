import type { IconType } from "react-icons";
import {
  GiAstronautHelmet, GiNinjaHead, GiWolfHead, GiDragonHead, GiRobotGolem, GiCrownedSkull, GiSpartanHelmet, GiVikingHelmet,
  GiSamuraiHelmet, GiCat, GiFox, GiOwl, GiBearFace, GiLion, GiEagleHead, GiRobotHelmet, GiAlienStare, GiGhost, GiPirateSkull,
  GiWizardFace, GiElfHelmet, GiTigerHead, GiUnicorn, GiHoodedAssassin, GiSpaceship, GiRocket, GiBatMask, GiDinosaurRex,
  GiCyborgFace, GiRabbitHead, GiHorseHead, GiFrogPrince, GiSharkFin, GiJesterHat, GiKnightBanner, GiDevilMask,
} from "react-icons/gi";

export interface AvatarDef {
  id: string;
  name: string;
  Icon: IconType;
  a: string;
  b: string;
}

export const AVATARS: AvatarDef[] = [
  { id: "astronaut", name: "Astronaut", Icon: GiAstronautHelmet, a: "#38bdf8", b: "#1d4ed8" },
  { id: "robot", name: "Robot", Icon: GiRobotGolem, a: "#22d3ee", b: "#0e7490" },
  { id: "mech", name: "Mech", Icon: GiRobotHelmet, a: "#a5b4fc", b: "#4338ca" },
  { id: "cyborg", name: "Cyborg", Icon: GiCyborgFace, a: "#5eead4", b: "#0f766e" },
  { id: "ninja", name: "Ninja", Icon: GiNinjaHead, a: "#94a3b8", b: "#1e293b" },
  { id: "samurai", name: "Samurai", Icon: GiSamuraiHelmet, a: "#f87171", b: "#7f1d1d" },
  { id: "spartan", name: "Spartan", Icon: GiSpartanHelmet, a: "#fbbf24", b: "#b45309" },
  { id: "viking", name: "Viking", Icon: GiVikingHelmet, a: "#fdba74", b: "#9a3412" },
  { id: "knight", name: "Knight", Icon: GiKnightBanner, a: "#cbd5e1", b: "#475569" },
  { id: "elf", name: "Elf", Icon: GiElfHelmet, a: "#86efac", b: "#166534" },
  { id: "wizard", name: "Wizard", Icon: GiWizardFace, a: "#c4b5fd", b: "#5b21b6" },
  { id: "assassin", name: "Assassin", Icon: GiHoodedAssassin, a: "#fca5a5", b: "#450a0a" },
  { id: "wolf", name: "Wolf", Icon: GiWolfHead, a: "#93c5fd", b: "#1e3a8a" },
  { id: "dragon", name: "Dragon", Icon: GiDragonHead, a: "#fb923c", b: "#9a3412" },
  { id: "lion", name: "Lion", Icon: GiLion, a: "#fcd34d", b: "#b45309" },
  { id: "tiger", name: "Tiger", Icon: GiTigerHead, a: "#fdba74", b: "#c2410c" },
  { id: "bear", name: "Bear", Icon: GiBearFace, a: "#d6a77a", b: "#78350f" },
  { id: "fox", name: "Fox", Icon: GiFox, a: "#fb923c", b: "#c2410c" },
  { id: "cat", name: "Cat", Icon: GiCat, a: "#f0abfc", b: "#a21caf" },
  { id: "owl", name: "Owl", Icon: GiOwl, a: "#fde68a", b: "#a16207" },
  { id: "eagle", name: "Eagle", Icon: GiEagleHead, a: "#bae6fd", b: "#0369a1" },
  { id: "rabbit", name: "Rabbit", Icon: GiRabbitHead, a: "#fbcfe8", b: "#be185d" },
  { id: "horse", name: "Horse", Icon: GiHorseHead, a: "#d9f99d", b: "#4d7c0f" },
  { id: "unicorn", name: "Unicorn", Icon: GiUnicorn, a: "#f5d0fe", b: "#c026d3" },
  { id: "shark", name: "Shark", Icon: GiSharkFin, a: "#67e8f9", b: "#155e75" },
  { id: "frog", name: "Frog Prince", Icon: GiFrogPrince, a: "#bef264", b: "#3f6212" },
  { id: "dino", name: "Dino", Icon: GiDinosaurRex, a: "#4ade80", b: "#166534" },
  { id: "alien", name: "Alien", Icon: GiAlienStare, a: "#a3e635", b: "#365314" },
  { id: "ghost", name: "Ghost", Icon: GiGhost, a: "#e2e8f0", b: "#64748b" },
  { id: "pirate", name: "Pirate", Icon: GiPirateSkull, a: "#e5e7eb", b: "#111827" },
  { id: "king", name: "Skull King", Icon: GiCrownedSkull, a: "#fde047", b: "#713f12" },
  { id: "bat", name: "Dark Knight", Icon: GiBatMask, a: "#818cf8", b: "#111827" },
  { id: "jester", name: "Jester", Icon: GiJesterHat, a: "#f472b6", b: "#6d28d9" },
  { id: "devil", name: "Devil", Icon: GiDevilMask, a: "#f87171", b: "#991b1b" },
  { id: "rocket", name: "Rocket", Icon: GiRocket, a: "#fda4af", b: "#be123c" },
  { id: "ship", name: "Starship", Icon: GiSpaceship, a: "#7dd3fc", b: "#4f46e5" },
];

export const getAvatar = (id: string) => AVATARS.find((a) => a.id === id) ?? AVATARS[0];

export function AvatarIcon({ id, size = "3rem", ring = true, className = "" }: { id: string; size?: string; ring?: boolean; className?: string }) {
  const a = getAvatar(id);
  return (
    <div
      className={`relative flex shrink-0 items-center justify-center overflow-hidden rounded-full ${className}`}
      style={{
        width: size,
        height: size,
        background: `radial-gradient(circle at 30% 20%, ${a.a} 0%, ${a.b} 100%)`,
        boxShadow: ring ? "0 0 0 0.12rem rgba(255,255,255,0.85), 0 0.4rem 1.2rem rgba(0,0,0,.45)" : "0 0.3rem 1rem rgba(0,0,0,.4)",
      }}
    >
      <div className="absolute inset-0 rounded-full" style={{ background: "radial-gradient(circle at 30% 15%, rgba(255,255,255,.45), transparent 45%)" }} />
      <a.Icon style={{ width: "62%", height: "62%", filter: "drop-shadow(0 0.15rem 0.25rem rgba(0,0,0,.45))" }} color="#fff" />
    </div>
  );
}
