/* Generative ambient home-screen music. Mood changes with the active theme. */
import { getAudio } from "./sfx";
import type { Mood } from "./themes";

interface MoodDef {
  root: number; // Hz
  scale: number[]; // semitones
  chords: number[][]; // scale-degree stacks
  wave: OscillatorType;
  cutoff: number;
  chordLen: number; // seconds
  noteEvery: number; // seconds between bell notes
  bell: OscillatorType;
  sub: boolean;
  pluck: boolean;
}

const MAJ = [0, 2, 4, 5, 7, 9, 11];
const MIN = [0, 2, 3, 5, 7, 8, 10];
const PENT = [0, 2, 4, 7, 9];
const DOR = [0, 2, 3, 5, 7, 9, 10];
const PHRY = [0, 1, 3, 5, 7, 8, 10];

const MOODS: Record<Mood, MoodDef> = {
  calm: { root: 146.83, scale: MAJ, chords: [[0, 2, 4, 6], [5, 0, 2, 4], [3, 5, 0, 2], [4, 6, 1, 3]], wave: "sine", cutoff: 1400, chordLen: 9, noteEvery: 2.4, bell: "sine", sub: true, pluck: false },
  tense: { root: 110, scale: MIN, chords: [[0, 2, 4], [5, 0, 2], [3, 5, 0], [6, 1, 3]], wave: "triangle", cutoff: 700, chordLen: 11, noteEvery: 3.6, bell: "triangle", sub: true, pluck: true },
  playful: { root: 196, scale: PENT, chords: [[0, 2, 4], [1, 3, 0], [2, 4, 1], [3, 0, 2]], wave: "triangle", cutoff: 2600, chordLen: 6, noteEvery: 0.7, bell: "sine", sub: false, pluck: true },
  epic: { root: 98, scale: DOR, chords: [[0, 4, 6], [3, 5, 0], [4, 6, 1], [0, 2, 4]], wave: "sawtooth", cutoff: 520, chordLen: 10, noteEvery: 4.4, bell: "triangle", sub: true, pluck: false },
  retro: { root: 130.81, scale: MAJ, chords: [[0, 2, 4], [3, 5, 0], [4, 6, 1], [0, 2, 4]], wave: "square", cutoff: 900, chordLen: 8, noteEvery: 1.1, bell: "square", sub: false, pluck: true },
  cosmic: { root: 123.47, scale: DOR, chords: [[0, 2, 4, 6], [4, 6, 1, 3], [5, 0, 2, 4], [3, 5, 0, 2]], wave: "sine", cutoff: 1800, chordLen: 10, noteEvery: 1.8, bell: "sine", sub: true, pluck: false },
  warm: { root: 130.81, scale: MAJ, chords: [[0, 2, 4], [5, 0, 2], [3, 5, 0], [4, 6, 1]], wave: "triangle", cutoff: 1100, chordLen: 9, noteEvery: 2.8, bell: "sine", sub: true, pluck: true },
  dark: { root: 82.41, scale: PHRY, chords: [[0, 2, 4], [1, 3, 5], [0, 3, 5], [6, 1, 3]], wave: "sawtooth", cutoff: 420, chordLen: 12, noteEvery: 5, bell: "sine", sub: true, pluck: false },
};

let bus: GainNode | null = null;
let filter: BiquadFilterNode | null = null;
let timer: number | null = null;
let noteTimer: number | null = null;
let mood: MoodDef = MOODS.calm;
let chordIdx = 0;
let volume = 0.5;
let playing = false;
let wantOn = false;

const freqOf = (deg: number, oct = 0) => {
  const sc = mood.scale;
  const n = sc.length;
  const o = Math.floor(deg / n);
  const i = ((deg % n) + n) % n;
  return mood.root * Math.pow(2, (sc[i] + 12 * (o + oct)) / 12);
};

function graph() {
  const { ctx, master, conv } = getAudio();
  if (!bus) {
    bus = ctx.createGain();
    bus.gain.value = 0;
    filter = ctx.createBiquadFilter();
    filter.type = "lowpass";
    filter.frequency.value = mood.cutoff;
    filter.Q.value = 0.4;
    filter.connect(bus);
    bus.connect(master);
    const send = ctx.createGain();
    send.gain.value = 0.8;
    bus.connect(send);
    send.connect(conv);
  }
  return { ctx, filter: filter! };
}

function voice(freq: number, t: number, dur: number, type: OscillatorType, gain: number, attack: number, detune = 0, dest?: AudioNode) {
  const { ctx, filter: f } = graph();
  const o = ctx.createOscillator();
  const g = ctx.createGain();
  o.type = type;
  o.frequency.value = freq;
  o.detune.value = detune;
  g.gain.setValueAtTime(0.0001, t);
  g.gain.exponentialRampToValueAtTime(gain, t + attack);
  g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
  o.connect(g);
  g.connect(dest ?? f);
  o.start(t);
  o.stop(t + dur + 0.1);
}

function playChord() {
  if (!playing) return;
  const { ctx, filter: f } = graph();
  const now = ctx.currentTime + 0.05;
  f.frequency.cancelScheduledValues(now);
  f.frequency.setTargetAtTime(mood.cutoff * (0.8 + Math.random() * 0.5), now, 2);
  const stack = mood.chords[chordIdx % mood.chords.length];
  chordIdx++;
  const len = mood.chordLen;
  stack.forEach((d, i) => {
    voice(freqOf(d, 0), now + i * 0.25, len + 2, mood.wave, 0.05, len * 0.35, -6);
    voice(freqOf(d, 0), now + i * 0.25, len + 2, "sine", 0.05, len * 0.35, 7);
  });
  if (mood.sub) voice(freqOf(stack[0], -1), now, len + 2, "sine", 0.1, len * 0.3);
}

function playNote() {
  if (!playing) return;
  const { ctx, filter: f } = graph();
  const stack = mood.chords[(chordIdx - 1 + mood.chords.length) % mood.chords.length];
  const d = stack[Math.floor(Math.random() * stack.length)] + (Math.random() > 0.5 ? mood.scale.length : 0) + (Math.random() > 0.8 ? mood.scale.length : 0);
  const now = ctx.currentTime + 0.02;
  const fr = freqOf(d, 1);
  if (mood.pluck) {
    voice(fr, now, 1.6, mood.bell, 0.05, 0.01, 0, f);
    voice(fr * 2, now, 0.8, "sine", 0.015, 0.01, 0, f);
  } else {
    voice(fr, now, 4.5, mood.bell, 0.035, 0.6, 0, f);
  }
  noteTimer = window.setTimeout(playNote, mood.noteEvery * 1000 * (0.6 + Math.random() * 0.9));
}

function begin() {
  if (playing) return;
  const { ctx } = graph();
  if (ctx.state === "suspended") return; // will retry on user gesture
  playing = true;
  bus!.gain.cancelScheduledValues(ctx.currentTime);
  bus!.gain.setTargetAtTime(Math.pow(volume, 1.6) * 1.1, ctx.currentTime, 2.2);
  chordIdx = Math.floor(Math.random() * 4);
  playChord();
  timer = window.setInterval(playChord, mood.chordLen * 1000);
  noteTimer = window.setTimeout(playNote, 1500);
}

function halt() {
  if (!playing) return;
  playing = false;
  if (timer) clearInterval(timer);
  if (noteTimer) clearTimeout(noteTimer);
  timer = noteTimer = null;
  if (bus) {
    const { ctx } = getAudio();
    bus.gain.cancelScheduledValues(ctx.currentTime);
    bus.gain.setTargetAtTime(0, ctx.currentTime, 0.4);
  }
}

export const music = {
  /** true while the home screen should be scoring */
  setActive(on: boolean) {
    wantOn = on;
    if (on) {
      try {
        begin();
      } catch {
        /* needs gesture */
      }
    } else halt();
  },
  /** try again after a user gesture unlocked audio */
  retry() {
    if (wantOn && !playing) begin();
  },
  setVolume(v: number) {
    volume = v;
    if (bus && playing) bus.gain.setTargetAtTime(Math.pow(v, 1.6) * 1.1, getAudio().ctx.currentTime, 0.3);
  },
  setMood(m: Mood) {
    const next = MOODS[m] ?? MOODS.calm;
    if (next === mood) return;
    mood = next;
    if (playing) {
      halt();
      window.setTimeout(() => wantOn && begin(), 700);
    }
  },
  isPlaying: () => playing,
};
