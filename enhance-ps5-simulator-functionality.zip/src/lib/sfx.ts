/* Procedural audio: UI blips, startup chime, etc. No audio files needed. */

let ctx: AudioContext | null = null;
let master: GainNode;
let conv: ConvolverNode;
let enabled = true;
let volume = 0.7;

function ensure(): AudioContext {
  if (!ctx) {
    const AC = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    ctx = new AC();
    master = ctx.createGain();
    master.gain.value = Math.pow(volume, 1.5);
    master.connect(ctx.destination);
    conv = ctx.createConvolver();
    const len = Math.floor(ctx.sampleRate * 3.2);
    const buf = ctx.createBuffer(2, len, ctx.sampleRate);
    for (let ch = 0; ch < 2; ch++) {
      const d = buf.getChannelData(ch);
      for (let i = 0; i < len; i++) d[i] = (Math.random() * 2 - 1) * Math.pow(1 - i / len, 2.6);
    }
    conv.buffer = buf;
    const wet = ctx.createGain();
    wet.gain.value = 0.7;
    conv.connect(wet);
    wet.connect(master);
  }
  if (ctx.state === "suspended") void ctx.resume();
  return ctx;
}

interface ToneOpts {
  type?: OscillatorType;
  gain?: number;
  attack?: number;
  rev?: number;
  detune?: number;
  to?: number;
}

function tone(freq: number, t0: number, dur: number, o: ToneOpts = {}) {
  if (!enabled) return;
  const c = ensure();
  const now = c.currentTime + t0;
  const osc = c.createOscillator();
  const g = c.createGain();
  osc.type = o.type ?? "sine";
  osc.frequency.setValueAtTime(freq, now);
  if (o.to) osc.frequency.exponentialRampToValueAtTime(o.to, now + dur);
  osc.detune.value = o.detune ?? 0;
  g.gain.setValueAtTime(0.0001, now);
  g.gain.exponentialRampToValueAtTime(o.gain ?? 0.15, now + (o.attack ?? 0.005));
  g.gain.exponentialRampToValueAtTime(0.0001, now + dur);
  osc.connect(g);
  g.connect(master);
  if (o.rev) {
    const s = c.createGain();
    s.gain.value = o.rev;
    g.connect(s);
    s.connect(conv);
  }
  osc.start(now);
  osc.stop(now + dur + 0.05);
}

export function getAudio() {
  const c = ensure();
  return { ctx: c, master, conv };
}
export function audioEnabled() {
  return enabled;
}

export const sfx = {
  /** The cinematic whoosh + chord when a game starts */
  gameStart() {
    if (!enabled) return;
    ensure();
    tone(55, 0, 2.6, { type: "sine", gain: 0.3, attack: 0.5, rev: 0.3 });
    tone(220, 0, 1.4, { type: "sawtooth", gain: 0.03, attack: 0.9, rev: 0.6, to: 880 });
    [261.63, 392, 523.25, 783.99].forEach((f, i) => {
      tone(f, 0.55 + i * 0.07, 2.6, { type: "sine", gain: 0.09, attack: 0.25, rev: 0.9 });
      tone(f * 2.005, 0.6 + i * 0.07, 2.2, { type: "triangle", gain: 0.025, attack: 0.3, rev: 0.9 });
    });
    tone(2093, 0.95, 1.8, { type: "sine", gain: 0.05, attack: 0.02, rev: 1 });
    tone(3136, 1.15, 1.6, { type: "sine", gain: 0.03, attack: 0.02, rev: 1 });
  },
  unlock() {
    ensure();
  },
  setVolume(v: number) {
    volume = v;
    if (ctx) master.gain.value = Math.pow(v, 1.5);
  },
  setEnabled(e: boolean) {
    enabled = e;
  },
  move() {
    tone(1480, 0, 0.09, { type: "sine", gain: 0.07, rev: 0.25 });
    tone(2210, 0.01, 0.07, { type: "sine", gain: 0.03, rev: 0.2 });
  },
  select() {
    tone(880, 0, 0.18, { type: "triangle", gain: 0.1, rev: 0.35 });
    tone(1320, 0.04, 0.3, { type: "sine", gain: 0.09, rev: 0.5 });
  },
  back() {
    tone(660, 0, 0.12, { type: "triangle", gain: 0.09, rev: 0.3 });
    tone(440, 0.05, 0.2, { type: "sine", gain: 0.08, rev: 0.4 });
  },
  toggle() {
    tone(1040, 0, 0.08, { type: "square", gain: 0.03, rev: 0.2 });
  },
  error() {
    tone(220, 0, 0.18, { type: "sawtooth", gain: 0.05, rev: 0.2 });
    tone(196, 0.12, 0.25, { type: "sawtooth", gain: 0.05, rev: 0.2 });
  },
  open() {
    tone(330, 0, 0.5, { type: "sine", gain: 0.1, rev: 0.6, to: 660 });
    tone(990, 0.08, 0.6, { type: "sine", gain: 0.06, rev: 0.7 });
    tone(1480, 0.14, 0.7, { type: "sine", gain: 0.04, rev: 0.8 });
  },
  ps() {
    tone(523, 0, 0.5, { type: "sine", gain: 0.09, rev: 0.7 });
    tone(784, 0.07, 0.7, { type: "sine", gain: 0.08, rev: 0.8 });
    tone(1175, 0.14, 0.9, { type: "sine", gain: 0.05, rev: 0.9 });
  },
  notify() {
    tone(1568, 0, 0.3, { type: "sine", gain: 0.07, rev: 0.6 });
    tone(2093, 0.12, 0.5, { type: "sine", gain: 0.06, rev: 0.7 });
  },
  /** The big ambient startup swell */
  boot() {
    if (!enabled) return;
    ensure();
    // deep sub swell
    tone(73.4, 0, 6.5, { type: "sine", gain: 0.28, attack: 2.4, rev: 0.2 });
    tone(110, 0.2, 6, { type: "sine", gain: 0.12, attack: 2.4, rev: 0.4 });
    // shimmering pad - D major add9 voicing
    const chord = [293.66, 440, 587.33, 659.25, 880, 1174.66];
    chord.forEach((f, i) => {
      tone(f, 1.0 + i * 0.22, 5.2, { type: "sine", gain: 0.07, attack: 1.4, rev: 0.9, detune: -4 });
      tone(f * 1.003, 1.0 + i * 0.22, 5.2, { type: "triangle", gain: 0.025, attack: 1.6, rev: 0.9, detune: 5 });
    });
    // sparkle tail
    [2349, 1760, 2637, 3136, 2093, 3520].forEach((f, i) => {
      tone(f, 2.6 + i * 0.34, 1.4, { type: "sine", gain: 0.035, attack: 0.01, rev: 1 });
    });
    // final high bloom
    tone(1760, 4.9, 2.6, { type: "sine", gain: 0.07, attack: 0.9, rev: 1 });
    tone(2349, 5.0, 2.6, { type: "sine", gain: 0.05, attack: 0.9, rev: 1 });
  },
  shutdown() {
    tone(880, 0, 1.4, { type: "sine", gain: 0.1, rev: 0.8, to: 220 });
    tone(587, 0.15, 1.6, { type: "sine", gain: 0.08, rev: 0.9, to: 147 });
  },
  test() {
    const was = enabled;
    enabled = true;
    this.select();
    enabled = was;
  },
};
