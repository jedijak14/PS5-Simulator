/** Open a real browser window (popup). Used for sign-in pages and sites that can't be framed. */
export function openWindow(url: string): boolean {
  const w = Math.min(1400, window.screen.availWidth || 1280);
  const h = Math.min(900, window.screen.availHeight || 800);
  const left = Math.max(0, ((window.screen.availWidth || w) - w) / 2);
  const top = Math.max(0, ((window.screen.availHeight || h) - h) / 2);
  const win = window.open(url, "_blank", `popup=yes,width=${w},height=${h},left=${left},top=${top}`);
  if (!win) return false;
  try {
    win.opener = null;
  } catch {
    /* ignore */
  }
  return true;
}
