export interface Game {
  id: string;
  title: string;
  html: string;
  cover: string;
  background: string;
  logo: string;
  addedAt: number;
  builtin?: boolean;
  /** remote web game – runs in a frame instead of srcDoc */
  url?: string;
  rating?: number; // minimum age
  genre?: string;
  desc?: string;
  /** filled in from meta store */
  lastPlayed?: number;
  playtime: number; // seconds
}

export interface Profile {
  id: string;
  name: string;
  avatar: string;
  theme: string;
  wallpaper: string | null; // id of an uploaded wallpaper
  child: boolean;
  createdAt: number;
}

export interface Settings {
  sfx: boolean;
  volume: number; // 0..1
  music: boolean;
  musicVolume: number; // 0..1
  gameSound: boolean;
  brightness: number; // 0.6..1.2
  hdr: boolean;
  hints: boolean;
  motion: boolean;
  largeText: boolean;
  clock24: boolean;
  notifications: boolean;
}

export interface Parental {
  enabled: boolean;
  pin: string;
  maxAge: number; // 3 | 7 | 12 | 16 | 18
  blockBrowser: boolean;
  blockStore: boolean;
  blockStreaming: boolean;
  blockUpload: boolean;
}

export type AppId = string;

export type Route =
  | { type: "home" }
  | { type: "app"; id: AppId }
  | { type: "game"; id: string };

export type Stage = "booting" | "profiles" | "on";

export type PowerAction = "restart" | "switch";

export interface Wallpaper {
  id: string;
  name: string;
  data: string; // data URL
  addedAt: number;
}

export interface Running {
  kind: "app" | "game";
  id: string;
}
