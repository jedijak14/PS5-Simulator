export interface Game {
  id: string;
  title: string;
  html: string;
  cover: string;
  background: string;
  logo: string;
  addedAt: number;
  builtin?: boolean;
  /** filled in from meta store */
  lastPlayed?: number;
  playtime: number; // seconds
}

export interface Settings {
  userName: string;
  avatarHue: number;
  sfx: boolean;
  volume: number; // 0..1
  brightness: number; // 0.6..1.2
  hdr: boolean;
  hints: boolean;
  theme: string;
  motion: boolean;
}

export type AppId = "browser" | "media" | "settings" | "about";

export type Route =
  | { type: "home" }
  | { type: "app"; id: AppId }
  | { type: "game"; id: string };

export type Stage = "off" | "rest" | "booting" | "on" | "restarting";

export type PowerAction = "rest" | "restart" | "off";
