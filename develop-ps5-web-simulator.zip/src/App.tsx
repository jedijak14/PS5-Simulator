import { useCallback, useEffect, useMemo, useRef, useState, type ReactNode } from "react";
import { Clapperboard, Globe, Check } from "lucide-react";
import type { AppId, Game, PowerAction, Route, Settings, Stage } from "./types";
import { DEMO_GAMES } from "./lib/demoGames";
import { DEFAULT_SETTINGS, factoryReset, getHidden, getMeta, loadSettings, loadUserGames, removeGame, saveSettings, setHidden, clearGames } from "./lib/store";
import { sfx } from "./lib/sfx";
import { useNav } from "./lib/useNav";
import Wallpaper from "./components/Wallpaper";
import Boot from "./components/Boot";
import OffScreen from "./components/OffScreen";
import Home from "./components/Home";
import InstallGame from "./components/InstallGame";
import GameRunner from "./components/GameRunner";
import ControlCenter from "./components/ControlCenter";
import Browser from "./components/Browser";
import MediaPlayer from "./components/MediaPlayer";
import SettingsApp from "./components/SettingsApp";
import About from "./components/About";
import { PSLogo, Spinner } from "./components/ui";

interface Toast {
  id: number;
  msg: string;
}

const SPLASH: Partial<Record<AppId, { name: string; gradient: string; icon: ReactNode }>> = {
  browser: { name: "Web Browser", gradient: "linear-gradient(135deg,#0a3a8a,#2b7fff 60%,#7cc4ff)", icon: <Globe className="h-[7rem] w-[7rem]" strokeWidth={1.2} /> },
  media: { name: "Media Player", gradient: "linear-gradient(135deg,#3b0a6b,#a23cff 60%,#ff7ad0)", icon: <Clapperboard className="h-[7rem] w-[7rem]" strokeWidth={1.2} /> },
};

function AppSplash({ id }: { id: AppId }) {
  const s = SPLASH[id];
  if (!s) return null;
  return (
    <div
      className="pointer-events-none absolute inset-0 z-[55] flex flex-col items-center justify-center text-white"
      style={{ background: s.gradient, animation: "fade-out 0.55s ease 0.55s forwards" }}
    >
      <div style={{ animation: "logo-in 0.7s cubic-bezier(.2,.8,.2,1) both" }}>{s.icon}</div>
      <div className="mt-4 text-[1.6rem] font-semibold" style={{ animation: "rise-in 0.6s ease 0.15s both" }}>{s.name}</div>
    </div>
  );
}

export default function App() {
  const [stage, setStage] = useState<Stage>("off");
  const [offMsg, setOffMsg] = useState<string | undefined>();
  const [quickBoot, setQuickBoot] = useState(false);
  const [blackout, setBlackout] = useState(false);
  const [settings, setSettings] = useState<Settings>(loadSettings);
  const [userGames, setUserGames] = useState<Game[]>([]);
  const [hidden, setHiddenState] = useState<string[]>(getHidden);
  const [metaTick, setMetaTick] = useState(0);
  const [route, setRoute] = useState<Route>({ type: "home" });
  const [cc, setCc] = useState(false);
  const [installOpen, setInstallOpen] = useState(false);
  const [toasts, setToasts] = useState<Toast[]>([]);
  const [fullscreen, setFullscreen] = useState(false);
  const [intro, setIntro] = useState(true);
  const [returnKey, setReturnKey] = useState(0);
  const toastId = useRef(0);

  /* ---------- persistence & services ---------- */
  useEffect(() => {
    void loadUserGames().then(setUserGames);
  }, []);
  useEffect(() => {
    sfx.setVolume(settings.volume);
    sfx.setEnabled(settings.sfx);
  }, [settings.volume, settings.sfx]);
  useEffect(() => {
    const f = () => setFullscreen(!!document.fullscreenElement);
    document.addEventListener("fullscreenchange", f);
    return () => document.removeEventListener("fullscreenchange", f);
  }, []);

  const update = useCallback((p: Partial<Settings>) => {
    setSettings((s) => {
      const n = { ...s, ...p };
      saveSettings(n);
      return n;
    });
  }, []);

  const notify = useCallback((msg: string) => {
    const id = ++toastId.current;
    setToasts((t) => [...t.slice(-2), { id, msg }]);
    sfx.notify();
    window.setTimeout(() => setToasts((t) => t.filter((x) => x.id !== id)), 3800);
  }, []);

  const games = useMemo(() => {
    const meta = getMeta();
    return [...DEMO_GAMES.filter((g) => !hidden.includes(g.id)), ...userGames].map((g) => ({
      ...g,
      lastPlayed: meta[g.id]?.lastPlayed,
      playtime: meta[g.id]?.playtime ?? 0,
    }));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [userGames, hidden, metaTick]);

  /* ---------- navigation ---------- */
  const goHome = useCallback(() => {
    setRoute({ type: "home" });
    setIntro(false);
    setReturnKey((k) => k + 1);
  }, []);

  // refresh play history once a game has been closed (after GameRunner saved its play time)
  useEffect(() => {
    if (route.type === "home") setMetaTick((t) => t + 1);
  }, [route.type]);

  const openApp = useCallback((id: AppId) => {
    sfx.open();
    setCc(false);
    setRoute({ type: "app", id });
  }, []);

  const launchGame = useCallback((g: Game) => {
    sfx.open();
    setCc(false);
    setRoute({ type: "game", id: g.id });
  }, []);

  const closeApp = useCallback(() => {
    sfx.back();
    setCc(false);
    goHome();
  }, [goHome]);

  const toggleFullscreen = useCallback(() => {
    if (document.fullscreenElement) void document.exitFullscreen();
    else void document.documentElement.requestFullscreen?.().catch(() => undefined);
  }, []);

  /* ---------- power ---------- */
  const power = useCallback(
    (a: PowerAction) => {
      setCc(false);
      sfx.shutdown();
      setBlackout(true);
      window.setTimeout(() => {
        setRoute({ type: "home" });
        setInstallOpen(false);
        setIntro(true);
        setBlackout(false);
        if (a === "restart") {
          setStage("restarting");
          window.setTimeout(() => {
            setQuickBoot(false);
            setStage("booting");
          }, 1800);
        } else {
          setOffMsg(undefined);
          setStage(a === "rest" ? "rest" : "off");
        }
      }, 1000);
    },
    []
  );

  const powerOn = useCallback(() => {
    sfx.unlock();
    setQuickBoot(stage === "rest");
    setStage("booting");
  }, [stage]);

  const bootDone = useCallback(() => {
    setStage("on");
    setIntro(true);
    window.setTimeout(() => notify(`Welcome, ${settings.userName}`), 1400);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [notify]);

  /* ---------- game library actions ---------- */
  const deleteGame = useCallback(
    async (g: Game) => {
      if (g.builtin) {
        const h = [...hidden, g.id];
        setHidden(h);
        setHiddenState(h);
      } else {
        await removeGame(g.id).catch(() => undefined);
        setUserGames((u) => u.filter((x) => x.id !== g.id));
      }
      notify(`${g.title} deleted`);
    },
    [hidden, notify]
  );

  const deleteAll = useCallback(async () => {
    const h = DEMO_GAMES.map((g) => g.id);
    setHidden(h);
    setHiddenState(h);
    await clearGames().catch(() => undefined);
    setUserGames([]);
    notify("All games deleted");
  }, [notify]);

  const resetConsole = useCallback(async () => {
    await factoryReset();
    setSettings(DEFAULT_SETTINGS);
    setHiddenState([]);
    setUserGames([]);
    power("restart");
  }, [power]);

  /* ---------- global PS button ---------- */
  useNav(
    (a) => {
      if (a === "ps") {
        sfx.ps();
        setCc(true);
      }
    },
    stage === "on" && !cc && !installOpen && !blackout
  );

  const activeGame = route.type === "game" ? games.find((g) => g.id === route.id) : undefined;
  const homeActive = stage === "on" && route.type === "home" && !cc && !installOpen;
  const on = stage === "on";

  const filter =
    settings.brightness !== 1 || settings.hdr
      ? `brightness(${settings.brightness})${settings.hdr ? " contrast(1.08) saturate(1.25)" : ""}`
      : undefined;

  return (
    <div className="relative h-full w-full overflow-hidden bg-black" style={{ filter }}>
      {on && <Wallpaper theme={settings.theme} animate={settings.motion} paused={route.type === "game"} />}

      {on && (
        <div className={`absolute inset-0 ${route.type === "home" ? "" : "invisible"}`}>
          <Home
            key="home"
            active={homeActive}
            intro={intro}
            returnKey={returnKey}
            games={games}
            settings={settings}
            onLaunchGame={launchGame}
            onOpenApp={openApp}
            onInstall={() => setInstallOpen(true)}
            onDeleteGame={(g) => void deleteGame(g)}
          />
        </div>
      )}

      {on && route.type === "app" && (
        <>
          {route.id === "browser" && <Browser settings={settings} onClose={closeApp} />}
          {route.id === "media" && <MediaPlayer settings={settings} onClose={closeApp} notify={notify} />}
          {route.id === "settings" && (
            <SettingsApp
              settings={settings}
              update={update}
              games={games}
              fullscreen={fullscreen}
              onToggleFullscreen={toggleFullscreen}
              onDeleteAll={() => void deleteAll()}
              onReset={() => void resetConsole()}
              onAbout={() => openApp("about")}
              onPower={power}
              onClose={closeApp}
            />
          )}
          {route.id === "about" && <About settings={settings} onClose={closeApp} />}
          <AppSplash key={route.id} id={route.id} />
        </>
      )}

      {on && activeGame && <GameRunner key={activeGame.id} game={activeGame} paused={cc} onPS={() => { sfx.ps(); setCc(true); }} />}

      {on && installOpen && (
        <InstallGame
          showHints={settings.hints}
          onClose={() => setInstallOpen(false)}
          onInstalled={(g) => {
            setUserGames((u) => [...u, g]);
            setInstallOpen(false);
            notify(`${g.title} was installed`);
          }}
        />
      )}

      {on && cc && (
        <ControlCenter
          context={route.type}
          settings={settings}
          fullscreen={fullscreen}
          onVolume={(v) => update({ volume: v, sfx: v > 0 })}
          onToggleFullscreen={toggleFullscreen}
          onResume={() => setCc(false)}
          onCloseApp={closeApp}
          onSettings={() => openApp("settings")}
          onPower={power}
        />
      )}

      {/* notifications */}
      {on && (
        <div className="pointer-events-none absolute left-1/2 top-[1.6rem] z-[95] flex flex-col items-center gap-2" style={{ transform: "translateX(-50%)" }}>
          {toasts.map((t) => (
            <div key={t.id} className="anim-pop glass flex items-center gap-3 rounded-full bg-black/60 py-[0.55rem] pl-[0.6rem] pr-[1.3rem] shadow-2xl">
              <div className="flex h-[1.9rem] w-[1.9rem] items-center justify-center rounded-full bg-[#2e7bff]">
                {t.msg.includes("install") || t.msg.includes("added") ? <Check className="h-[1rem] w-[1rem]" /> : <PSLogo className="h-[0.9rem]" />}
              </div>
              <span className="text-[0.9rem] font-medium">{t.msg}</span>
            </div>
          ))}
        </div>
      )}

      {/* power states */}
      {stage === "booting" && <Boot quick={quickBoot} onDone={bootDone} />}
      {(stage === "off" || stage === "rest") && <OffScreen key={stage} mode={stage} message={offMsg} onPower={powerOn} />}
      {stage === "restarting" && (
        <div className="absolute inset-0 z-[90] flex flex-col items-center justify-center gap-5 bg-black">
          <Spinner size="2.6rem" />
          <div className="text-[0.95rem] text-white/60">Restarting PS5…</div>
        </div>
      )}
      <div className={`pointer-events-none absolute inset-0 z-[110] bg-black transition-opacity duration-[900ms] ${blackout ? "opacity-100" : "opacity-0"}`} />
    </div>
  );
}
