import { useState, type ReactNode } from "react";
import { Home, Maximize, Minimize, Moon, Play, Power, RotateCw, Settings as Gear, Volume2, VolumeX, X, ArrowLeft } from "lucide-react";
import { useNav } from "../lib/useNav";
import { sfx } from "../lib/sfx";
import { Hint, HintBar, PSLogo } from "./ui";
import type { PowerAction, Settings } from "../types";

interface Item {
  id: string;
  label: string;
  sub?: string;
  icon: ReactNode;
  danger?: boolean;
}

/** The PS-button quick menu that slides up over everything. */
export default function ControlCenter({
  context,
  settings,
  fullscreen,
  onVolume,
  onToggleFullscreen,
  onResume,
  onCloseApp,
  onSettings,
  onPower,
}: {
  context: "home" | "app" | "game";
  settings: Settings;
  fullscreen: boolean;
  onVolume: (v: number) => void;
  onToggleFullscreen: () => void;
  onResume: () => void;
  onCloseApp: () => void;
  onSettings: () => void;
  onPower: (a: PowerAction) => void;
}) {
  const [mode, setMode] = useState<"main" | "power">("main");
  const [sel, setSel] = useState(context === "home" ? 0 : 0);
  const ic = "h-[46%] w-[46%]";
  const vol = settings.sfx ? settings.volume : 0;

  const main: Item[] = [
    ...(context !== "home"
      ? [
          { id: "resume", label: "Resume", sub: context === "game" ? "Back to game" : "Back to app", icon: <Play className={ic} /> },
          { id: "close", label: context === "game" ? "Close Game" : "Close App", sub: "Return to Home", icon: <Home className={ic} /> },
        ]
      : []),
    { id: "volume", label: "Volume", sub: `${Math.round(vol * 100)}%  ◂ ▸`, icon: vol === 0 ? <VolumeX className={ic} /> : <Volume2 className={ic} /> },
    { id: "fullscreen", label: "Full Screen", sub: fullscreen ? "On" : "Off", icon: fullscreen ? <Minimize className={ic} /> : <Maximize className={ic} /> },
    { id: "settings", label: "Settings", sub: "System", icon: <Gear className={ic} /> },
    { id: "power", label: "Power", sub: "Rest · Restart · Off", icon: <Power className={ic} /> },
  ];
  const power: Item[] = [
    { id: "back", label: "Back", icon: <ArrowLeft className={ic} /> },
    { id: "rest", label: "Enter Rest Mode", icon: <Moon className={ic} /> },
    { id: "restart", label: "Restart PS5", icon: <RotateCw className={ic} /> },
    { id: "off", label: "Turn Off PS5", icon: <X className={ic} />, danger: true },
  ];
  const items = mode === "main" ? main : power;

  const activate = (it: Item) => {
    sfx.select();
    switch (it.id) {
      case "resume":
        return onResume();
      case "close":
        return onCloseApp();
      case "fullscreen":
        return onToggleFullscreen();
      case "settings":
        return onSettings();
      case "power":
        setMode("power");
        return setSel(1);
      case "back":
        setMode("main");
        return setSel(main.length - 1);
      case "rest":
      case "restart":
      case "off":
        return onPower(it.id);
    }
  };

  useNav((a) => {
    if (a === "left" || a === "right") {
      const it = items[sel];
      if (it.id === "volume") {
        const v = Math.max(0, Math.min(1, +(vol + (a === "left" ? -0.1 : 0.1)).toFixed(2)));
        onVolume(v);
        sfx.move();
        return;
      }
      setSel((s) => Math.max(0, Math.min(items.length - 1, s + (a === "left" ? -1 : 1))));
      sfx.move();
    } else if (a === "confirm") activate(items[sel]);
    else if (a === "back") {
      if (mode === "power") {
        setMode("main");
        setSel(main.length - 1);
        sfx.back();
      } else {
        sfx.back();
        onResume();
      }
    } else if (a === "ps") {
      sfx.back();
      onResume();
    }
  }, true, true);

  return (
    <div className="absolute inset-0 z-[75]" onClick={onResume}>
      <div className="anim-fade-in absolute inset-0 bg-gradient-to-t from-black/90 via-black/45 to-black/10" />
      <div className="absolute bottom-0 left-0 right-0 px-[4rem] pb-[4.2rem]" style={{ animation: "slide-up 0.4s cubic-bezier(.2,.8,.2,1) both" }} onClick={(e) => e.stopPropagation()}>
        <div className="mb-[1.6rem] flex items-center gap-3 text-white/70">
          <PSLogo className="h-[1.5rem] text-white/90" />
          <span className="text-[0.8rem] font-semibold uppercase tracking-[0.25em]">{mode === "main" ? "Control Center" : "Power"}</span>
        </div>
        <div className="flex items-start gap-[1.4rem]">
          {items.map((it, i) => {
            const on = sel === i;
            return (
              <button
                key={it.id}
                onMouseEnter={() => setSel(i)}
                onClick={() => activate(it)}
                className="flex w-[8.6rem] flex-col items-center text-center transition-transform duration-200"
                style={{ transform: on ? "translateY(-0.4rem) scale(1.06)" : "none" }}
              >
                <div
                  className={`flex h-[6.2rem] w-[6.2rem] items-center justify-center rounded-full transition-all duration-200 ${
                    on ? `focus-ring ${it.danger ? "bg-[#ff5d6c] text-white" : "bg-white text-black"}` : "glass text-white"
                  }`}
                >
                  {it.icon}
                </div>
                <div className={`mt-[0.8rem] text-[0.92rem] font-semibold ${on ? "text-white" : "text-white/70"}`}>{it.label}</div>
                {it.sub && <div className={`mt-0.5 text-[0.75rem] transition-opacity ${on ? "text-white/65 opacity-100" : "opacity-0"}`}>{it.sub}</div>}
              </button>
            );
          })}
        </div>
      </div>
      <HintBar show={settings.hints}>
        <Hint k="← →">Navigate</Hint>
        <Hint k="Enter" glyph="cross">Select</Hint>
        <Hint k="Esc" glyph="circle">Close</Hint>
      </HintBar>
    </div>
  );
}
