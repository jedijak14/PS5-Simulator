import { useEffect, useState } from "react";
import { Power } from "lucide-react";

/** Console is powered off or in rest mode. Any key / click wakes it. */
export default function OffScreen({ mode, message, onPower }: { mode: "off" | "rest"; message?: string; onPower: () => void }) {
  const [ready, setReady] = useState(false);
  useEffect(() => {
    const t = window.setTimeout(() => setReady(true), 900);
    return () => clearTimeout(t);
  }, []);
  useEffect(() => {
    if (!ready) return;
    const k = (e: KeyboardEvent) => {
      if (["Shift", "Control", "Alt", "Meta"].includes(e.key)) return;
      e.preventDefault();
      onPower();
    };
    window.addEventListener("keydown", k);
    return () => window.removeEventListener("keydown", k);
  }, [ready, onPower]);

  const rest = mode === "rest";
  return (
    <div onPointerDown={() => ready && onPower()} className="absolute inset-0 z-[90] flex cursor-pointer flex-col items-center justify-center bg-black">
      <div className="anim-fade-in flex flex-col items-center gap-6" style={{ animationDelay: "0.6s" }}>
        <div
          className={`flex h-[4.2rem] w-[4.2rem] items-center justify-center rounded-full border ${
            rest ? "border-amber-500/40 text-amber-400" : "border-white/20 text-white/50"
          } anim-breathe`}
        >
          <Power className="h-[1.7rem] w-[1.7rem]" />
        </div>
        <div className="text-center">
          <div className="text-[1.05rem] font-medium tracking-wide text-white/70">{message ?? (rest ? "PS5 is in Rest Mode" : "PS5 is turned off")}</div>
          <div className="mt-2 text-[0.8rem] text-white/35">
            Press <span className="keycap mx-1">Enter</span> or click to {rest ? "wake up" : "turn on"} your PS5
          </div>
        </div>
      </div>
      {/* the console's status light */}
      <div
        className="anim-breathe absolute bottom-[3.2rem] h-[0.28rem] w-[9rem] rounded-full"
        style={{
          background: rest ? "#ff9d1c" : "rgba(255,255,255,0.18)",
          boxShadow: rest ? "0 0 1.4rem 0.3rem rgba(255,150,20,0.55)" : "none",
        }}
      />
    </div>
  );
}
