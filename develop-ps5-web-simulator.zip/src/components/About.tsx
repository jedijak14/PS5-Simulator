import { useEffect, useRef, useState, type ReactNode } from "react";
import { Cpu, MemoryStick, MonitorPlay, HardDrive, Activity, Gauge, Zap } from "lucide-react";
import type { Settings } from "../types";
import { useNav } from "../lib/useNav";
import { sfx } from "../lib/sfx";
import { hash } from "../lib/art";
import { Hint, HintBar, Meter, PSLogo } from "./ui";

interface PerfMemory {
  usedJSHeapSize: number;
  jsHeapSizeLimit: number;
}

function detectGpu(): string {
  try {
    const c = document.createElement("canvas");
    const gl = (c.getContext("webgl") || c.getContext("experimental-webgl")) as WebGLRenderingContext | null;
    if (!gl) return "Unavailable";
    const ext = gl.getExtension("WEBGL_debug_renderer_info");
    const r = ext ? (gl.getParameter(ext.UNMASKED_RENDERER_WEBGL) as string) : (gl.getParameter(gl.RENDERER) as string);
    return r || "Unknown";
  } catch {
    return "Unavailable";
  }
}

function useTelemetry() {
  const [t, setT] = useState({ fps: 60, load: 0.05, heap: 0, heapLimit: 0 });
  useEffect(() => {
    let frames = 0;
    let last = performance.now();
    let raf = 0;
    const count = () => {
      frames++;
      raf = requestAnimationFrame(count);
    };
    raf = requestAnimationFrame(count);
    let expected = performance.now() + 100;
    let lag = 0;
    const lagTimer = window.setInterval(() => {
      const now = performance.now();
      lag = lag * 0.8 + Math.max(0, now - expected) * 0.2;
      expected = now + 100;
    }, 100);
    const report = window.setInterval(() => {
      const now = performance.now();
      const fps = (frames * 1000) / (now - last);
      frames = 0;
      last = now;
      const pm = (performance as unknown as { memory?: PerfMemory }).memory;
      setT({
        fps: Math.min(fps, 240),
        load: Math.min(1, 0.04 + lag / 40),
        heap: pm?.usedJSHeapSize ?? 0,
        heapLimit: pm?.jsHeapSizeLimit ?? 0,
      });
    }, 500);
    return () => {
      cancelAnimationFrame(raf);
      clearInterval(lagTimer);
      clearInterval(report);
    };
  }, []);
  return t;
}

function Console() {
  return (
    <svg viewBox="0 0 200 400" className="h-full drop-shadow-[0_1.5rem_2rem_rgba(0,0,0,0.6)]">
      <defs>
        <linearGradient id="wht" x1="0" x2="1">
          <stop offset="0" stopColor="#c9d1e3" />
          <stop offset=".5" stopColor="#ffffff" />
          <stop offset="1" stopColor="#d7ddec" />
        </linearGradient>
        <linearGradient id="blk" x1="0" x2="1">
          <stop offset="0" stopColor="#05070b" />
          <stop offset="1" stopColor="#1a2030" />
        </linearGradient>
        <filter id="blur"><feGaussianBlur stdDeviation="4" /></filter>
      </defs>
      <ellipse cx="100" cy="390" rx="72" ry="7" fill="#000" opacity=".55" />
      <rect x="62" y="12" width="76" height="364" rx="32" fill="url(#blk)" />
      <rect x="96" y="70" width="8" height="260" rx="4" fill="#4aa3ff" opacity=".7" filter="url(#blur)" className="anim-breathe" />
      <rect x="98" y="72" width="4" height="256" rx="2" fill="#bfe0ff" className="anim-breathe" />
      <path d="M80 6C30 18 16 90 16 200s14 182 64 194C64 336 58 270 58 200S64 62 80 6Z" fill="url(#wht)" />
      <path d="M120 6c50 12 64 84 64 194s-14 182-64 194c16-58 22-124 22-194S136 62 120 6Z" fill="url(#wht)" />
    </svg>
  );
}

function Spec({ icon, title, main, lines, meter }: { icon: ReactNode; title: string; main: string; lines: string[]; meter?: number }) {
  return (
    <div className="glass rounded-[1.1rem] p-[1.2rem]">
      <div className="flex items-center gap-3">
        <div className="flex h-[2.4rem] w-[2.4rem] items-center justify-center rounded-full bg-white/10 p-[0.55rem] text-[#9fd0ff]">{icon}</div>
        <div className="text-[0.75rem] font-semibold uppercase tracking-[0.18em] text-white/55">{title}</div>
      </div>
      <div className="mt-3 text-[1.3rem] font-bold leading-tight">{main}</div>
      <ul className="mt-2 space-y-0.5 text-[0.85rem] text-white/65">
        {lines.map((l) => (
          <li key={l}>{l}</li>
        ))}
      </ul>
      {meter !== undefined && <Meter value={meter} className="mt-3" />}
    </div>
  );
}

function Row({ k, v }: { k: string; v: string }) {
  return (
    <div className="flex items-baseline justify-between gap-6 border-b border-white/10 py-[0.65rem] last:border-0">
      <span className="text-[0.92rem] text-white/60">{k}</span>
      <span className="max-w-[26rem] truncate text-right text-[0.92rem] font-medium" title={v}>{v}</span>
    </div>
  );
}

export default function About({ settings, onClose }: { settings: Settings; onClose: () => void }) {
  const scroller = useRef<HTMLDivElement>(null);
  const tel = useTelemetry();
  const [gpu] = useState(detectGpu);
  const [boot] = useState(() => Date.now());
  const [now, setNow] = useState(Date.now());
  useEffect(() => {
    const t = window.setInterval(() => setNow(Date.now()), 1000);
    return () => clearInterval(t);
  }, []);

  useNav((a) => {
    if (a === "back") {
      sfx.back();
      onClose();
    } else if (a === "down" || a === "up") {
      scroller.current?.scrollBy({ top: a === "down" ? 170 : -170, behavior: "smooth" });
      sfx.move();
    }
  });

  const nav = navigator as Navigator & { deviceMemory?: number; userAgentData?: { platform?: string; brands?: { brand: string }[] } };
  const cores = nav.hardwareConcurrency || 0;
  const mem = nav.deviceMemory;
  const serial = "PS5-" + hash(settings.userName + "ps5").toString(16).toUpperCase().padStart(8, "0") + "-" + (hash("sn" + settings.userName) % 9999).toString().padStart(4, "0");
  const up = Math.floor((now - boot) / 1000);
  const upStr = `${Math.floor(up / 3600)}h ${Math.floor((up % 3600) / 60)}m ${up % 60}s`;
  const fpsRatio = tel.fps / 60;

  return (
    <div className="anim-app-enter absolute inset-0 z-[50] flex bg-[#070a12]/80 backdrop-blur-2xl">
      <div className="relative flex w-[24rem] shrink-0 flex-col items-center justify-center">
        <div className="absolute left-[4rem] top-[2.4rem] flex items-center gap-3 text-white/90">
          <PSLogo className="h-[1.6rem]" />
          <span className="text-[1rem] font-semibold tracking-wide">About</span>
        </div>
        <div className="h-[28rem]">
          <Console />
        </div>
        <div className="mt-[1.2rem] text-center">
          <div className="text-[1.3rem] font-bold">PlayStation 5</div>
          <div className="text-[0.82rem] text-white/50">Model CFI-1215A · Disc Edition</div>
        </div>
      </div>

      <div ref={scroller} className="relative flex-1 overflow-y-auto py-[3rem] pr-[4rem]">
        <div className="mx-auto max-w-[46rem] space-y-[1.8rem]">
          <section className="anim-rise">
            <h2 className="mb-3 text-[0.78rem] font-semibold uppercase tracking-[0.22em] text-white/50">Console Hardware</h2>
            <div className="grid grid-cols-2 gap-[1rem]">
              <Spec icon={<Cpu className="h-full w-full" />} title="Processor" main="AMD Zen 2" lines={["8 cores / 16 threads", "Variable frequency up to 3.5 GHz", "Custom 7 nm SoC"]} meter={0.9} />
              <Spec icon={<MonitorPlay className="h-full w-full" />} title="Graphics (GPU)" main="AMD RDNA 2" lines={["36 CUs @ up to 2.23 GHz", "10.28 TFLOPS · Hardware ray tracing", "Variable-rate shading"]} meter={0.95} />
              <Spec icon={<MemoryStick className="h-full w-full" />} title="Memory (RAM)" main="16 GB GDDR6" lines={["256-bit interface", "448 GB/s bandwidth", "Unified memory architecture"]} meter={0.8} />
              <Spec icon={<HardDrive className="h-full w-full" />} title="Storage" main="825 GB Custom SSD" lines={["5.5 GB/s raw read speed", "NVMe expansion slot", "Ultra-high speed I/O"]} meter={0.7} />
            </div>
          </section>

          <section className="anim-rise" style={{ animationDelay: "0.08s" }}>
            <h2 className="mb-3 text-[0.78rem] font-semibold uppercase tracking-[0.22em] text-white/50">Live Performance</h2>
            <div className="glass grid grid-cols-3 gap-[1.4rem] rounded-[1.1rem] p-[1.3rem]">
              {[
                { icon: <Activity className="h-[1rem] w-[1rem]" />, label: "Frame Rate", val: `${Math.round(tel.fps)} FPS`, v: fpsRatio },
                { icon: <Gauge className="h-[1rem] w-[1rem]" />, label: "System Load", val: `${Math.round(tel.load * 100)}%`, v: tel.load },
                {
                  icon: <Zap className="h-[1rem] w-[1rem]" />,
                  label: "Memory In Use",
                  val: tel.heapLimit ? `${(tel.heap / 1048576).toFixed(0)} MB` : "n/a",
                  v: tel.heapLimit ? tel.heap / tel.heapLimit : 0,
                },
              ].map((m) => (
                <div key={m.label}>
                  <div className="flex items-center gap-2 text-[0.75rem] font-semibold uppercase tracking-wider text-white/55">
                    {m.icon}
                    {m.label}
                  </div>
                  <div className="mb-2 mt-1 text-[1.5rem] font-bold tabular-nums">{m.val}</div>
                  <Meter value={m.v} />
                </div>
              ))}
            </div>
          </section>

          <section className="anim-rise" style={{ animationDelay: "0.16s" }}>
            <h2 className="mb-3 text-[0.78rem] font-semibold uppercase tracking-[0.22em] text-white/50">Host Hardware (Detected)</h2>
            <div className="glass rounded-[1.1rem] px-[1.3rem] py-[0.4rem]">
              <Row k="Processor" v={cores ? `${cores} logical cores` : "Unknown"} />
              <Row k="Memory" v={mem ? `${mem >= 8 ? "8+" : mem} GB (reported)` : "Not reported"} />
              <Row k="Graphics" v={gpu} />
              <Row k="Display" v={`${screen.width} × ${screen.height} @ ${window.devicePixelRatio}x`} />
              <Row k="Output Resolution" v={`${window.innerWidth} × ${window.innerHeight}`} />
              <Row k="Platform" v={nav.userAgentData?.platform || nav.platform || "Unknown"} />
            </div>
          </section>

          <section className="anim-rise pb-[3rem]" style={{ animationDelay: "0.24s" }}>
            <h2 className="mb-3 text-[0.78rem] font-semibold uppercase tracking-[0.22em] text-white/50">System</h2>
            <div className="glass rounded-[1.1rem] px-[1.3rem] py-[0.4rem]">
              <Row k="System Software" v="10.01.00 (Simulator)" />
              <Row k="Serial Number" v={serial} />
              <Row k="Online ID" v={settings.userName} />
              <Row k="Session Uptime" v={upStr} />
            </div>
          </section>
        </div>
      </div>

      <HintBar show={settings.hints}>
        <Hint k="↑ ↓">Scroll</Hint>
        <Hint k="Esc" glyph="circle">Back</Hint>
      </HintBar>
    </div>
  );
}
