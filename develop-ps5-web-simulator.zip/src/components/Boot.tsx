import { useEffect, useRef, useState } from "react";
import { PS5Word, PSLogo } from "./ui";
import { sfx } from "../lib/sfx";

/** The PS5-style power-on sequence: dark void, drifting light, logo bloom, wordmark, dissolve. */
export default function Boot({ quick, onDone }: { quick: boolean; onDone: () => void }) {
  const cv = useRef<HTMLCanvasElement>(null);
  const [leaving, setLeaving] = useState(false);
  const doneRef = useRef(onDone);
  doneRef.current = onDone;

  useEffect(() => {
    const total = quick ? 2800 : 7600;
    const timers: number[] = [];
    if (quick) sfx.ps();
    else sfx.boot();
    let finished = false;
    const finish = () => {
      if (finished) return;
      finished = true;
      setLeaving(true);
      timers.push(window.setTimeout(() => doneRef.current(), 900));
    };
    timers.push(window.setTimeout(finish, total));
    const skip = () => finish();
    const t = window.setTimeout(() => {
      window.addEventListener("keydown", skip);
      window.addEventListener("pointerdown", skip);
    }, 2200);
    return () => {
      timers.forEach(clearTimeout);
      clearTimeout(t);
      window.removeEventListener("keydown", skip);
      window.removeEventListener("pointerdown", skip);
    };
  }, [quick]);

  useEffect(() => {
    const c = cv.current!;
    const ctx = c.getContext("2d")!;
    const resize = () => {
      c.width = window.innerWidth;
      c.height = window.innerHeight;
    };
    resize();
    window.addEventListener("resize", resize);
    const N = 190;
    const P = Array.from({ length: N }, () => ({
      a: Math.random() * Math.PI * 2,
      r: 0.1 + Math.random() * 0.9,
      v: 0.00012 + Math.random() * 0.0004,
      s: 0.5 + Math.random() * 1.8,
      ph: Math.random() * 6.28,
      swirl: (Math.random() - 0.5) * 0.0006,
      hue: Math.random() > 0.55 ? 205 : 220,
    }));
    let raf = 0;
    const t0 = performance.now();
    const loop = (now: number) => {
      const t = (now - t0) / 1000;
      const { width: w, height: h } = c;
      ctx.clearRect(0, 0, w, h);
      const R = Math.hypot(w, h) / 2;
      const cx = w / 2, cy = h / 2;
      ctx.globalCompositeOperation = "lighter";
      // central bloom
      const bloom = Math.min(1, Math.max(0, (t - (quick ? 0.1 : 1.2)) / 1.8));
      const pulse = 0.85 + Math.sin(t * 1.3) * 0.15;
      const g = ctx.createRadialGradient(cx, cy, 0, cx, cy, R * 0.55);
      g.addColorStop(0, `rgba(90,150,255,${0.28 * bloom * pulse})`);
      g.addColorStop(0.45, `rgba(40,80,200,${0.12 * bloom})`);
      g.addColorStop(1, "rgba(0,0,0,0)");
      ctx.fillStyle = g;
      ctx.fillRect(0, 0, w, h);
      // light bar glow along bottom
      const lb = ctx.createRadialGradient(cx, h * 1.02, 0, cx, h * 1.02, w * 0.5);
      lb.addColorStop(0, `rgba(80,140,255,${0.28 * (0.5 + 0.5 * Math.sin(t * 2.2 - 1))})`);
      lb.addColorStop(1, "rgba(0,0,0,0)");
      ctx.fillStyle = lb;
      ctx.fillRect(0, 0, w, h);
      // drifting sparks that spiral slowly inward then get re-seeded outward
      const vis = Math.min(1, t / (quick ? 0.4 : 1.4));
      for (const p of P) {
        p.r -= p.v * 16 * (0.5 + bloom);
        p.a += p.swirl * 16;
        if (p.r < 0.04) {
          p.r = 1;
          p.a = Math.random() * 6.28;
        }
        const x = cx + Math.cos(p.a) * p.r * R * 1.05;
        const y = cy + Math.sin(p.a) * p.r * R * 0.62;
        const tw = 0.45 + 0.55 * Math.sin(t * 2.4 + p.ph);
        const fade = Math.min(1, p.r * 2.4);
        ctx.globalAlpha = Math.max(0, tw * fade * vis);
        ctx.fillStyle = `hsl(${p.hue} 100% 82%)`;
        ctx.beginPath();
        ctx.arc(x, y, p.s, 0, 6.3);
        ctx.fill();
        if (p.s > 1.7) {
          ctx.globalAlpha *= 0.25;
          ctx.beginPath();
          ctx.arc(x, y, p.s * 4, 0, 6.3);
          ctx.fill();
        }
      }
      ctx.globalAlpha = 1;
      raf = requestAnimationFrame(loop);
    };
    raf = requestAnimationFrame(loop);
    return () => {
      cancelAnimationFrame(raf);
      window.removeEventListener("resize", resize);
    };
  }, [quick]);

  const d = quick ? 0.15 : 1.7;
  return (
    <div className={`absolute inset-0 z-[100] overflow-hidden bg-black transition-opacity duration-[900ms] ${leaving ? "opacity-0" : "opacity-100"}`}>
      <canvas ref={cv} className="anim-fade-in absolute inset-0 h-full w-full" style={{ animationDuration: "2.5s" }} />
      <div className="absolute inset-0 flex flex-col items-center justify-center">
        <div style={{ animation: `logo-in 2.4s cubic-bezier(.2,.8,.2,1) ${d}s both` }}>
          <PSLogo className="w-[13rem] text-white drop-shadow-[0_0_2.5rem_rgba(120,170,255,0.75)]" />
        </div>
        <div style={{ animation: `rise-in 1.6s cubic-bezier(.2,.8,.2,1) ${quick ? 0.6 : 4.1}s both` }} className="mt-[1.6rem]">
          <PS5Word className="w-[8.5rem] text-white/95 drop-shadow-[0_0_1.2rem_rgba(120,170,255,0.6)]" />
        </div>
      </div>
      {!quick && (
        <div className="anim-fade-in absolute bottom-6 w-full text-center text-[0.7rem] tracking-[0.25em] text-white/25" style={{ animationDelay: "3s" }}>
          PRESS ANY KEY TO SKIP
        </div>
      )}
    </div>
  );
}
