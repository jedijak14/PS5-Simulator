import { useMemo, useRef, useState } from "react";
import { Check, FileUp, Image as ImageIcon, Type, Layers, Sparkles } from "lucide-react";
import type { Game } from "../types";
import { useNav } from "../lib/useNav";
import { sfx } from "../lib/sfx";
import { buildArt, fileToDataUrl } from "../lib/art";
import { saveGame } from "../lib/store";
import { Hint, HintBar } from "./ui";

type Slot = "cover" | "background" | "logo";

export default function InstallGame({
  showHints,
  onClose,
  onInstalled,
}: {
  showHints: boolean;
  onClose: () => void;
  onInstalled: (g: Game) => void;
}) {
  const [title, setTitle] = useState("");
  const [file, setFile] = useState<{ name: string; html: string } | null>(null);
  const [art, setArt] = useState<Record<Slot, string | null>>({ cover: null, background: null, logo: null });
  const [row, setRow] = useState(0);
  const [btn, setBtn] = useState(0);
  const [err, setErr] = useState("");
  const [progress, setProgress] = useState<number | null>(null);

  const titleRef = useRef<HTMLInputElement>(null);
  const gameRef = useRef<HTMLInputElement>(null);
  const slotRefs = { cover: useRef<HTMLInputElement>(null), background: useRef<HTMLInputElement>(null), logo: useRef<HTMLInputElement>(null) };

  const fallback = useMemo(() => buildArt(title || "Untitled Game"), [title]);
  const cover = art.cover ?? fallback.cover;
  const background = art.background ?? fallback.background;
  const logo = art.logo ?? fallback.logo;

  const rows: { label: string; hint: string; icon: React.ReactNode; slot?: Slot }[] = [
    { label: "Game Title", hint: "Name shown on the home screen", icon: <Type className="h-full w-full" /> },
    { label: "Game File", hint: file ? file.name : "Choose the game data to install (required)", icon: <FileUp className="h-full w-full" /> },
    { label: "Cover Art", hint: art.cover ? "Custom image selected" : "Square tile image (optional – auto-generated)", icon: <ImageIcon className="h-full w-full" />, slot: "cover" },
    { label: "Background", hint: art.background ? "Custom image selected" : "Wide key art shown behind the tile (optional)", icon: <Layers className="h-full w-full" />, slot: "background" },
    { label: "Logo", hint: art.logo ? "Custom image selected" : "Transparent title logo (optional)", icon: <Sparkles className="h-full w-full" />, slot: "logo" },
  ];
  const ROWS = rows.length + 1; // + buttons row

  const pickSlot = async (slot: Slot, f: File | undefined) => {
    if (!f) return;
    try {
      const url = await fileToDataUrl(f, slot === "background" ? 1920 : slot === "cover" ? 640 : 900, slot === "logo" ? "image/png" : "image/jpeg");
      setArt((a) => ({ ...a, [slot]: url }));
      sfx.select();
    } catch {
      setErr("That image couldn't be read.");
      sfx.error();
    }
  };

  const pickGame = async (f: File | undefined) => {
    if (!f) return;
    const text = await f.text();
    if (!/<\s*(html|script|body|canvas|!doctype)/i.test(text)) {
      setErr("This file doesn't look like valid game data.");
      sfx.error();
      return;
    }
    setFile({ name: f.name, html: text });
    setErr("");
    if (!title) setTitle(f.name.replace(/\.[^.]+$/, "").replace(/[-_]+/g, " ").replace(/\b\w/g, (c) => c.toUpperCase()));
    sfx.select();
  };

  const install = async () => {
    if (progress !== null) return;
    if (!title.trim()) {
      setErr("Enter a title for the game.");
      sfx.error();
      setRow(0);
      return;
    }
    if (!file) {
      setErr("Choose a game file to install.");
      sfx.error();
      setRow(1);
      return;
    }
    setErr("");
    sfx.select();
    setProgress(0);
    const game: Game = {
      id: "g-" + Date.now().toString(36),
      title: title.trim(),
      html: file.html,
      cover,
      background,
      logo,
      addedAt: Date.now(),
      playtime: 0,
    };
    const start = performance.now();
    const dur = 1700;
    const saving = saveGame(game).catch(() => undefined);
    await new Promise<void>((res) => {
      const tick = () => {
        const p = Math.min(1, (performance.now() - start) / dur);
        setProgress(p);
        if (p < 1) requestAnimationFrame(tick);
        else res();
      };
      tick();
    });
    await saving;
    onInstalled(game);
  };

  const activate = (r: number) => {
    if (r === 0) titleRef.current?.focus();
    else if (r === 1) gameRef.current?.click();
    else if (r <= 4) slotRefs[rows[r].slot!].current?.click();
    else if (btn === 0) {
      sfx.back();
      onClose();
    } else void install();
  };

  useNav((a) => {
    if (progress !== null) return;
    const typing = document.activeElement === titleRef.current;
    if (a === "back") {
      if (typing) titleRef.current?.blur();
      else {
        sfx.back();
        onClose();
      }
      return;
    }
    if (typing) return;
    if (a === "up") {
      setRow((r) => Math.max(0, r - 1));
      sfx.move();
    } else if (a === "down") {
      setRow((r) => Math.min(ROWS - 1, r + 1));
      sfx.move();
    } else if ((a === "left" || a === "right") && row === ROWS - 1) {
      setBtn(a === "left" ? 0 : 1);
      sfx.move();
    } else if (a === "confirm") activate(row);
  }, true, true);

  return (
    <div className="anim-app-enter absolute inset-0 z-[60] flex overflow-hidden bg-[#06080f]">
      <div className="absolute inset-0">
        <img src={background} alt="" className="h-full w-full scale-110 object-cover opacity-40 blur-2xl" />
        <div className="absolute inset-0 bg-gradient-to-r from-black/90 via-black/70 to-black/40" />
      </div>

      {/* form */}
      <div className="relative z-10 flex w-[44rem] flex-col px-[4rem] pt-[3.2rem]">
        <div className="text-[0.75rem] font-semibold uppercase tracking-[0.25em] text-white/50">Game Library</div>
        <h1 className="mt-1 text-[2.2rem] font-bold">Install Game</h1>
        <div className="mt-[1.6rem] flex flex-col gap-[0.5rem]">
          {rows.map((r, i) => {
            const sel = row === i;
            const done = i === 1 ? !!file : i >= 2 ? !!art[r.slot!] : title.trim().length > 0;
            return (
              <div
                key={r.label}
                onMouseEnter={() => progress === null && setRow(i)}
                onClick={() => i !== 0 && activate(i)}
                className={`flex cursor-pointer items-center gap-4 rounded-[0.9rem] px-[1.1rem] py-[0.8rem] transition-all duration-150 ${sel ? "bg-white text-black shadow-[0_0_1.6rem_rgba(255,255,255,0.25)]" : "bg-white/[0.07] text-white"}`}
              >
                <div className={`h-[1.5rem] w-[1.5rem] ${sel ? "text-black/70" : "text-white/60"}`}>{r.icon}</div>
                <div className="min-w-0 flex-1">
                  <div className="text-[0.98rem] font-semibold">{r.label}</div>
                  {i === 0 ? (
                    <input
                      ref={titleRef}
                      value={title}
                      onChange={(e) => setTitle(e.target.value)}
                      onKeyDown={(e) => {
                        if (e.key === "Enter" || e.key === "ArrowDown") {
                          e.preventDefault();
                          titleRef.current?.blur();
                          setRow(1);
                          sfx.move();
                        }
                      }}
                      onFocus={() => setRow(0)}
                      maxLength={40}
                      placeholder="Enter game title"
                      className={`mt-0.5 w-full bg-transparent text-[0.85rem] outline-none ${sel ? "text-black/80 placeholder:text-black/40" : "text-white/70 placeholder:text-white/35"}`}
                    />
                  ) : (
                    <div className={`truncate text-[0.82rem] ${sel ? "text-black/60" : "text-white/50"}`}>{r.hint}</div>
                  )}
                </div>
                {done && <Check className={`h-[1.3rem] w-[1.3rem] ${sel ? "text-emerald-600" : "text-emerald-400"}`} />}
              </div>
            );
          })}

          <div className="mt-[0.8rem] flex items-center gap-[0.8rem]">
            {["Cancel", "Install"].map((l, i) => (
              <button
                key={l}
                onMouseEnter={() => {
                  setRow(ROWS - 1);
                  setBtn(i);
                }}
                onClick={() => (i === 0 ? onClose() : void install())}
                className={`min-w-[9.5rem] rounded-full px-[1.6rem] py-[0.7rem] text-[0.98rem] font-bold transition-all duration-150 ${
                  row === ROWS - 1 && btn === i ? "focus-ring scale-105 bg-white text-black" : "bg-white/12 text-white/80"
                }`}
              >
                {l}
              </button>
            ))}
            {err && <span className="anim-pop ml-2 text-[0.85rem] font-medium text-[#ff8a95]">{err}</span>}
          </div>
        </div>
      </div>

      {/* preview */}
      <div className="relative z-10 flex flex-1 flex-col items-center justify-center pr-[4rem]">
        <div className="text-[0.75rem] font-semibold uppercase tracking-[0.25em] text-white/45">Preview</div>
        <div className="relative mt-[1.1rem] aspect-video w-[30rem] overflow-hidden rounded-[1.2rem] shadow-2xl ring-1 ring-white/15">
          <img src={background} alt="" className="absolute inset-0 h-full w-full object-cover" />
          <div className="absolute inset-0 bg-gradient-to-r from-black/70 to-transparent" />
          <img src={logo} alt="" className="absolute bottom-[1.4rem] left-[1.4rem] max-h-[5rem] max-w-[14rem] object-contain object-left-bottom" />
        </div>
        <div className="mt-[1.4rem] flex items-end gap-[1.2rem]">
          <img src={cover} alt="" className="h-[9.4rem] w-[9.4rem] rounded-[1.1rem] object-cover shadow-xl ring-2 ring-white/70" />
          <div className="pb-1">
            <div className="max-w-[16rem] truncate text-[1.1rem] font-semibold">{title || "Untitled Game"}</div>
            <div className="text-[0.8rem] text-white/55">Game · PS5</div>
          </div>
        </div>
      </div>

      <input ref={gameRef} type="file" accept=".html,.htm,text/html" className="hidden" onChange={(e) => { void pickGame(e.target.files?.[0]); e.target.value = ""; }} />
      {(["cover", "background", "logo"] as Slot[]).map((s) => (
        <input key={s} ref={slotRefs[s]} type="file" accept="image/*" className="hidden" onChange={(e) => { void pickSlot(s, e.target.files?.[0]); e.target.value = ""; }} />
      ))}

      {progress !== null && (
        <div className="anim-fade-in absolute inset-0 z-20 flex flex-col items-center justify-center bg-black/80 backdrop-blur-md">
          <img src={cover} alt="" className="h-[9rem] w-[9rem] rounded-[1.1rem] object-cover shadow-2xl" />
          <div className="mt-6 text-[1.2rem] font-semibold">{progress < 1 ? "Installing…" : "Installed"}</div>
          <div className="mt-4 h-[0.35rem] w-[22rem] overflow-hidden rounded-full bg-white/15">
            <div className="h-full rounded-full bg-gradient-to-r from-[#4aa3ff] to-[#b6e6ff]" style={{ width: `${progress * 100}%` }} />
          </div>
          <div className="mt-2 text-[0.8rem] tabular-nums text-white/55">{Math.round(progress * 100)}%</div>
        </div>
      )}

      <HintBar show={showHints}>
        <Hint k="↑ ↓">Navigate</Hint>
        <Hint k="Enter" glyph="cross">Select</Hint>
        <Hint k="Esc" glyph="circle">Back</Hint>
      </HintBar>
    </div>
  );
}
