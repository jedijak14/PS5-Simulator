import { useEffect, useRef, useState } from "react";
import type { Game } from "../types";
import { addPlaytime } from "../lib/store";
import { Spinner } from "./ui";

/* Injected into every game so the PS button (F1) still works while the game has keyboard focus. */
const BRIDGE =
  '<script>addEventListener("keydown",function(e){if(e.key==="F1"){e.preventDefault();e.stopPropagation();parent.postMessage({ps5:"ps"},"*")}},true);<' +
  "/script>";

function inject(html: string): string {
  const m = html.match(/<head[^>]*>/i) || html.match(/<html[^>]*>/i);
  if (m && m.index !== undefined) {
    const at = m.index + m[0].length;
    return html.slice(0, at) + BRIDGE + html.slice(at);
  }
  const dt = html.match(/<!doctype[^>]*>/i);
  if (dt && dt.index !== undefined) {
    const at = dt.index + dt[0].length;
    return html.slice(0, at) + BRIDGE + html.slice(at);
  }
  return BRIDGE + html;
}

export default function GameRunner({ game, paused, onPS }: { game: Game; paused: boolean; onPS: () => void }) {
  const [mounted, setMounted] = useState(false);
  const [splash, setSplash] = useState<"show" | "fade" | "gone">("show");
  const [tip, setTip] = useState(false);
  const frame = useRef<HTMLIFrameElement>(null);
  const startedAt = useRef(0);
  const onPSRef = useRef(onPS);
  onPSRef.current = onPS;

  useEffect(() => {
    const t1 = window.setTimeout(() => {
      setMounted(true);
      startedAt.current = Date.now();
    }, 2300);
    const t2 = window.setTimeout(() => setSplash("fade"), 2700);
    const t3 = window.setTimeout(() => {
      setSplash("gone");
      setTip(true);
    }, 3500);
    const t4 = window.setTimeout(() => setTip(false), 7500);
    const onMsg = (e: MessageEvent) => {
      if (e.data && e.data.ps5 === "ps") onPSRef.current();
    };
    window.addEventListener("message", onMsg);
    return () => {
      [t1, t2, t3, t4].forEach(clearTimeout);
      window.removeEventListener("message", onMsg);
      if (startedAt.current) addPlaytime(game.id, Math.round((Date.now() - startedAt.current) / 1000));
    };
  }, [game.id]);

  // hand keyboard focus between the game and the console UI
  useEffect(() => {
    if (!mounted) return;
    if (paused) {
      (document.activeElement as HTMLElement | null)?.blur();
      window.focus();
    } else {
      const t = window.setTimeout(() => {
        frame.current?.focus();
        frame.current?.contentWindow?.focus();
      }, 50);
      return () => clearTimeout(t);
    }
  }, [paused, mounted]);

  return (
    <div className="absolute inset-0 bg-black">
      {mounted && (
        <iframe
          ref={frame}
          title={game.title}
          srcDoc={inject(game.html)}
          sandbox="allow-scripts allow-same-origin allow-pointer-lock allow-forms allow-modals allow-popups allow-downloads"
          allow="autoplay; fullscreen; gamepad; clipboard-write"
          className="anim-fade-in absolute inset-0 h-full w-full border-0 bg-black"
          onLoad={() => {
            frame.current?.focus();
            frame.current?.contentWindow?.focus();
          }}
        />
      )}

      {splash !== "gone" && (
        <div className={`absolute inset-0 z-10 overflow-hidden bg-black transition-opacity duration-[800ms] ${splash === "fade" ? "opacity-0" : "opacity-100"}`}>
          <img src={game.background} alt="" className="absolute inset-0 h-full w-full object-cover" style={{ animation: "zoom-slow 6s ease-out both" }} />
          <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,rgba(0,0,0,0.1),rgba(0,0,0,0.75))]" />
          <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-transparent to-black/40" />
          <div className="absolute inset-0 flex items-center justify-center">
            <img
              src={game.logo}
              alt={game.title}
              className="max-h-[14rem] max-w-[34rem] object-contain drop-shadow-[0_0.5rem_2rem_rgba(0,0,0,0.7)]"
              style={{ animation: "logo-in 1.2s cubic-bezier(.2,.8,.2,1) 0.25s both" }}
            />
          </div>
          <div className="anim-fade-in absolute bottom-[2.4rem] right-[3.2rem] flex items-center gap-4" style={{ animationDelay: "0.6s" }}>
            <span className="text-[0.95rem] font-medium text-white/80">Starting {game.title}…</span>
            <Spinner />
          </div>
        </div>
      )}

      {tip && (
        <div className="anim-fade-in pointer-events-none absolute bottom-[2rem] left-1/2 z-20 flex -translate-x-1/2 items-center gap-3 rounded-full bg-black/60 px-5 py-[0.55rem] text-[0.85rem] text-white/90 backdrop-blur-md">
          Press <span className="keycap">F1</span> for the PS button
        </div>
      )}
    </div>
  );
}
