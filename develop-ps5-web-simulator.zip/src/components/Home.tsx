import { useEffect, useLayoutEffect, useMemo, useRef, useState, type ReactNode } from "react";
import { Globe, Info, Play, Plus, Settings as Gear, Clapperboard, Trash2, Trophy, Clock, CalendarDays, MoreHorizontal, FolderPlus } from "lucide-react";
import type { AppId, Game, Settings } from "../types";
import { useNav } from "../lib/useNav";
import { sfx } from "../lib/sfx";
import { hash } from "../lib/art";
import { Avatar, ConfirmDialog, Hint, HintBar, OptionsPanel } from "./ui";

interface Tile {
  key: string;
  kind: "game" | "app" | "install";
  title: string;
  subtitle: string;
  cover?: string;
  bg?: string;
  logo?: string;
  gradient: string;
  icon: ReactNode;
  desc: string;
  game?: Game;
  appId?: AppId;
}

const fmtTime = (s: number) => {
  if (s < 60) return s < 5 ? "Just started" : `${Math.round(s)} sec`;
  if (s < 3600) return `${Math.round(s / 60)} min`;
  return `${(s / 3600).toFixed(1)} hrs`;
};
const fmtAgo = (t?: number) => {
  if (!t) return "Never";
  const d = (Date.now() - t) / 1000;
  if (d < 60) return "Just now";
  if (d < 3600) return `${Math.round(d / 60)} min ago`;
  if (d < 86400) return `${Math.round(d / 3600)} hr ago`;
  return new Date(t).toLocaleDateString();
};

const APP_TILES: Tile[] = [
  {
    key: "app-browser",
    kind: "app",
    appId: "browser",
    title: "Web Browser",
    subtitle: "Media · App",
    gradient: "linear-gradient(135deg,#0a3a8a,#2b7fff 60%,#7cc4ff)",
    icon: <Globe className="h-[46%] w-[46%]" strokeWidth={1.4} />,
    desc: "Browse the web right from your console. Search Wikipedia, open sites, and explore.",
  },
  {
    key: "app-media",
    kind: "app",
    appId: "media",
    title: "Media Player",
    subtitle: "Media · App",
    gradient: "linear-gradient(135deg,#3b0a6b,#a23cff 60%,#ff7ad0)",
    icon: <Clapperboard className="h-[46%] w-[46%]" strokeWidth={1.4} />,
    desc: "Play your own music, videos and photos. Add files from your device and enjoy them on the big screen.",
  },
];

function CrossFade({ src, className = "" }: { src: string | null; className?: string }) {
  const [layers, setLayers] = useState<{ cur: string | null; prev: string | null }>({ cur: src, prev: null });
  useEffect(() => {
    setLayers((l) => (l.cur === src ? l : { cur: src, prev: l.cur }));
    const t = window.setTimeout(() => setLayers((l) => ({ ...l, prev: null })), 700);
    return () => clearTimeout(t);
  }, [src]);
  return (
    <>
      {layers.prev && <img src={layers.prev} alt="" className={className} draggable={false} />}
      {layers.cur && <img key={layers.cur} src={layers.cur} alt="" draggable={false} className={`${className} anim-fade-in`} style={{ animationDuration: "0.6s" }} />}
    </>
  );
}

export default function Home({
  active,
  intro,
  returnKey,
  games,
  settings,
  onLaunchGame,
  onOpenApp,
  onInstall,
  onDeleteGame,
}: {
  active: boolean;
  intro: boolean;
  returnKey: number;
  games: Game[];
  settings: Settings;
  onLaunchGame: (g: Game) => void;
  onOpenApp: (id: AppId) => void;
  onInstall: () => void;
  onDeleteGame: (g: Game) => void;
}) {
  const [zone, setZone] = useState<"top" | "tiles">("tiles");
  const [tab, setTab] = useState<"games" | "media">("games");
  const [topIdx, setTopIdx] = useState(0);
  const [idx, setIdx] = useState({ games: 0, media: 0 });
  const [options, setOptions] = useState(false);
  const [confirm, setConfirm] = useState<Game | null>(null);
  const [clock, setClock] = useState(() => new Date());

  useEffect(() => {
    const t = window.setInterval(() => setClock(new Date()), 10000);
    return () => clearInterval(t);
  }, []);

  const sorted = useMemo(
    () => [...games].sort((a, b) => (b.lastPlayed ?? 0) - (a.lastPlayed ?? 0) || b.addedAt - a.addedAt),
    [games]
  );

  const tiles: Tile[] = useMemo(() => {
    if (tab === "media") return APP_TILES;
    const gt: Tile[] = sorted.map((g) => ({
      key: g.id,
      kind: "game",
      title: g.title,
      subtitle: g.lastPlayed ? "Game · PS5" : "Game · New",
      cover: g.cover,
      bg: g.background,
      logo: g.logo,
      gradient: "#222",
      icon: null,
      desc: "",
      game: g,
    }));
    gt.push({
      key: "install",
      kind: "install",
      title: "Install Game",
      subtitle: "Add a game to your library",
      gradient: "linear-gradient(135deg,#1c2330,#2f3b52)",
      icon: <Plus className="h-[40%] w-[40%]" strokeWidth={1.2} />,
      desc: "Add a new game to this console. Provide the game file along with its cover, background and logo artwork.",
    });
    return gt;
  }, [tab, sorted]);

  const cur = Math.min(idx[tab], tiles.length - 1);
  const tile = tiles[cur];

  // keep selection valid when game list shrinks
  useEffect(() => {
    setIdx((i) => (i[tab] > tiles.length - 1 ? { ...i, [tab]: tiles.length - 1 } : i));
  }, [tiles.length, tab]);

  /* --- row scrolling --- */
  const refs = useRef<(HTMLDivElement | null)[]>([]);
  const [shift, setShift] = useState(0);
  useLayoutEffect(() => {
    const el = refs.current[cur];
    if (!el) return;
    const rem = parseFloat(getComputedStyle(document.documentElement).fontSize);
    setShift(el.offsetLeft - rem * 4);
  }, [cur, tab, tiles.length]);

  const play = (t: Tile) => {
    sfx.select();
    if (t.kind === "game" && t.game) onLaunchGame(t.game);
    else if (t.kind === "app" && t.appId) onOpenApp(t.appId);
    else if (t.kind === "install") onInstall();
  };

  const setCur = (i: number) => setIdx((s) => ({ ...s, [tab]: i }));

  const TOP_COUNT = 4;
  useNav(
    (a) => {
      if (zone === "tiles") {
        if (a === "left" && cur > 0) {
          setCur(cur - 1);
          sfx.move();
        } else if (a === "right" && cur < tiles.length - 1) {
          setCur(cur + 1);
          sfx.move();
        } else if (a === "up") {
          setZone("top");
          setTopIdx(tab === "games" ? 0 : 1);
          sfx.move();
        } else if (a === "confirm") play(tile);
        else if (a === "options") {
          sfx.select();
          setOptions(true);
        }
      } else {
        if (a === "left" && topIdx > 0) {
          const n = topIdx - 1;
          setTopIdx(n);
          if (n < 2) setTab(n === 0 ? "games" : "media");
          sfx.move();
        } else if (a === "right" && topIdx < TOP_COUNT - 1) {
          const n = topIdx + 1;
          setTopIdx(n);
          if (n < 2) setTab(n === 0 ? "games" : "media");
          sfx.move();
        } else if (a === "down") {
          setZone("tiles");
          sfx.move();
        } else if (a === "confirm") {
          if (topIdx < 2) {
            sfx.select();
            setZone("tiles");
          } else {
            sfx.select();
            onOpenApp(topIdx === 2 ? "settings" : "about");
          }
        }
      }
    },
    active && !options && !confirm
  );

  const trophy = tile?.game ? hash(tile.game.id) % 100 : 0;
  const optionItems = !tile
    ? []
    : [
        { label: tile.kind === "game" ? "Play" : tile.kind === "install" ? "Install Game" : "Open", icon: <Play className="h-full w-full" />, onSelect: () => { setOptions(false); play(tile); } },
        ...(tile.kind === "game" && tile.game
          ? [{ label: "Delete", danger: true, icon: <Trash2 className="h-full w-full" />, onSelect: () => { setOptions(false); setConfirm(tile.game!); } }]
          : []),
      ];

  const bgUrl = tile?.bg ?? null;
  const topItems: { label?: string; icon?: ReactNode }[] = [
    { label: "Games" },
    { label: "Media" },
    { icon: <Gear className="h-full w-full" /> },
    { icon: <Info className="h-full w-full" /> },
  ];

  const time = clock.toLocaleTimeString([], { hour: "numeric", minute: "2-digit" });

  return (
    <div key={returnKey} className={`absolute inset-0 overflow-hidden ${intro ? "anim-home-intro" : "anim-home-return"}`}>
      {/* key art */}
      <div className="absolute inset-0">
        <CrossFade src={bgUrl} className="absolute inset-0 h-full w-full object-cover" />
        {!bgUrl && tile && (
          <div key={tile.key} className="anim-fade-in absolute inset-0 opacity-70" style={{ background: tile.gradient, animationDuration: "0.6s" }}>
            <div className="absolute inset-0 bg-[radial-gradient(circle_at_75%_35%,rgba(255,255,255,0.22),transparent_55%)]" />
          </div>
        )}
        <div className="absolute inset-0 bg-gradient-to-r from-black/75 via-black/25 to-black/10" />
        <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-black/15 to-black/50" />
      </div>

      {/* top bar */}
      <div className="absolute left-0 right-0 top-0 z-10 flex items-center justify-between px-[4rem] pt-[1.6rem]">
        <div className="flex items-center gap-[2.2rem]">
          {topItems.slice(0, 2).map((it, i) => {
            const on = tab === (i === 0 ? "games" : "media");
            const focus = zone === "top" && topIdx === i;
            return (
              <button
                key={it.label}
                onClick={() => {
                  setTab(i === 0 ? "games" : "media");
                  setTopIdx(i);
                  sfx.move();
                }}
                className={`relative pb-[0.45rem] text-[1.25rem] transition-all duration-200 ${on ? "font-semibold text-white" : "font-medium text-white/50"} ${focus ? "scale-110" : ""}`}
              >
                {it.label}
                <span className={`absolute -bottom-[0.05rem] left-0 h-[0.18rem] rounded-full bg-white transition-all duration-300 ${on ? "w-full opacity-100" : "w-0 opacity-0"}`} />
                {focus && <span className="focus-ring absolute -inset-x-[0.9rem] -inset-y-[0.2rem] rounded-full" />}
              </button>
            );
          })}
        </div>
        <div className="flex items-center gap-[1.4rem]">
          {topItems.slice(2).map((it, k) => {
            const i = k + 2;
            const focus = zone === "top" && topIdx === i;
            return (
              <button
                key={i}
                onClick={() => onOpenApp(i === 2 ? "settings" : "about")}
                onMouseMove={() => { setZone("top"); setTopIdx(i); }}
                title={i === 2 ? "Settings" : "About"}
                className={`flex h-[2.5rem] w-[2.5rem] items-center justify-center rounded-full p-[0.6rem] transition-all duration-200 ${focus ? "focus-ring scale-110 bg-white/20 text-white" : "text-white/80"}`}
              >
                {it.icon}
              </button>
            );
          })}
          <div className="flex items-center gap-3 pl-1">
            <Avatar name={settings.userName} hue={settings.avatarHue} />
            <span className="text-[1.05rem] font-medium tabular-nums">{time}</span>
          </div>
        </div>
      </div>

      {/* tile row */}
      <div
        className="absolute left-0 right-0 top-[6.2rem] z-10 h-[16rem] overflow-hidden"
        style={{ WebkitMaskImage: "linear-gradient(to right, transparent 0, #000 3.2rem, #000 100%)", maskImage: "linear-gradient(to right, transparent 0, #000 3.2rem, #000 100%)" }}
      >
        <div key={tab} className="anim-rise absolute inset-0">
        <div className="absolute left-0 top-0 flex items-start gap-[1rem] px-[4rem] pt-[0.9rem] transition-transform duration-[450ms] ease-[cubic-bezier(0.2,0.8,0.2,1)]" style={{ transform: `translateX(${-shift}px)`, width: "max-content" }}>
          {tiles.map((t, i) => {
            const sel = i === cur;
            const focused = sel && zone === "tiles";
            const size = sel ? "12.4rem" : "9.4rem";
            return (
              <div
                key={t.key}
                ref={(el) => {
                  refs.current[i] = el;
                }}
                onMouseMove={() => {
                  if (!active) return;
                  if (i !== cur || zone !== "tiles") sfx.move();
                  setCur(i);
                  setZone("tiles");
                }}
                onClick={() => play(t)}
                className="relative shrink-0 cursor-pointer transition-all duration-[350ms] ease-[cubic-bezier(0.2,0.8,0.2,1)]"
                style={{ width: size, height: size, opacity: sel ? 1 : 0.9 }}
              >
                <div
                  className={`relative h-full w-full overflow-hidden rounded-[1.1rem] transition-shadow duration-300 ${focused ? "focus-ring" : sel ? "shadow-[0_0_0_0.12rem_rgba(255,255,255,0.5)]" : "shadow-lg shadow-black/50"}`}
                  style={{ background: t.cover ? "#111" : t.gradient }}
                >
                  {t.cover ? (
                    <img src={t.cover} alt={t.title} draggable={false} className="h-full w-full object-cover" />
                  ) : (
                    <div className="flex h-full w-full flex-col items-center justify-center text-white">
                      {t.icon}
                    </div>
                  )}
                  {focused && <div className="pointer-events-none absolute inset-y-0 left-0 w-1/3" style={{ animation: "sheen 2.8s ease-in-out infinite", background: "linear-gradient(90deg,transparent,rgba(255,255,255,0.28),transparent)" }} />}
                  <div className="pointer-events-none absolute inset-0 rounded-[1.1rem] bg-gradient-to-b from-white/10 to-transparent" />
                </div>
                <div className={`absolute left-0 right-0 top-full pt-[0.7rem] transition-opacity duration-300 ${sel ? "opacity-100" : "opacity-0"}`}>
                  <div className="truncate text-[0.95rem] font-semibold">{t.title}</div>
                </div>
              </div>
            );
          })}
        </div>
        </div>
      </div>

      {/* selected item info */}
      {tile && (
        <div key={tile.key} className="anim-rise absolute left-[4rem] right-[4rem] top-[23.6rem] z-10" style={{ animationDuration: "0.5s" }}>
          <div className="flex h-[5.4rem] items-end">
            {tile.logo ? (
              <img src={tile.logo} alt={tile.title} draggable={false} className="max-h-full max-w-[24rem] object-contain object-left-bottom drop-shadow-[0_0.3rem_1rem_rgba(0,0,0,0.6)]" />
            ) : (
              <h1 className="text-[2.6rem] font-bold leading-none tracking-tight drop-shadow-[0_0.2rem_1rem_rgba(0,0,0,0.6)]">{tile.title}</h1>
            )}
          </div>
          <div className="mt-[0.4rem] text-[0.85rem] font-medium text-white/65">{tile.subtitle}</div>
          <div className="mt-[1rem] flex items-center gap-[0.9rem]">
            <button
              onClick={() => play(tile)}
              className="flex items-center gap-[0.6rem] rounded-full bg-white px-[1.9rem] py-[0.65rem] text-[1.02rem] font-bold text-black shadow-[0_0.4rem_1.6rem_rgba(0,0,0,0.45)] transition-transform hover:scale-105"
            >
              {tile.kind === "install" ? <FolderPlus className="h-[1.1rem] w-[1.1rem]" /> : <Play className="h-[1.1rem] w-[1.1rem] fill-black" />}
              {tile.kind === "game" ? "Play Game" : tile.kind === "install" ? "Install" : "Open"}
            </button>
            <button onClick={() => setOptions(true)} className="glass flex h-[2.6rem] w-[2.6rem] items-center justify-center rounded-full text-white/90 transition-transform hover:scale-110">
              <MoreHorizontal className="h-[1.2rem] w-[1.2rem]" />
            </button>
          </div>

          <div className="mt-[1.7rem] flex gap-[1rem]">
            {tile.kind === "game" && tile.game ? (
              <>
                <InfoCard icon={<Clock className="h-[1.1rem] w-[1.1rem]" />} label="Time Played" value={fmtTime(tile.game.playtime)} />
                <InfoCard icon={<CalendarDays className="h-[1.1rem] w-[1.1rem]" />} label="Last Played" value={fmtAgo(tile.game.lastPlayed)} />
                <div className="glass flex w-[16rem] items-center gap-[1rem] rounded-[1rem] px-[1.1rem] py-[0.9rem]">
                  <div className="relative h-[3rem] w-[3rem]">
                    <svg viewBox="0 0 36 36" className="h-full w-full -rotate-90">
                      <circle cx="18" cy="18" r="15" fill="none" stroke="rgba(255,255,255,0.15)" strokeWidth="3" />
                      <circle cx="18" cy="18" r="15" fill="none" stroke="#7cc4ff" strokeWidth="3" strokeLinecap="round" strokeDasharray={`${(trophy / 100) * 94.2} 94.2`} />
                    </svg>
                    <Trophy className="absolute inset-0 m-auto h-[1.1rem] w-[1.1rem] text-[#e8c36a]" />
                  </div>
                  <div>
                    <div className="text-[0.72rem] font-semibold uppercase tracking-wider text-white/55">Trophies</div>
                    <div className="text-[1.15rem] font-bold tabular-nums">{trophy}%</div>
                  </div>
                </div>
              </>
            ) : (
              <div className="glass max-w-[34rem] rounded-[1rem] px-[1.3rem] py-[1rem] text-[0.92rem] leading-relaxed text-white/80">{tile.desc}</div>
            )}
          </div>
        </div>
      )}

      <HintBar show={settings.hints && active}>
        <Hint k="↑ ↓ ← →">Navigate</Hint>
        <Hint k="Enter" glyph="cross">Select</Hint>
        <Hint k="Tab" glyph="square">Options</Hint>
        <Hint k="F1">PS Button</Hint>
      </HintBar>

      {options && active && <OptionsPanel title={tile?.title ?? ""} items={optionItems} onClose={() => setOptions(false)} />}
      {confirm && (
        <ConfirmDialog
          title="Delete this game?"
          message={`"${confirm.title}" and its saved data will be removed from this console.`}
          confirmLabel="Delete"
          danger
          onCancel={() => setConfirm(null)}
          onConfirm={() => {
            onDeleteGame(confirm);
            setConfirm(null);
          }}
        />
      )}
    </div>
  );
}

function InfoCard({ icon, label, value }: { icon: ReactNode; label: string; value: string }) {
  return (
    <div className="glass flex w-[13rem] items-center gap-[0.9rem] rounded-[1rem] px-[1.1rem] py-[0.9rem]">
      <div className="flex h-[3rem] w-[3rem] items-center justify-center rounded-full bg-white/10 text-white/85">{icon}</div>
      <div>
        <div className="text-[0.72rem] font-semibold uppercase tracking-wider text-white/55">{label}</div>
        <div className="text-[1.05rem] font-bold">{value}</div>
      </div>
    </div>
  );
}
