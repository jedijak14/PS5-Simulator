import { useEffect, useRef, useState } from "react";
import { ArrowLeft, ArrowRight, BookOpen, ExternalLink, Globe, Home, Landmark, Map, Newspaper, RotateCw, Search, X, Library, Image as ImageIcon } from "lucide-react";
import type { Settings } from "../types";
import { useNav } from "../lib/useNav";
import { sfx } from "../lib/sfx";
import { Hint, HintBar } from "./ui";

const LINKS = [
  { title: "Wikipedia", url: "https://en.wikipedia.org/wiki/Main_Page", icon: <BookOpen className="h-full w-full" />, color: "from-slate-500 to-slate-800" },
  { title: "OpenStreetMap", url: "https://www.openstreetmap.org/", icon: <Map className="h-full w-full" />, color: "from-emerald-500 to-teal-800" },
  { title: "Internet Archive", url: "https://archive.org/", icon: <Library className="h-full w-full" />, color: "from-sky-500 to-indigo-800" },
  { title: "Hacker News", url: "https://news.ycombinator.com/", icon: <Newspaper className="h-full w-full" />, color: "from-orange-500 to-red-800" },
  { title: "Wikimedia Commons", url: "https://commons.wikimedia.org/", icon: <ImageIcon className="h-full w-full" />, color: "from-cyan-500 to-blue-800" },
  { title: "Example Domain", url: "https://example.com/", icon: <Landmark className="h-full w-full" />, color: "from-violet-500 to-purple-900" },
];
const COLS = 3;

function normalize(q: string): string {
  const s = q.trim();
  if (!s) return "";
  if (/^https?:\/\//i.test(s)) return s;
  if (/^[\w-]+(\.[\w-]+)+(:\d+)?(\/.*)?$/i.test(s) && !/\s/.test(s)) return "https://" + s;
  return "https://en.wikipedia.org/w/index.php?search=" + encodeURIComponent(s);
}

export default function Browser({ settings, onClose }: { settings: Settings; onClose: () => void }) {
  const [hist, setHist] = useState<string[]>([""]);
  const [hi, setHi] = useState(0);
  const [reload, setReload] = useState(0);
  const [text, setText] = useState("");
  const [sel, setSel] = useState(0); // -1 = search box
  const [loading, setLoading] = useState(false);
  const [notice, setNotice] = useState(false);
  const input = useRef<HTMLInputElement>(null);
  const url = hist[hi];

  const go = (raw: string) => {
    const u = normalize(raw);
    if (!u) return;
    setHist((h) => [...h.slice(0, hi + 1), u]);
    setHi((i) => i + 1);
    setText(u);
    setLoading(true);
    setNotice(true);
    sfx.open();
  };
  const goHome = () => {
    setHist((h) => [...h.slice(0, hi + 1), ""]);
    setHi((i) => i + 1);
    setText("");
    setSel(0);
  };
  const back = () => {
    if (hi > 0) {
      setHi(hi - 1);
      setText(hist[hi - 1]);
      setLoading(!!hist[hi - 1]);
      sfx.back();
    }
  };
  const fwd = () => {
    if (hi < hist.length - 1) {
      setHi(hi + 1);
      setText(hist[hi + 1]);
      setLoading(!!hist[hi + 1]);
      sfx.select();
    }
  };

  useEffect(() => {
    if (!notice) return;
    const t = window.setTimeout(() => setNotice(false), 7000);
    return () => clearTimeout(t);
  }, [notice]);

  // "/" or Ctrl+L focuses the address bar
  useEffect(() => {
    const k = (e: KeyboardEvent) => {
      const typing = document.activeElement === input.current;
      if ((e.key === "/" && !typing) || ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === "l")) {
        e.preventDefault();
        input.current?.focus();
        input.current?.select();
      }
      if (e.altKey && e.key === "ArrowLeft") back();
      if (e.altKey && e.key === "ArrowRight") fwd();
    };
    window.addEventListener("keydown", k);
    return () => window.removeEventListener("keydown", k);
  });

  useNav((a) => {
    const typing = document.activeElement === input.current;
    if (a === "back") {
      if (typing) input.current?.blur();
      else {
        sfx.back();
        onClose();
      }
      return;
    }
    if (typing) return;
    if (!url) {
      if (a === "left" && sel > 0) setSel(sel - 1), sfx.move();
      else if (a === "right" && sel < LINKS.length - 1) setSel(sel + 1), sfx.move();
      else if (a === "down" && sel + COLS < LINKS.length) setSel(sel + COLS), sfx.move();
      else if (a === "up") {
        if (sel >= COLS) setSel(sel - COLS), sfx.move();
        else {
          input.current?.focus();
          sfx.move();
        }
      } else if (a === "confirm") go(LINKS[sel].url);
    } else if (a === "options") {
      window.open(url, "_blank", "noopener");
    }
  });

  return (
    <div className="anim-app-enter absolute inset-0 z-[50] flex flex-col bg-[#0b0e16]">
      {/* toolbar */}
      <div className="flex items-center gap-[0.7rem] border-b border-white/10 bg-[#12151f] px-[1.4rem] py-[0.8rem]">
        {[
          { i: <ArrowLeft />, on: back, dis: hi === 0, t: "Back" },
          { i: <ArrowRight />, on: fwd, dis: hi >= hist.length - 1, t: "Forward" },
          { i: <RotateCw />, on: () => { if (url) { setReload((r) => r + 1); setLoading(true); } }, dis: !url, t: "Reload" },
          { i: <Home />, on: goHome, dis: false, t: "Home" },
        ].map((b) => (
          <button
            key={b.t}
            title={b.t}
            disabled={b.dis}
            onClick={b.on}
            className="flex h-[2.3rem] w-[2.3rem] items-center justify-center rounded-full p-[0.55rem] text-white/85 transition-colors hover:bg-white/15 disabled:opacity-30"
          >
            {b.i}
          </button>
        ))}
        <form
          className="relative mx-[0.6rem] flex-1"
          onSubmit={(e) => {
            e.preventDefault();
            input.current?.blur();
            go(text);
          }}
        >
          <Search className="absolute left-[1rem] top-1/2 h-[1rem] w-[1rem] -translate-y-1/2 text-white/45" />
          <input
            ref={input}
            value={text}
            onChange={(e) => setText(e.target.value)}
            onFocus={(e) => e.currentTarget.select()}
            onKeyDown={(e) => {
              if (e.key === "ArrowDown" && !url) {
                e.preventDefault();
                input.current?.blur();
                setSel(0);
              }
            }}
            placeholder="Search Wikipedia or enter a web address"
            spellCheck={false}
            className="w-full rounded-full bg-black/40 py-[0.6rem] pl-[2.6rem] pr-[1rem] text-[0.95rem] outline-none ring-1 ring-white/10 transition-all placeholder:text-white/35 focus:bg-black/60 focus:ring-2 focus:ring-[#4aa3ff]"
          />
          {loading && <div className="absolute bottom-0 left-[1.2rem] right-[1.2rem] h-[2px] overflow-hidden rounded-full bg-transparent"><div className="h-full w-1/3 animate-[sheen_1.1s_linear_infinite] bg-[#4aa3ff]" /></div>}
        </form>
        <button
          title="Open in new tab"
          disabled={!url}
          onClick={() => window.open(url, "_blank", "noopener")}
          className="flex h-[2.3rem] w-[2.3rem] items-center justify-center rounded-full p-[0.55rem] text-white/85 transition-colors hover:bg-white/15 disabled:opacity-30"
        >
          <ExternalLink />
        </button>
        <button title="Close browser" onClick={() => { sfx.back(); onClose(); }} className="flex h-[2.3rem] w-[2.3rem] items-center justify-center rounded-full bg-white/10 p-[0.55rem] text-white transition-colors hover:bg-[#ff5d6c]">
          <X />
        </button>
      </div>

      {/* viewport */}
      <div className="relative flex-1 overflow-hidden">
        {url ? (
          <>
            <iframe
              key={`${hi}-${reload}-${url}`}
              src={url}
              title="Web Browser"
              sandbox="allow-scripts allow-same-origin allow-forms allow-popups allow-modals"
              referrerPolicy="no-referrer"
              onLoad={() => setLoading(false)}
              className="absolute inset-0 h-full w-full border-0 bg-white"
            />
            {notice && (
              <div className="anim-rise absolute bottom-[3.2rem] left-1/2 z-10 flex -translate-x-1/2 items-center gap-4 rounded-full bg-black/80 px-[1.3rem] py-[0.6rem] text-[0.85rem] shadow-xl backdrop-blur-md">
                <Globe className="h-[1rem] w-[1rem] text-[#7cc4ff]" />
                <span className="text-white/85">Some sites don't allow embedded viewing.</span>
                <button onClick={() => window.open(url, "_blank", "noopener")} className="font-semibold text-[#7cc4ff] hover:underline">
                  Open in new tab
                </button>
              </div>
            )}
          </>
        ) : (
          <div className="absolute inset-0 overflow-hidden bg-gradient-to-b from-[#101a33] via-[#0b0e16] to-[#0b0e16]">
            <div className="absolute -top-[10rem] left-1/2 h-[26rem] w-[50rem] -translate-x-1/2 rounded-full bg-[#2b7fff]/25 blur-[6rem]" />
            <div className="relative mx-auto flex h-full w-[48rem] flex-col items-center pt-[4.2rem]">
              <Globe className="h-[3.2rem] w-[3.2rem] text-[#7cc4ff]" strokeWidth={1.3} />
              <h1 className="mt-3 text-[2.2rem] font-bold tracking-tight">Web Browser</h1>
              <p className="mt-1 text-[0.95rem] text-white/55">Search with Wikipedia or jump to a site below</p>
              <div className="mt-[2.4rem] grid w-full grid-cols-3 gap-[1rem]">
                {LINKS.map((l, i) => {
                  const on = sel === i;
                  return (
                    <button
                      key={l.url}
                      onMouseEnter={() => setSel(i)}
                      onClick={() => go(l.url)}
                      className={`flex items-center gap-[0.9rem] rounded-[1rem] bg-white/[0.07] p-[0.9rem] text-left transition-all duration-200 ${on ? "focus-ring scale-105 bg-white/[0.16]" : ""}`}
                    >
                      <div className={`h-[3rem] w-[3rem] shrink-0 rounded-[0.8rem] bg-gradient-to-br p-[0.75rem] text-white ${l.color}`}>{l.icon}</div>
                      <div className="min-w-0">
                        <div className="truncate text-[0.95rem] font-semibold">{l.title}</div>
                        <div className="truncate text-[0.72rem] text-white/45">{l.url.replace(/^https?:\/\/(www\.)?/, "").replace(/\/$/, "")}</div>
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>
          </div>
        )}
      </div>

      <HintBar show={settings.hints} className="!bottom-[0.7rem]">
        <Hint k="/">Address Bar</Hint>
        {!url && <Hint k="↑ ↓ ← →">Navigate</Hint>}
        {!url && <Hint k="Enter" glyph="cross">Open</Hint>}
        {url && <Hint k="Tab" glyph="square">New Tab</Hint>}
        <Hint k="Esc" glyph="circle">Exit</Hint>
      </HintBar>
    </div>
  );
}
