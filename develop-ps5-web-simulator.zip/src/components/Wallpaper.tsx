import { useEffect, useRef } from "react";
import { getTheme } from "../lib/themes";

function rgba(hex: string, a: number) {
  const n = parseInt(hex.slice(1), 16);
  return `rgba(${(n >> 16) & 255},${(n >> 8) & 255},${n & 255},${a})`;
}

/** The flowing ribbon wallpaper behind the home screen. */
export default function Wallpaper({ theme, animate, paused }: { theme: string; animate: boolean; paused: boolean }) {
  const ref = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const cv = ref.current!;
    const ctx = cv.getContext("2d")!;
    const th = getTheme(theme);
    let raf = 0;
    let t = 0;
    const resize = () => {
      cv.width = Math.floor(window.innerWidth / 2);
      cv.height = Math.floor(window.innerHeight / 2);
    };
    resize();
    window.addEventListener("resize", resize);

    const draw = () => {
      const { width: w, height: h } = cv;
      const bg = ctx.createLinearGradient(0, 0, w * 0.3, h);
      bg.addColorStop(0, th.colors[0]);
      bg.addColorStop(1, "#02030a");
      ctx.globalCompositeOperation = "source-over";
      ctx.fillStyle = bg;
      ctx.fillRect(0, 0, w, h);
      ctx.globalCompositeOperation = "lighter";
      for (let i = 0; i < 6; i++) {
        const col = th.colors[1 + (i % 2)];
        const base = h * (0.5 + i * 0.07);
        const amp = h * (0.07 + i * 0.012);
        const f = 1.2 + i * 0.33;
        ctx.beginPath();
        ctx.moveTo(0, h);
        for (let x = 0; x <= w; x += 6) {
          const y =
            base +
            Math.sin((x / w) * f * Math.PI + t * (0.35 + i * 0.07) + i) * amp +
            Math.sin((x / w) * f * 2.1 * Math.PI - t * 0.25 + i * 2) * amp * 0.4;
          ctx.lineTo(x, y);
        }
        ctx.lineTo(w, h);
        ctx.closePath();
        const g = ctx.createLinearGradient(0, base - amp, 0, h);
        g.addColorStop(0, rgba(col, 0.2));
        g.addColorStop(1, rgba(col, 0));
        ctx.fillStyle = g;
        ctx.fill();
      }
      const glow = ctx.createRadialGradient(w * 0.8, h * 0.15, 0, w * 0.8, h * 0.15, w * 0.6);
      glow.addColorStop(0, rgba(th.colors[2], 0.22));
      glow.addColorStop(1, rgba(th.colors[2], 0));
      ctx.fillStyle = glow;
      ctx.fillRect(0, 0, w, h);
    };

    if (paused || !animate) {
      draw();
    } else {
      const loop = () => {
        t += 0.016;
        draw();
        raf = requestAnimationFrame(loop);
      };
      raf = requestAnimationFrame(loop);
    }
    return () => {
      cancelAnimationFrame(raf);
      window.removeEventListener("resize", resize);
    };
  }, [theme, animate, paused]);

  return <canvas ref={ref} className="absolute inset-0 h-full w-full" />;
}
