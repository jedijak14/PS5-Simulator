import { useEffect, useRef, useState } from "react";
import { Film, ImageIcon, Music, Pause, Play, Plus, SkipBack, SkipForward, Trash2, Volume2, VolumeX } from "lucide-react";
import type { Settings } from "../types";
import { useNav } from "../lib/useNav";
import { sfx } from "../lib/sfx";
import { Hint, HintBar } from "./ui";

type Kind = "audio" | "video" | "image";
interface Item {
  id: string;
  name: string;
  url: string;
  kind: Kind;
  size: number;
}

const COLS = 5;

function kindOf(f: File): Kind | null {
  if (f.type.startsWith("audio/")) return "audio";
  if (f.type.startsWith("video/")) return "video";
  if (f.type.startsWith("image/")) return "image";
  const ext = f.name.split(".").pop()?.toLowerCase() ?? "";
  if (["mp3", "wav", "ogg", "flac", "m4a", "aac", "opus"].includes(ext)) return "audio";
  if (["mp4", "webm", "mkv", "mov", "m4v", "ogv"].includes(ext)) return "video";
  if (["png", "jpg", "jpeg", "gif", "webp", "avif", "bmp", "svg"].includes(ext)) return "image";
  return null;
}

const fmt = (s: number) => {
  if (!isFinite(s)) return "0:00";
  const m = Math.floor(s / 60);
  return `${m}:${Math.floor(s % 60).toString().padStart(2, "0")}`;
};
const size = (n: number) => (n > 1048576 ? `${(n / 1048576).toFixed(1)} MB` : `${Math.max(1, Math.round(n / 1024))} KB`);
const icon = (k: Kind, cls: string) => (k === "audio" ? <Music className={cls} /> : k === "video" ? <Film className={cls} /> : <ImageIcon className={cls} />);
const tint: Record<Kind, string> = {
  audio: "from-fuchsia-600 to-indigo-900",
  video: "from-sky-500 to-blue-900",
  image: "from-emerald-500 to-teal-900",
};

/* one shared AudioContext; a media element can only be wired once */
let sharedCtx: AudioContext | null = null;
const wired = new WeakMap<HTMLMediaElement, AnalyserNode>();
function analyserFor(el: HTMLMediaElement): AnalyserNode | null {
  try {
    const hit = wired.get(el);
    if (hit) return hit;
    const AC = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    sharedCtx = sharedCtx ?? new AC();
    if (sharedCtx.state === "suspended") void sharedCtx.resume();
    const src = sharedCtx.createMediaElementSource(el);
    const an = sharedCtx.createAnalyser();
    an.fftSize = 256;
    an.smoothingTimeConstant = 0.8;
    src.connect(an);
    an.connect(sharedCtx.destination);
    wired.set(el, an);
    return an;
  } catch {
    return null;
  }
}

function Player({ items, start, hints, onExit }: { items: Item[]; start: number; hints: boolean; onExit: () => void }) {
  const [i, setI] = useState(start);
  const [paused, setPaused] = useState(false);
  const [time, setTime] = useState({ cur: 0, dur: 0 });
  const [vol, setVol] = useState(0.8);
  const [muted, setMuted] = useState(false);
  const [ui, setUi] = useState(true);
  const media = useRef<HTMLVideoElement>(null);
  const cv = useRef<HTMLCanvasElement>(null);
  const hideT = useRef<number>(0);
  const item = items[i];

  const poke = () => {
    setUi(true);
    clearTimeout(hideT.current);
    hideT.current = window.setTimeout(() => setUi(false), 3200);
  };
  useEffect(() => {
    poke();
    return () => clearTimeout(hideT.current);
  }, []);

  useEffect(() => {
    const el = media.current;
    if (!el) return;
    el.volume = vol;
    el.muted = muted;
  }, [vol, muted, i]);

  useEffect(() => {
    setTime({ cur: 0, dur: 0 });
    setPaused(false);
    const el = media.current;
    if (el && item.kind !== "image") {
      analyserFor(el);
      el.play().catch(() => setPaused(true));
    }
    poke();
  }, [i]);

  // visualizer
  useEffect(() => {
    if (item.kind !== "audio") return;
    const c = cv.current;
    const el = media.current;
    if (!c || !el) return;
    const an = analyserFor(el);
    const ctx = c.getContext("2d")!;
    const data = new Uint8Array(an?.frequencyBinCount ?? 128);
    let raf = 0;
    let t = 0;
    const loop = () => {
      t += 0.02;
      const w = (c.width = c.clientWidth);
      const h = (c.height = c.clientHeight);
      ctx.clearRect(0, 0, w, h);
      if (an) an.getByteFrequencyData(data);
      const bars = 64;
      const bw = w / bars;
      for (let b = 0; b < bars; b++) {
        const v = an ? data[Math.floor((b / bars) * data.length * 0.75)] / 255 : 0.15 + 0.1 * Math.sin(t + b);
        const bh = Math.max(4, v * h * 0.5);
        const g = ctx.createLinearGradient(0, h, 0, h - bh);
        g.addColorStop(0, "rgba(90,150,255,0.15)");
        g.addColorStop(1, `hsla(${210 + b * 2},100%,75%,0.9)`);
        ctx.fillStyle = g;
        ctx.beginPath();
        ctx.roundRect(b * bw + bw * 0.15, h - bh, bw * 0.7, bh, bw * 0.3);
        ctx.fill();
      }
      raf = requestAnimationFrame(loop);
    };
    raf = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(raf);
  }, [i, item.kind]);

  const toggle = () => {
    const el = media.current;
    if (!el) return;
    if (el.paused) void el.play();
    else el.pause();
    poke();
  };
  const seek = (d: number) => {
    const el = media.current;
    if (el) el.currentTime = Math.max(0, Math.min(el.duration || 0, el.currentTime + d));
    poke();
  };
  const step = (d: number) => {
    const n = i + d;
    if (n >= 0 && n < items.length) {
      setI(n);
      sfx.move();
    }
  };

  useNav((a) => {
    poke();
    const img = item.kind === "image";
    if (a === "back") {
      sfx.back();
      onExit();
    } else if (a === "confirm") img ? undefined : toggle();
    else if (a === "left") img ? step(-1) : seek(-10);
    else if (a === "right") img ? step(1) : seek(10);
    else if (a === "up") setVol((v) => Math.min(1, +(v + 0.1).toFixed(2))), setMuted(false);
    else if (a === "down") setVol((v) => Math.max(0, +(v - 0.1).toFixed(2)));
  }, true, true);

  useEffect(() => {
    const k = (e: KeyboardEvent) => {
      if (e.key === " " && item.kind !== "image") {
        e.preventDefault();
        toggle();
      } else if (e.key === "n" || e.key === "N") step(1);
      else if (e.key === "p" || e.key === "P") step(-1);
      else if (e.key === "m" || e.key === "M") setMuted((m) => !m);
    };
    window.addEventListener("keydown", k);
    return () => window.removeEventListener("keydown", k);
  });

  const pct = time.dur ? time.cur / time.dur : 0;

  return (
    <div className="anim-fade-in absolute inset-0 z-[60] overflow-hidden bg-black" onMouseMove={poke} style={{ cursor: ui ? "default" : "none" }}>
      {item.kind === "image" ? (
        <>
          <img src={item.url} alt="" className="absolute inset-0 h-full w-full scale-125 object-cover opacity-30 blur-3xl" />
          <img key={item.id} src={item.url} alt={item.name} className="anim-fade-in absolute inset-0 m-auto max-h-full max-w-full object-contain" />
        </>
      ) : (
        <video
          key={item.id}
          ref={media}
          src={item.url}
          playsInline
          onClick={toggle}
          onTimeUpdate={(e) => setTime({ cur: e.currentTarget.currentTime, dur: e.currentTarget.duration })}
          onLoadedMetadata={(e) => setTime({ cur: 0, dur: e.currentTarget.duration })}
          onPlay={() => setPaused(false)}
          onPause={() => setPaused(true)}
          onEnded={() => (i < items.length - 1 ? step(1) : setPaused(true))}
          className={`absolute inset-0 h-full w-full ${item.kind === "video" ? "bg-black object-contain" : "opacity-0"}`}
        />
      )}

      {item.kind === "audio" && (
        <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(ellipse_at_50%_35%,#1b2f7a,#06081a_70%)]">
          <div className="absolute left-1/2 top-[11rem] flex h-[13rem] w-[13rem] -translate-x-1/2 items-center justify-center rounded-full bg-gradient-to-br from-fuchsia-500 to-indigo-700 shadow-[0_0_6rem_rgba(120,100,255,0.6)]" style={{ animation: paused ? "none" : "breathe 4s ease-in-out infinite" }}>
            <Music className="h-[5.5rem] w-[5.5rem] text-white/90" strokeWidth={1.2} />
          </div>
          <canvas ref={cv} className="absolute inset-x-[6rem] bottom-[8rem] h-[12rem] w-[calc(100%-12rem)]" />
        </div>
      )}

      {paused && item.kind !== "image" && (
        <div className="anim-pop pointer-events-none absolute inset-0 flex items-center justify-center">
          <div className="flex h-[6rem] w-[6rem] items-center justify-center rounded-full bg-black/50 backdrop-blur-md">
            <Play className="h-[2.6rem] w-[2.6rem] fill-white" />
          </div>
        </div>
      )}

      {/* transport */}
      <div className={`absolute inset-x-0 bottom-0 transition-all duration-500 ${ui ? "translate-y-0 opacity-100" : "translate-y-6 opacity-0"}`}>
        <div className="bg-gradient-to-t from-black/90 via-black/50 to-transparent px-[4rem] pb-[3.2rem] pt-[4rem]">
          <div className="mb-[0.8rem] flex items-end justify-between">
            <div className="min-w-0">
              <div className="truncate text-[1.5rem] font-semibold">{item.name.replace(/\.[^.]+$/, "")}</div>
              <div className="text-[0.82rem] text-white/55">
                {i + 1} of {items.length} · {item.kind === "audio" ? "Music" : item.kind === "video" ? "Video" : "Photo"}
              </div>
            </div>
            <div className="flex items-center gap-[1rem]">
              <button onClick={() => step(-1)} className="text-white/80 transition-colors hover:text-white"><SkipBack className="h-[1.6rem] w-[1.6rem]" /></button>
              {item.kind !== "image" && (
                <button onClick={toggle} className="flex h-[3.4rem] w-[3.4rem] items-center justify-center rounded-full bg-white text-black transition-transform hover:scale-110">
                  {paused ? <Play className="h-[1.5rem] w-[1.5rem] fill-black" /> : <Pause className="h-[1.5rem] w-[1.5rem] fill-black" />}
                </button>
              )}
              <button onClick={() => step(1)} className="text-white/80 transition-colors hover:text-white"><SkipForward className="h-[1.6rem] w-[1.6rem]" /></button>
              <button onClick={() => setMuted((m) => !m)} className="ml-3 flex items-center gap-2 text-white/80">
                {muted || vol === 0 ? <VolumeX className="h-[1.3rem] w-[1.3rem]" /> : <Volume2 className="h-[1.3rem] w-[1.3rem]" />}
                <div className="h-[0.28rem] w-[5rem] overflow-hidden rounded-full bg-white/25"><div className="h-full rounded-full bg-white" style={{ width: `${(muted ? 0 : vol) * 100}%` }} /></div>
              </button>
            </div>
          </div>
          {item.kind !== "image" && (
            <div className="flex items-center gap-4 text-[0.82rem] tabular-nums text-white/70">
              <span className="w-[3rem]">{fmt(time.cur)}</span>
              <div
                className="group relative h-[0.4rem] flex-1 cursor-pointer overflow-hidden rounded-full bg-white/25"
                onClick={(e) => {
                  const r = e.currentTarget.getBoundingClientRect();
                  if (media.current && time.dur) media.current.currentTime = ((e.clientX - r.left) / r.width) * time.dur;
                }}
              >
                <div className="h-full rounded-full bg-white" style={{ width: `${pct * 100}%` }} />
              </div>
              <span className="w-[3rem] text-right">{fmt(time.dur)}</span>
            </div>
          )}
        </div>
      </div>

      <HintBar show={hints && ui}>
        {item.kind === "image" ? <Hint k="← →">Previous / Next</Hint> : <Hint k="Space">Play / Pause</Hint>}
        {item.kind !== "image" && <Hint k="← →">Seek 10s</Hint>}
        <Hint k="↑ ↓">Volume</Hint>
        <Hint k="N / P">Next / Prev</Hint>
        <Hint k="Esc" glyph="circle">Back</Hint>
      </HintBar>
    </div>
  );
}

export default function MediaPlayer({ settings, onClose, notify }: { settings: Settings; onClose: () => void; notify: (m: string) => void }) {
  const [items, setItems] = useState<Item[]>([]);
  const [sel, setSel] = useState(0);
  const [playing, setPlaying] = useState<number | null>(null);
  const picker = useRef<HTMLInputElement>(null);
  const listRef = useRef<HTMLDivElement>(null);
  const itemsRef = useRef(items);
  itemsRef.current = items;

  useEffect(() => () => itemsRef.current.forEach((it) => URL.revokeObjectURL(it.url)), []);

  const add = (files: FileList | null) => {
    if (!files) return;
    const added: Item[] = [];
    let skipped = 0;
    Array.from(files).forEach((f) => {
      const k = kindOf(f);
      if (!k) return void skipped++;
      added.push({ id: Math.random().toString(36).slice(2), name: f.name, url: URL.createObjectURL(f), kind: k, size: f.size });
    });
    if (added.length) {
      setItems((it) => [...it, ...added]);
      setSel(items.length + 1);
      notify(`${added.length} file${added.length > 1 ? "s" : ""} added to Media Player`);
    }
    if (skipped) {
      sfx.error();
      notify(`${skipped} unsupported file${skipped > 1 ? "s" : ""} skipped`);
    }
  };

  const total = items.length + 1;
  const remove = (idx: number) => {
    const it = items[idx];
    if (!it) return;
    URL.revokeObjectURL(it.url);
    setItems((a) => a.filter((_, k) => k !== idx));
    setSel((s) => Math.max(0, Math.min(s, items.length - 1)));
    sfx.back();
  };

  useNav(
    (a) => {
      if (a === "back") {
        sfx.back();
        onClose();
      } else if (a === "left" && sel > 0) {
        setSel(sel - 1);
        sfx.move();
      } else if (a === "right" && sel < total - 1) {
        setSel(sel + 1);
        sfx.move();
      } else if (a === "up" && sel - COLS >= 0) {
        setSel(sel - COLS);
        sfx.move();
      } else if (a === "down" && sel + COLS < total) {
        setSel(sel + COLS);
        sfx.move();
      } else if (a === "confirm") {
        if (sel === 0) picker.current?.click();
        else {
          sfx.open();
          setPlaying(sel - 1);
        }
      } else if (a === "options" && sel > 0) remove(sel - 1);
    },
    playing === null
  );

  useEffect(() => {
    listRef.current?.querySelector<HTMLElement>('[data-sel="true"]')?.scrollIntoView({ block: "nearest", behavior: "smooth" });
  }, [sel]);

  return (
    <div className="anim-app-enter absolute inset-0 z-[50] bg-[#0a0716]/80 backdrop-blur-2xl">
      <div className="absolute left-[4rem] top-[2.4rem]">
        <div className="text-[0.75rem] font-semibold uppercase tracking-[0.25em] text-white/50">Media</div>
        <h1 className="text-[2rem] font-bold">Media Player</h1>
      </div>
      <div className="absolute right-[4rem] top-[3.2rem] text-[0.85rem] text-white/50">
        {items.length} item{items.length === 1 ? "" : "s"}
      </div>

      <div ref={listRef} className="absolute inset-x-0 bottom-[3.6rem] top-[7rem] overflow-y-auto px-[4rem] pb-[1rem] pt-[1rem]">
        <div className="grid gap-[1.2rem]" style={{ gridTemplateColumns: `repeat(${COLS}, minmax(0, 1fr))` }}>
          <div
            data-sel={sel === 0}
            onMouseMove={() => setSel(0)}
            onClick={() => picker.current?.click()}
            className={`flex aspect-[4/3] cursor-pointer flex-col items-center justify-center gap-3 rounded-[1.1rem] border-2 border-dashed transition-all duration-200 ${sel === 0 ? "focus-ring scale-[1.04] border-white/60 bg-white/15" : "border-white/20 bg-white/[0.04]"}`}
          >
            <Plus className="h-[2.6rem] w-[2.6rem]" strokeWidth={1.3} />
            <div className="text-[0.95rem] font-semibold">Add Files</div>
            <div className="text-[0.75rem] text-white/50">Music · Video · Photos</div>
          </div>
          {items.map((it, k) => {
            const on = sel === k + 1;
            return (
              <div
                key={it.id}
                data-sel={on}
                onMouseMove={() => setSel(k + 1)}
                onClick={() => { sfx.open(); setPlaying(k); }}
                className={`group relative aspect-[4/3] cursor-pointer overflow-hidden rounded-[1.1rem] bg-gradient-to-br transition-all duration-200 ${tint[it.kind]} ${on ? "focus-ring scale-[1.04]" : "shadow-lg shadow-black/40"}`}
              >
                {it.kind === "image" && <img src={it.url} alt="" className="absolute inset-0 h-full w-full object-cover" />}
                {it.kind === "video" && <video src={it.url + "#t=0.5"} preload="metadata" muted className="absolute inset-0 h-full w-full object-cover" />}
                <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-black/10 to-transparent" />
                {it.kind !== "image" && <div className="absolute inset-0 flex items-center justify-center">{it.kind === "audio" ? icon("audio", "h-[3rem] w-[3rem] text-white/70") : null}</div>}
                <div className="absolute right-3 top-3 flex h-[1.9rem] w-[1.9rem] items-center justify-center rounded-full bg-black/50 p-[0.45rem]">{icon(it.kind, "h-full w-full")}</div>
                <div className="absolute inset-x-0 bottom-0 p-[0.8rem]">
                  <div className="truncate text-[0.88rem] font-semibold">{it.name.replace(/\.[^.]+$/, "")}</div>
                  <div className="text-[0.72rem] text-white/60">{size(it.size)}</div>
                </div>
              </div>
            );
          })}
        </div>
        {items.length === 0 && (
          <div className="anim-fade-in mx-auto mt-[3rem] max-w-[30rem] text-center text-[0.95rem] leading-relaxed text-white/50">
            Your library is empty. Select <b className="text-white/80">Add Files</b> to pick songs, videos or photos from your device. Files stay on this console until you leave.
          </div>
        )}
      </div>

      <input ref={picker} type="file" multiple accept="audio/*,video/*,image/*" className="hidden" onChange={(e) => { add(e.target.files); e.target.value = ""; }} />

      <HintBar show={settings.hints && playing === null}>
        <Hint k="↑ ↓ ← →">Navigate</Hint>
        <Hint k="Enter" glyph="cross">{sel === 0 ? "Add Files" : "Play"}</Hint>
        {sel > 0 && (
          <Hint k="Tab" glyph="square">
            <span className="inline-flex items-center gap-1"><Trash2 className="h-[0.8rem] w-[0.8rem]" />Remove</span>
          </Hint>
        )}
        <Hint k="Esc" glyph="circle">Back</Hint>
      </HintBar>

      {playing !== null && <Player items={items} start={playing} hints={settings.hints} onExit={() => setPlaying(null)} />}
    </div>
  );
}
