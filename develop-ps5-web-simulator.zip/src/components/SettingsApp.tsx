import { useEffect, useRef, useState, type ReactNode } from "react";
import { User, Volume2, MonitorPlay, Palette, HardDrive, Wifi, Cpu, ChevronRight } from "lucide-react";
import type { Game, PowerAction, Settings } from "../types";
import { THEMES } from "../lib/themes";
import { useNav } from "../lib/useNav";
import { sfx } from "../lib/sfx";
import { ConfirmDialog, Hint, HintBar, Meter, Toggle } from "./ui";

type Row =
  | { type: "toggle"; label: string; desc?: string; value: boolean; onChange: (v: boolean) => void }
  | { type: "slider"; label: string; value: number; min: number; max: number; step: number; fmt: (v: number) => string; onChange: (v: number) => void }
  | { type: "select"; label: string; value: string; options: { id: string; label: string }[]; onChange: (v: string) => void }
  | { type: "action"; label: string; desc?: string; danger?: boolean; onSelect: () => void }
  | { type: "info"; label: string; value: string }
  | { type: "meter"; label: string; value: number; text: string }
  | { type: "text"; label: string; value: string; onChange: (v: string) => void };

interface Category {
  id: string;
  title: string;
  desc: string;
  icon: ReactNode;
  rows: Row[];
}

const mb = (n: number) => (n / 1048576 >= 1 ? `${(n / 1048576).toFixed(1)} MB` : `${Math.max(1, Math.round(n / 1024))} KB`);

export default function SettingsApp({
  settings,
  update,
  games,
  fullscreen,
  onToggleFullscreen,
  onDeleteAll,
  onReset,
  onAbout,
  onPower,
  onClose,
}: {
  settings: Settings;
  update: (p: Partial<Settings>) => void;
  games: Game[];
  fullscreen: boolean;
  onToggleFullscreen: () => void;
  onDeleteAll: () => void;
  onReset: () => void;
  onAbout: () => void;
  onPower: (a: PowerAction) => void;
  onClose: () => void;
}) {
  const [level, setLevel] = useState<"cats" | "page">("cats");
  const [cat, setCat] = useState(0);
  const [row, setRow] = useState(0);
  const [dialog, setDialog] = useState<null | { title: string; message: string; label: string; onConfirm: () => void }>(null);
  const listRef = useRef<HTMLDivElement>(null);
  const textRef = useRef<HTMLInputElement>(null);

  const nav = navigator as Navigator & { connection?: { effectiveType?: string; downlink?: number; rtt?: number } };
  const used = games.reduce((s, g) => s + g.html.length + g.cover.length + g.background.length + g.logo.length, 0);
  const total = 825 * 1024 * 1024 * 1024;

  const categories: Category[] = [
    {
      id: "users",
      title: "Users and Accounts",
      desc: "Online ID, avatar",
      icon: <User className="h-full w-full" />,
      rows: [
        { type: "text", label: "Online ID", value: settings.userName, onChange: (v) => update({ userName: v.slice(0, 16) || "Player_One" }) },
        { type: "slider", label: "Avatar Colour", value: settings.avatarHue, min: 0, max: 360, step: 15, fmt: (v) => `${v}°`, onChange: (v) => update({ avatarHue: v }) },
        { type: "info", label: "Account Type", value: "Master Account" },
      ],
    },
    {
      id: "sound",
      title: "Sound",
      desc: "System sounds, volume",
      icon: <Volume2 className="h-full w-full" />,
      rows: [
        { type: "toggle", label: "System Sounds", desc: "Menu navigation and startup sounds", value: settings.sfx, onChange: (v) => update({ sfx: v }) },
        { type: "slider", label: "Master Volume", value: settings.volume, min: 0, max: 1, step: 0.1, fmt: (v) => `${Math.round(v * 100)}%`, onChange: (v) => update({ volume: v }) },
        { type: "action", label: "Test Sound", desc: "Play a sample system sound", onSelect: () => sfx.test() },
      ],
    },
    {
      id: "screen",
      title: "Screen and Video",
      desc: "Brightness, HDR, full screen",
      icon: <MonitorPlay className="h-full w-full" />,
      rows: [
        { type: "slider", label: "Brightness", value: settings.brightness, min: 0.6, max: 1.2, step: 0.05, fmt: (v) => `${Math.round(v * 100)}%`, onChange: (v) => update({ brightness: +v.toFixed(2) }) },
        { type: "toggle", label: "HDR", desc: "Richer contrast and colour", value: settings.hdr, onChange: (v) => update({ hdr: v }) },
        { type: "toggle", label: "Full Screen", desc: "Fill the entire display", value: fullscreen, onChange: () => onToggleFullscreen() },
        { type: "toggle", label: "Show Control Hints", desc: "Keyboard prompts at the bottom of the screen", value: settings.hints, onChange: (v) => update({ hints: v }) },
        { type: "info", label: "Video Output", value: `${window.innerWidth} × ${window.innerHeight}` },
        { type: "info", label: "Colour Depth", value: `${screen.colorDepth}-bit` },
      ],
    },
    {
      id: "themes",
      title: "Themes",
      desc: "Wallpaper and motion",
      icon: <Palette className="h-full w-full" />,
      rows: [
        { type: "select", label: "Home Wallpaper", value: settings.theme, options: THEMES.map((t) => ({ id: t.id, label: t.name })), onChange: (v) => update({ theme: v }) },
        { type: "toggle", label: "Animated Wallpaper", value: settings.motion, onChange: (v) => update({ motion: v }) },
      ],
    },
    {
      id: "storage",
      title: "Storage",
      desc: "Installed games and capacity",
      icon: <HardDrive className="h-full w-full" />,
      rows: [
        { type: "meter", label: "Console Storage", value: Math.max(used / total, 0.004) + 0.12, text: `${mb(used)} games · 825 GB total` },
        ...games.map((g): Row => ({ type: "info", label: g.title, value: mb(g.html.length + g.cover.length + g.background.length + g.logo.length) })),
        {
          type: "action",
          label: "Delete All Games",
          desc: "Removes every installed game from this console",
          danger: true,
          onSelect: () =>
            setDialog({ title: "Delete all games?", message: "All installed games will be removed. This can't be undone.", label: "Delete All", onConfirm: onDeleteAll }),
        },
      ],
    },
    {
      id: "network",
      title: "Network",
      desc: "Connection status",
      icon: <Wifi className="h-full w-full" />,
      rows: [
        { type: "info", label: "Status", value: navigator.onLine ? "Connected" : "Offline" },
        { type: "info", label: "Connection Type", value: nav.connection?.effectiveType?.toUpperCase() ?? "Unknown" },
        { type: "info", label: "Estimated Speed", value: nav.connection?.downlink ? `${nav.connection.downlink} Mbps` : "Unknown" },
        { type: "info", label: "Latency", value: nav.connection?.rtt !== undefined ? `${nav.connection.rtt} ms` : "Unknown" },
      ],
    },
    {
      id: "system",
      title: "System",
      desc: "About, power, reset",
      icon: <Cpu className="h-full w-full" />,
      rows: [
        { type: "action", label: "About This PS5", desc: "Processor, GPU, memory and more", onSelect: onAbout },
        { type: "action", label: "Enter Rest Mode", onSelect: () => onPower("rest") },
        { type: "action", label: "Restart PS5", onSelect: () => onPower("restart") },
        { type: "action", label: "Turn Off PS5", onSelect: () => onPower("off") },
        {
          type: "action",
          label: "Reset Your PS5",
          desc: "Erase all games, settings and play history",
          danger: true,
          onSelect: () =>
            setDialog({ title: "Reset your PS5?", message: "This restores factory settings and deletes all installed games. The console will restart.", label: "Reset", onConfirm: onReset }),
        },
      ],
    },
  ];

  const rows = categories[cat].rows;
  const selectable = (r: Row) => r.type !== "info" && r.type !== "meter";

  const moveRow = (d: number) => {
    let i = row;
    for (let n = 0; n < rows.length; n++) {
      i = i + d;
      if (i < 0 || i >= rows.length) return;
      if (selectable(rows[i])) {
        setRow(i);
        sfx.move();
        return;
      }
    }
  };

  useEffect(() => {
    listRef.current?.querySelector<HTMLElement>(`[data-sel="true"]`)?.scrollIntoView({ block: "nearest", behavior: "smooth" });
  }, [row, cat, level]);

  const openCat = (i: number) => {
    setCat(i);
    const first = categories[i].rows.findIndex(selectable);
    setRow(Math.max(0, first));
    setLevel("page");
    sfx.select();
  };

  const adjust = (r: Row, dir: number) => {
    if (r.type === "slider") {
      const v = Math.max(r.min, Math.min(r.max, +(r.value + dir * r.step).toFixed(3)));
      if (v !== r.value) {
        r.onChange(v);
        sfx.move();
      }
    } else if (r.type === "select") {
      const i = r.options.findIndex((o) => o.id === r.value);
      const n = Math.max(0, Math.min(r.options.length - 1, i + dir));
      if (n !== i) {
        r.onChange(r.options[n].id);
        sfx.move();
      }
    } else if (r.type === "toggle" && ((dir > 0 && !r.value) || (dir < 0 && r.value))) {
      r.onChange(dir > 0);
      sfx.toggle();
    }
  };

  useNav(
    (a) => {
      const typing = document.activeElement === textRef.current && !!textRef.current;
      if (a === "back") {
        if (typing) return void textRef.current?.blur();
        sfx.back();
        if (level === "page") setLevel("cats");
        else onClose();
        return;
      }
      if (typing) return;
      if (level === "cats") {
        if (a === "up" && cat > 0) {
          setCat(cat - 1);
          sfx.move();
        } else if (a === "down" && cat < categories.length - 1) {
          setCat(cat + 1);
          sfx.move();
        } else if (a === "confirm" || a === "right") openCat(cat);
      } else {
        const r = rows[row];
        if (a === "up") moveRow(-1);
        else if (a === "down") moveRow(1);
        else if (a === "left") adjust(r, -1);
        else if (a === "right") adjust(r, 1);
        else if (a === "confirm") {
          if (r.type === "toggle") {
            r.onChange(!r.value);
            sfx.toggle();
          } else if (r.type === "action") {
            sfx.select();
            r.onSelect();
          } else if (r.type === "text") textRef.current?.focus();
          else if (r.type === "select") adjust(r, 1);
        }
      }
    },
    !dialog
  );

  return (
    <div className="anim-app-enter absolute inset-0 z-[50] bg-[#070a12]/80 backdrop-blur-2xl">
      <div className="absolute left-[4rem] top-[2.4rem] flex items-center gap-3">
        <h1 className="text-[1.9rem] font-bold">{level === "cats" ? "Settings" : categories[cat].title}</h1>
      </div>

      <div ref={listRef} className="absolute inset-x-0 bottom-[3.4rem] top-[6.4rem] overflow-y-auto">
        {level === "cats" ? (
          <div key="cats" className="anim-rise mx-auto w-[44rem] space-y-[0.5rem] pb-4">
            {categories.map((c, i) => (
              <button
                key={c.id}
                data-sel={cat === i}
                onMouseMove={() => setCat(i)}
                onClick={() => openCat(i)}
                className={`flex w-full items-center gap-[1.2rem] rounded-[1rem] px-[1.2rem] py-[0.85rem] text-left transition-all duration-150 ${
                  cat === i ? "focus-ring scale-[1.02] bg-white text-black" : "bg-white/[0.07] text-white"
                }`}
              >
                <div className={`h-[2.7rem] w-[2.7rem] rounded-full p-[0.65rem] ${cat === i ? "bg-black/10" : "bg-white/10"}`}>{c.icon}</div>
                <div className="flex-1">
                  <div className="text-[1.05rem] font-semibold">{c.title}</div>
                  <div className={`text-[0.82rem] ${cat === i ? "text-black/55" : "text-white/50"}`}>{c.desc}</div>
                </div>
                <ChevronRight className={`h-[1.2rem] w-[1.2rem] ${cat === i ? "text-black/50" : "text-white/30"}`} />
              </button>
            ))}
          </div>
        ) : (
          <div key={"page" + cat} className="anim-rise mx-auto w-[46rem] space-y-[0.45rem] pb-4">
            {rows.map((r, i) => {
              const sel = row === i && selectable(r);
              return (
                <div
                  key={r.label + i}
                  data-sel={sel}
                  onMouseMove={() => selectable(r) && setRow(i)}
                  onClick={() => {
                    if (!selectable(r)) return;
                    setRow(i);
                    if (r.type === "toggle") r.onChange(!r.value);
                    else if (r.type === "action") r.onSelect();
                    else if (r.type === "text") textRef.current?.focus();
                    else if (r.type === "select") adjust(r, 1);
                  }}
                  className={`flex items-center gap-4 rounded-[0.9rem] px-[1.3rem] py-[0.8rem] transition-all duration-150 ${
                    sel ? "focus-ring bg-white text-black" : r.type === "info" || r.type === "meter" ? "bg-white/[0.04]" : "cursor-pointer bg-white/[0.07]"
                  } ${r.type === "action" && r.danger && !sel ? "text-[#ff8a95]" : ""}`}
                >
                  <div className="min-w-0 flex-1">
                    <div className="text-[1rem] font-semibold">{r.label}</div>
                    {"desc" in r && r.desc && <div className={`text-[0.8rem] ${sel ? "text-black/55" : "text-white/50"}`}>{r.desc}</div>}
                    {r.type === "meter" && (
                      <div className="mt-2">
                        <Meter value={r.value} />
                        <div className="mt-1 text-[0.8rem] text-white/55">{r.text}</div>
                      </div>
                    )}
                  </div>
                  {r.type === "toggle" && <Toggle on={r.value} />}
                  {r.type === "info" && <span className="text-[0.95rem] text-white/60">{r.value}</span>}
                  {r.type === "text" && (
                    <input
                      ref={textRef}
                      value={r.value}
                      onChange={(e) => r.onChange(e.target.value)}
                      onKeyDown={(e) => e.key === "Enter" && textRef.current?.blur()}
                      className={`w-[14rem] rounded-lg bg-transparent px-2 py-1 text-right text-[0.95rem] outline-none focus:ring-2 ${sel ? "text-black focus:ring-black/30" : "text-white/80 focus:ring-white/40"}`}
                    />
                  )}
                  {r.type === "slider" && (
                    <div className="flex items-center gap-3">
                      <div className={`h-[0.3rem] w-[12rem] overflow-hidden rounded-full ${sel ? "bg-black/15" : "bg-white/20"}`}>
                        <div className={`h-full rounded-full ${sel ? "bg-black" : "bg-white"}`} style={{ width: `${((r.value - r.min) / (r.max - r.min)) * 100}%` }} />
                      </div>
                      <span className="w-[3.2rem] text-right text-[0.9rem] tabular-nums">{r.fmt(r.value)}</span>
                    </div>
                  )}
                  {r.type === "select" && (
                    <div className="flex items-center gap-2 text-[0.95rem] font-medium">
                      <span className={sel ? "text-black/40" : "text-white/30"}>◂</span>
                      <span className="min-w-[6rem] text-center">{r.options.find((o) => o.id === r.value)?.label}</span>
                      <span className={sel ? "text-black/40" : "text-white/30"}>▸</span>
                    </div>
                  )}
                  {r.type === "action" && !r.danger && <ChevronRight className={`h-[1.1rem] w-[1.1rem] ${sel ? "text-black/50" : "text-white/30"}`} />}
                </div>
              );
            })}
          </div>
        )}
      </div>

      {dialog && (
        <ConfirmDialog
          title={dialog.title}
          message={dialog.message}
          confirmLabel={dialog.label}
          danger
          onCancel={() => setDialog(null)}
          onConfirm={() => {
            const f = dialog.onConfirm;
            setDialog(null);
            f();
          }}
        />
      )}

      <HintBar show={settings.hints}>
        <Hint k="↑ ↓">Navigate</Hint>
        {level === "page" && <Hint k="← →">Adjust</Hint>}
        <Hint k="Enter" glyph="cross">Select</Hint>
        <Hint k="Esc" glyph="circle">Back</Hint>
      </HintBar>
    </div>
  );
}
