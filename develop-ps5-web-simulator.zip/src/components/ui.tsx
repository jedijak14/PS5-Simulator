import { useState, type ReactNode } from "react";
import { useNav } from "../lib/useNav";
import { sfx } from "../lib/sfx";

export const PS_PATH =
  "M8.984 2.596v17.547l3.915 1.261V6.688c0-.69.304-1.151.794-.991.636.18.76.814.76 1.505v5.875c2.441 1.193 4.362-.002 4.362-3.152 0-3.237-1.126-4.675-4.438-5.827-1.307-.448-3.728-1.186-5.39-1.502zm4.656 16.241l6.296-2.275c.715-.258.826-.625.246-.818-.586-.192-1.637-.139-2.357.123l-4.205 1.5V14.98l.24-.085s1.201-.42 2.913-.615c1.696-.18 3.785.03 5.437.661 1.848.601 2.04 1.472 1.576 2.072-.465.6-1.622 1.036-1.622 1.036l-8.544 3.107V18.86zM1.807 18.6c-1.9-.545-2.214-1.668-1.352-2.32.801-.586 2.16-1.052 2.16-1.052l5.615-2.013v2.313L4.205 17c-.705.271-.825.632-.239.826.586.195 1.637.15 2.343-.12L8.247 17v2.074c-.12.03-.256.044-.39.073-1.939.331-3.996.196-6.038-.479z";

export const PS5_WORD_PATH =
  "M10.4499 14.56905a1.38287 1.38287 0 001.38287-1.38287v-2.37841a.83315.83315 0 01.83416-.83315h2.68403a.03732.03732 0 00.03631-.03732V9.4612a.03631.03631 0 00-.0363-.0363H12.1172a1.38287 1.38287 0 00-1.38388 1.38286v2.38043a.83416.83416 0 01-.83315.83415H7.25347a.03631.03631 0 00-.03631.03632v.47608a.03631.03631 0 00.03631.03631zm6.04488-3.21156V9.4612a.03631.03631 0 01.0363-.0363h7.30772a.03732.03732 0 01.03732.0363v.47609a.03833.03833 0 01-.03732.03732h-6.20929a.03631.03631 0 00-.0363.03631v1.2356a.3954.3954 0 00.3964.39741h4.62267a1.46457 1.46457 0 010 2.9251h-6.0812a.03631.03631 0 01-.0363-.0363v-.47407a.03631.03631 0 01.0363-.03632h5.53047a.91586.91586 0 10-.00706-1.8307h-4.72656a.83315.83315 0 01-.83315-.83416m-10.84608.28645a.83466.83466 0 000-1.66932H.03654a.03732.03732 0 01-.03632-.03732V9.4612a.03631.03631 0 01.03632-.0363h6.1528a1.38388 1.38388 0 010 2.76673H1.9328a.83315.83315 0 00-.83315.83416v1.51299a.03631.03631 0 01-.03631.0363H.03654a.03631.03631 0 01-.03632-.04034v-1.51298a1.38287 1.38287 0 011.38388-1.37783Z";

export function PSLogo({ className = "", style }: { className?: string; style?: React.CSSProperties }) {
  return (
    <svg viewBox="0 2.2 24 19.6" className={className} style={style} fill="currentColor">
      <path d={PS_PATH} />
    </svg>
  );
}

export function PS5Word({ className = "", style }: { className?: string; style?: React.CSSProperties }) {
  return (
    <svg viewBox="0 9 24 6" className={className} style={style} fill="currentColor">
      <path d={PS5_WORD_PATH} />
    </svg>
  );
}

export type GlyphKind = "cross" | "circle" | "square" | "triangle";

export function Glyph({ kind, className = "w-4 h-4" }: { kind: GlyphKind; className?: string }) {
  const common = { fill: "none", strokeWidth: 2.4, strokeLinecap: "round" as const, strokeLinejoin: "round" as const };
  return (
    <svg viewBox="0 0 24 24" className={className}>
      {kind === "cross" && <path d="M6 6l12 12M18 6L6 18" stroke="#78aaff" {...common} />}
      {kind === "circle" && <circle cx="12" cy="12" r="7" stroke="#ff6f7d" {...common} />}
      {kind === "square" && <rect x="5.5" y="5.5" width="13" height="13" rx="1" stroke="#ff9bd5" {...common} />}
      {kind === "triangle" && <path d="M12 5l7.5 13h-15z" stroke="#4fe3a8" {...common} />}
    </svg>
  );
}

export function Hint({ k, glyph, children }: { k: string; glyph?: GlyphKind; children: ReactNode }) {
  return (
    <span className="inline-flex items-center gap-2 text-[0.8rem] font-semibold text-white/85">
      {glyph && <Glyph kind={glyph} className="h-[1.1rem] w-[1.1rem]" />}
      <span className="keycap">{k}</span>
      <span>{children}</span>
    </span>
  );
}

export function HintBar({ show = true, children, className = "" }: { show?: boolean; children: ReactNode; className?: string }) {
  if (!show) return null;
  return (
    <div className={`pointer-events-none absolute bottom-[1.1rem] right-[3rem] z-30 flex items-center gap-[1.6rem] drop-shadow-[0_2px_6px_rgba(0,0,0,0.8)] ${className}`}>
      {children}
    </div>
  );
}

export function Avatar({ name, hue, size = "2.6rem" }: { name: string; hue: number; size?: string }) {
  return (
    <div
      className="flex items-center justify-center rounded-full font-bold text-white shadow-[0_0_0_0.12rem_rgba(255,255,255,0.85)]"
      style={{
        width: size,
        height: size,
        fontSize: `calc(${size} * 0.42)`,
        background: `radial-gradient(circle at 30% 25%, hsl(${hue} 90% 70%), hsl(${(hue + 40) % 360} 80% 38%))`,
      }}
    >
      {(name || "P").slice(0, 1).toUpperCase()}
    </div>
  );
}

export function Spinner({ size = "2.2rem" }: { size?: string }) {
  return (
    <div className="relative" style={{ width: size, height: size }}>
      <div className="absolute inset-0 rounded-full border-[0.18rem] border-white/20" />
      <div className="anim-spin absolute inset-0 rounded-full border-[0.18rem] border-transparent border-t-white" />
    </div>
  );
}

export function Toggle({ on }: { on: boolean }) {
  return (
    <div className={`relative h-[1.5rem] w-[2.9rem] rounded-full transition-colors duration-200 ${on ? "bg-[#2e7bff]" : "bg-white/25"}`}>
      <div className={`absolute top-[0.2rem] h-[1.1rem] w-[1.1rem] rounded-full bg-white shadow transition-all duration-200 ${on ? "left-[1.55rem]" : "left-[0.2rem]"}`} />
    </div>
  );
}

export function Meter({ value, className = "" }: { value: number; className?: string }) {
  return (
    <div className={`h-[0.35rem] w-full overflow-hidden rounded-full bg-white/15 ${className}`}>
      <div className="h-full rounded-full bg-gradient-to-r from-[#4aa3ff] to-[#9be0ff] transition-all duration-300" style={{ width: `${Math.max(0, Math.min(1, value)) * 100}%` }} />
    </div>
  );
}

/* ---------- Dialogs ---------- */

export function ConfirmDialog({
  title,
  message,
  confirmLabel = "OK",
  danger,
  onConfirm,
  onCancel,
}: {
  title: string;
  message: string;
  confirmLabel?: string;
  danger?: boolean;
  onConfirm: () => void;
  onCancel: () => void;
}) {
  const [sel, setSel] = useState(0);
  useNav((a) => {
    if (a === "left" || a === "right") {
      setSel((s) => 1 - s);
      sfx.move();
    } else if (a === "confirm") {
      sfx.select();
      sel === 1 ? onConfirm() : onCancel();
    } else if (a === "back") {
      sfx.back();
      onCancel();
    }
  }, true, true);
  return (
    <div className="anim-fade-in absolute inset-0 z-[80] flex items-center justify-center bg-black/70 backdrop-blur-md">
      <div className="anim-pop w-[30rem] rounded-[1.4rem] bg-[#1a1d26]/95 p-8 text-center shadow-2xl ring-1 ring-white/10">
        <h3 className="text-[1.4rem] font-semibold">{title}</h3>
        <p className="mt-3 text-[0.95rem] leading-relaxed text-white/70">{message}</p>
        <div className="mt-7 flex justify-center gap-4">
          {["Cancel", confirmLabel].map((l, i) => (
            <button
              key={l}
              onMouseEnter={() => setSel(i)}
              onClick={() => (i === 1 ? onConfirm() : onCancel())}
              className={`min-w-[9rem] rounded-full px-6 py-[0.7rem] text-[0.95rem] font-semibold transition-all duration-150 ${
                sel === i ? `scale-105 ${i === 1 && danger ? "bg-[#ff5d6c] text-white" : "bg-white text-black"} focus-ring` : "bg-white/12 text-white/80"
              }`}
            >
              {l}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}

export interface OptionItem {
  label: string;
  icon?: ReactNode;
  danger?: boolean;
  onSelect: () => void;
}

export function OptionsPanel({ title, items, onClose }: { title: string; items: OptionItem[]; onClose: () => void }) {
  const [sel, setSel] = useState(0);
  useNav((a) => {
    if (a === "up") {
      setSel((s) => (s + items.length - 1) % items.length);
      sfx.move();
    } else if (a === "down") {
      setSel((s) => (s + 1) % items.length);
      sfx.move();
    } else if (a === "confirm") {
      sfx.select();
      items[sel].onSelect();
    } else if (a === "back" || a === "options") {
      sfx.back();
      onClose();
    }
  }, true, true);
  return (
    <div className="absolute inset-0 z-[70] bg-black/40" onClick={onClose}>
      <div
        onClick={(e) => e.stopPropagation()}
        className="anim-slide-left absolute right-0 top-0 flex h-full w-[22rem] flex-col bg-[#14161d]/90 px-6 pb-8 pt-10 shadow-2xl backdrop-blur-2xl"
      >
        <div className="mb-1 text-[0.75rem] font-semibold uppercase tracking-[0.2em] text-white/50">Options</div>
        <h3 className="mb-6 truncate text-[1.35rem] font-semibold">{title}</h3>
        <div className="flex flex-col gap-1">
          {items.map((it, i) => (
            <button
              key={it.label}
              onMouseEnter={() => setSel(i)}
              onClick={() => it.onSelect()}
              className={`flex items-center gap-3 rounded-xl px-4 py-[0.85rem] text-left text-[0.98rem] font-medium transition-all duration-150 ${
                sel === i ? "bg-white text-black" : "text-white/80"
              } ${it.danger && sel !== i ? "text-[#ff8a95]" : ""}`}
            >
              <span className="h-[1.2rem] w-[1.2rem]">{it.icon}</span>
              {it.label}
            </button>
          ))}
        </div>
        <HintBar className="!bottom-5 !right-6">
          <Hint k="Esc" glyph="circle">Back</Hint>
        </HintBar>
      </div>
    </div>
  );
}
