/* Procedural key-art for games without uploaded artwork + image helpers */

export const svgUri = (s: string) => "data:image/svg+xml;charset=utf-8," + encodeURIComponent(s);

export function hash(str: string): number {
  let h = 2166136261;
  for (let i = 0; i < str.length; i++) {
    h ^= str.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return h >>> 0;
}

function rng(seed: number) {
  let s = seed || 1;
  return () => {
    s ^= s << 13;
    s >>>= 0;
    s ^= s >>> 17;
    s ^= s << 5;
    s >>>= 0;
    return s / 4294967296;
  };
}

export type Motif = "space" | "grid" | "waves" | "abstract";

function scene(m: Motif, w: number, h: number, a: number, b: number, seed: number): string {
  const r = rng(seed);
  const min = Math.min(w, h);
  let o = `<defs>
  <linearGradient id="g" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="hsl(${a} 70% 9%)"/><stop offset="1" stop-color="hsl(${b} 75% 26%)"/></linearGradient>
  <radialGradient id="glow" cx=".72" cy=".38" r=".7"><stop offset="0" stop-color="hsl(${b} 95% 60%)" stop-opacity=".6"/><stop offset="1" stop-color="hsl(${b} 95% 60%)" stop-opacity="0"/></radialGradient>
  <radialGradient id="orb" cx=".35" cy=".3" r=".8"><stop offset="0" stop-color="hsl(${b} 90% 75%)"/><stop offset=".55" stop-color="hsl(${a} 80% 40%)"/><stop offset="1" stop-color="hsl(${a} 80% 8%)"/></radialGradient>
  <linearGradient id="sun" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="hsl(${(b + 40) % 360} 100% 65%)"/><stop offset="1" stop-color="hsl(${(a + 300) % 360} 100% 55%)"/></linearGradient>
  </defs>
  <rect width="${w}" height="${h}" fill="url(#g)"/><rect width="${w}" height="${h}" fill="url(#glow)"/>`;
  if (m === "space") {
    for (let i = 0; i < Math.round((w * h) / 9000); i++) {
      o += `<circle cx="${r() * w}" cy="${r() * h}" r="${r() * min * 0.004 + 0.5}" fill="#fff" opacity="${0.3 + r() * 0.7}"/>`;
    }
    const cx = w * 0.7, cy = h * 0.42, pr = min * 0.26;
    o += `<ellipse cx="${cx}" cy="${cy}" rx="${pr * 1.8}" ry="${pr * 0.32}" fill="none" stroke="hsl(${b} 90% 80%)" stroke-opacity=".35" stroke-width="${pr * 0.07}" transform="rotate(-18 ${cx} ${cy})"/>`;
    o += `<circle cx="${cx}" cy="${cy}" r="${pr}" fill="url(#orb)"/>`;
    o += `<path d="M${cx - pr * 1.8} ${cy + pr * 0.4} Q${cx} ${cy + pr * 0.75} ${cx + pr * 1.8} ${cy - pr * 0.4}" stroke="hsl(${b} 90% 85%)" stroke-opacity=".5" stroke-width="${pr * 0.05}" fill="none" transform="rotate(-18 ${cx} ${cy})"/>`;
  } else if (m === "grid") {
    const hz = h * 0.58;
    o += `<circle cx="${w / 2}" cy="${hz}" r="${min * 0.3}" fill="url(#sun)"/>`;
    for (let i = 0; i < 7; i++) o += `<rect x="0" y="${hz - min * 0.06 * i}" width="${w}" height="${min * 0.008 * (i + 1) * 0.6}" fill="hsl(${a} 70% 9%)"/>`;
    o += `<rect x="0" y="${hz}" width="${w}" height="${h - hz}" fill="hsl(${a} 70% 7%)"/>`;
    for (let i = -14; i <= 14; i++) o += `<line x1="${w / 2 + i * w * 0.02}" y1="${hz}" x2="${w / 2 + i * w * 0.2}" y2="${h}" stroke="hsl(${(b + 40) % 360} 100% 65%)" stroke-opacity=".6" stroke-width="${min * 0.004}"/>`;
    for (let i = 1; i < 10; i++) {
      const y = hz + Math.pow(i / 10, 2.2) * (h - hz);
      o += `<line x1="0" y1="${y}" x2="${w}" y2="${y}" stroke="hsl(${(b + 40) % 360} 100% 65%)" stroke-opacity=".6" stroke-width="${min * 0.004}"/>`;
    }
  } else if (m === "waves") {
    for (let i = 0; i < 7; i++) {
      const y = h * (0.35 + i * 0.1);
      const amp = h * (0.04 + r() * 0.05);
      const k = 2 + r() * 3;
      let d = `M0 ${h} L0 ${y}`;
      for (let x = 0; x <= w; x += w / 40) d += ` L${x} ${y + Math.sin((x / w) * k * Math.PI + i) * amp}`;
      d += ` L${w} ${h} Z`;
      o += `<path d="${d}" fill="hsl(${a + i * 14} 85% ${20 + i * 6}%)" fill-opacity=".5"/>`;
    }
  } else {
    for (let i = 0; i < 16; i++) {
      const x = r() * w, y = r() * h, s = min * (0.08 + r() * 0.3);
      const hue = r() > 0.5 ? a : b;
      if (r() > 0.5) o += `<circle cx="${x}" cy="${y}" r="${s}" fill="hsl(${hue} 85% 55%)" fill-opacity="${0.08 + r() * 0.2}"/>`;
      else o += `<polygon points="${x},${y - s} ${x + s * 0.9},${y + s * 0.6} ${x - s * 0.9},${y + s * 0.6}" fill="hsl(${hue} 85% 60%)" fill-opacity="${0.08 + r() * 0.2}" transform="rotate(${r() * 90} ${x} ${y})"/>`;
    }
  }
  return o;
}

function wrap(title: string, max: number): string[] {
  const words = title.trim().split(/\s+/);
  const lines: string[] = [];
  let cur = "";
  for (const wd of words) {
    if ((cur + " " + wd).trim().length > max && cur) {
      lines.push(cur);
      cur = wd;
    } else cur = (cur + " " + wd).trim();
  }
  if (cur) lines.push(cur);
  return lines.slice(0, 3);
}

const esc = (s: string) => s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");

export interface ArtOpts {
  hueA?: number;
  hueB?: number;
  motif?: Motif;
}

export function buildArt(title: string, opts: ArtOpts = {}) {
  const seed = hash(title);
  const hueA = opts.hueA ?? seed % 360;
  const hueB = opts.hueB ?? (seed >> 8) % 360;
  const motif: Motif = opts.motif ?? (["space", "grid", "waves", "abstract"] as Motif[])[seed % 4];
  const lines = wrap(title.toUpperCase(), 11);

  // cover (square)
  const fs = 74 - Math.max(0, lines.length - 1) * 12;
  let cover = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512">${scene(motif, 512, 512, hueA, hueB, seed)}
  <rect y="230" width="512" height="282" fill="url(#shade)"/>
  <defs><linearGradient id="shade" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#000" stop-opacity="0"/><stop offset="1" stop-color="#000" stop-opacity=".85"/></linearGradient></defs>`;
  lines.forEach((l, i) => {
    const y = 512 - 36 - (lines.length - 1 - i) * (fs + 4);
    cover += `<text x="30" y="${y}" font-family="Arial Black, Arial, sans-serif" font-weight="900" font-style="italic" font-size="${fs}" fill="#fff" textLength="${Math.min(452, l.length * fs * 0.62)}" lengthAdjust="spacingAndGlyphs">${esc(l)}</text>`;
  });
  cover += `</svg>`;

  // background (16:9)
  const background = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1920 1080" preserveAspectRatio="xMidYMid slice">${scene(motif, 1920, 1080, hueA, hueB, seed)}</svg>`;

  // logo (transparent)
  const lfs = lines.length > 1 ? 150 : 190;
  let logo = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1400 ${60 + lines.length * (lfs + 10)}">
  <defs><linearGradient id="lg" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#fff"/><stop offset="1" stop-color="hsl(${hueB} 90% 78%)"/></linearGradient></defs>`;
  lines.forEach((l, i) => {
    logo += `<text x="30" y="${lfs + i * (lfs + 10)}" font-family="Arial Black, Arial, sans-serif" font-weight="900" font-style="italic" font-size="${lfs}" fill="url(#lg)" stroke="hsl(${hueA} 80% 15%)" stroke-width="3" textLength="${Math.min(1340, l.length * lfs * 0.64)}" lengthAdjust="spacingAndGlyphs">${esc(l)}</text>`;
  });
  logo += `</svg>`;

  return { cover: svgUri(cover), background: svgUri(background), logo: svgUri(logo) };
}

/** Read an image file, downscale it, return a data URL. SVGs are passed through. */
export function fileToDataUrl(file: File, maxDim: number, mime: "image/jpeg" | "image/png" = "image/jpeg"): Promise<string> {
  return new Promise((resolve, reject) => {
    if (file.type === "image/svg+xml") {
      const fr = new FileReader();
      fr.onload = () => resolve(fr.result as string);
      fr.onerror = () => reject(fr.error);
      fr.readAsDataURL(file);
      return;
    }
    const url = URL.createObjectURL(file);
    const img = new Image();
    img.onload = () => {
      const k = Math.min(1, maxDim / Math.max(img.width, img.height));
      const c = document.createElement("canvas");
      c.width = Math.max(1, Math.round(img.width * k));
      c.height = Math.max(1, Math.round(img.height * k));
      c.getContext("2d")!.drawImage(img, 0, 0, c.width, c.height);
      URL.revokeObjectURL(url);
      resolve(c.toDataURL(mime, 0.88));
    };
    img.onerror = () => {
      URL.revokeObjectURL(url);
      reject(new Error("Could not read image"));
    };
    img.src = url;
  });
}
