export interface Theme {
  id: string;
  name: string;
  colors: [string, string, string];
}

export const THEMES: Theme[] = [
  { id: "midnight", name: "Midnight", colors: ["#07123a", "#1d4ed8", "#0ea5e9"] },
  { id: "nebula", name: "Nebula", colors: ["#140a33", "#7c3aed", "#38bdf8"] },
  { id: "aurora", name: "Aurora", colors: ["#04221f", "#10b981", "#6366f1"] },
  { id: "ember", name: "Ember", colors: ["#2a0a0a", "#ea580c", "#db2777"] },
  { id: "graphite", name: "Graphite", colors: ["#0c0c0e", "#3f4350", "#9ca3af"] },
];

export const getTheme = (id: string) => THEMES.find((t) => t.id === id) ?? THEMES[0];
