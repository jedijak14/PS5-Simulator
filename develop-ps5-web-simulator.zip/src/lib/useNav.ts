import { useEffect, useRef } from "react";

export type Action = "up" | "down" | "left" | "right" | "confirm" | "back" | "options" | "ps";

export function toAction(e: KeyboardEvent): Action | null {
  if (e.ctrlKey || e.metaKey || e.altKey) return null;
  switch (e.key) {
    case "ArrowUp":
    case "w":
    case "W":
      return "up";
    case "ArrowDown":
    case "s":
    case "S":
      return "down";
    case "ArrowLeft":
    case "a":
    case "A":
      return "left";
    case "ArrowRight":
    case "d":
    case "D":
      return "right";
    case "Enter":
      return "confirm";
    case "Escape":
    case "Backspace":
      return "back";
    case "Tab":
    case "o":
    case "O":
      return "options";
    case "F1":
    case "Home":
      return "ps";
  }
  return null;
}

/**
 * Subscribe to console-style actions mapped from the keyboard.
 * While a text field is focused only Escape / F1 are handled.
 */
export function useNav(handler: (a: Action, e: KeyboardEvent) => void, active = true, modal = false) {
  const ref = useRef(handler);
  ref.current = handler;
  useEffect(() => {
    if (!active) return;
    const f = (e: KeyboardEvent) => {
      const a = toAction(e);
      if (!a) return;
      const t = e.target as HTMLElement | null;
      const typing = !!t && (t.tagName === "INPUT" || t.tagName === "TEXTAREA" || t.isContentEditable) &&
        (t as HTMLInputElement).type !== "range" && (t as HTMLInputElement).type !== "checkbox";
      if (typing && !(e.key === "Escape" || e.key === "F1")) return;
      e.preventDefault();
      // modal layers listen in the capture phase and swallow the key so screens underneath never see it
      if (modal) e.stopImmediatePropagation();
      if (e.repeat && (a === "confirm" || a === "back" || a === "ps" || a === "options")) return;
      ref.current(a, e);
    };
    window.addEventListener("keydown", f, modal);
    return () => window.removeEventListener("keydown", f, modal);
  }, [active, modal]);
}
