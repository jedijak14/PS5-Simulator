import type { Game } from "../types";
import { buildArt } from "./art";

const END = "</scr" + "ipt>";

const STARFALL = `<!doctype html><html><head><meta charset="utf-8"><title>Starfall</title>
<style>html,body{margin:0;height:100%;background:#050816;overflow:hidden;font-family:Arial,sans-serif}canvas{display:block;width:100%;height:100%}</style></head>
<body><canvas id="c"></canvas><script>
var c=document.getElementById('c'),x=c.getContext('2d'),W,H;
function rs(){W=c.width=innerWidth;H=c.height=innerHeight}rs();addEventListener('resize',rs);
var keys={};
addEventListener('keydown',function(e){keys[e.code]=1;if(['Space','ArrowUp','ArrowDown','ArrowLeft','ArrowRight'].indexOf(e.code)>-1)e.preventDefault();if(e.code==='Enter'&&over)reset()});
addEventListener('keyup',function(e){keys[e.code]=0});
var ship,bullets,enemies,parts,stars=[],score,lives,over,t,cool,inv,best=0;
try{best=+localStorage.getItem('starfall-best')||0}catch(_){}
for(var i=0;i<150;i++)stars.push({x:Math.random()*2000,y:Math.random()*1200,z:Math.random()*2+.3});
function reset(){ship={x:W/2,y:H-100,vx:0,vy:0};bullets=[];enemies=[];parts=[];score=0;lives=3;over=false;t=0;cool=0;inv=0}
reset();
function boom(px,py,col){for(var i=0;i<24;i++){var a=Math.random()*6.28,s=Math.random()*5+1;parts.push({x:px,y:py,vx:Math.cos(a)*s,vy:Math.sin(a)*s,l:1,col:col})}}
var last=performance.now();
function loop(n){var dt=Math.min(.05,(n-last)/1000)*60;last=n;update(dt);draw();requestAnimationFrame(loop)}
function update(dt){
 stars.forEach(function(s){s.y+=s.z*dt*1.5;if(s.y>H){s.y=0;s.x=Math.random()*W}});
 parts.forEach(function(p){p.x+=p.vx*dt;p.y+=p.vy*dt;p.l-=.03*dt});parts=parts.filter(function(p){return p.l>0});
 if(over)return;t+=dt;
 var L=keys.ArrowLeft||keys.KeyA,R=keys.ArrowRight||keys.KeyD,U=keys.ArrowUp||keys.KeyW,D=keys.ArrowDown||keys.KeyS;
 ship.vx+=((R?1:0)-(L?1:0))*.9*dt;ship.vy+=((D?1:0)-(U?1:0))*.9*dt;
 ship.vx*=Math.pow(.86,dt);ship.vy*=Math.pow(.86,dt);
 ship.x=Math.max(20,Math.min(W-20,ship.x+ship.vx*dt));ship.y=Math.max(40,Math.min(H-30,ship.y+ship.vy*dt));
 cool-=dt;if(keys.Space&&cool<=0){bullets.push({x:ship.x,y:ship.y-18});cool=9}
 if(inv>0)inv-=dt;
 if(Math.random()<(.02+Math.min(.05,t/60000))*dt)enemies.push({x:Math.random()*(W-80)+40,y:-30,vx:(Math.random()-.5)*3,s:Math.random()*1.5+1.2,hp:2,r:18});
 bullets.forEach(function(b){b.y-=12*dt});bullets=bullets.filter(function(b){return b.y>-20});
 enemies.forEach(function(e){e.y+=e.s*dt;e.x+=Math.sin((e.y+e.x)/60)*e.vx*dt});
 enemies.forEach(function(e){
  bullets.forEach(function(b){if(Math.abs(b.x-e.x)<e.r&&Math.abs(b.y-e.y)<e.r){b.y=-99;e.hp--;if(e.hp<=0){e.dead=1;score+=10;boom(e.x,e.y,'#ff6ad5')}}});
  if(!e.dead&&inv<=0&&Math.hypot(e.x-ship.x,e.y-ship.y)<e.r+14){e.dead=1;boom(e.x,e.y,'#ff6ad5');boom(ship.x,ship.y,'#7cc4ff');lives--;inv=90;
   if(lives<=0){over=true;if(score>best){best=score;try{localStorage.setItem('starfall-best',best)}catch(_){}}}}
  if(e.y>H+40)e.dead=1;
 });
 enemies=enemies.filter(function(e){return !e.dead});
}
function draw(){
 var g=x.createLinearGradient(0,0,0,H);g.addColorStop(0,'#050816');g.addColorStop(1,'#1b1040');x.fillStyle=g;x.fillRect(0,0,W,H);
 stars.forEach(function(s){x.globalAlpha=.3+s.z/3;x.fillStyle='#fff';x.fillRect(s.x%W,s.y,s.z,s.z)});x.globalAlpha=1;
 parts.forEach(function(p){x.globalAlpha=p.l;x.fillStyle=p.col;x.fillRect(p.x,p.y,3,3)});x.globalAlpha=1;
 x.shadowBlur=18;
 bullets.forEach(function(b){x.shadowColor='#7cf';x.fillStyle='#bff';x.fillRect(b.x-2,b.y-10,4,16)});
 enemies.forEach(function(e){x.shadowColor='#f6d';x.fillStyle='#ff6ad5';x.beginPath();x.moveTo(e.x,e.y-e.r);x.lineTo(e.x+e.r,e.y);x.lineTo(e.x,e.y+e.r);x.lineTo(e.x-e.r,e.y);x.closePath();x.fill()});
 if(!over&&(inv<=0||Math.floor(inv/4)%2)){x.shadowColor='#7cc4ff';x.fillStyle='#e8f4ff';x.beginPath();x.moveTo(ship.x,ship.y-22);x.lineTo(ship.x+16,ship.y+16);x.lineTo(ship.x,ship.y+8);x.lineTo(ship.x-16,ship.y+16);x.closePath();x.fill();
  x.fillStyle='#4af';x.fillRect(ship.x-3,ship.y+10,6,6+Math.random()*10)}
 x.shadowBlur=0;x.fillStyle='#fff';x.font='bold 22px Arial';x.textAlign='left';x.fillText('SCORE '+score,24,40);x.textAlign='right';x.fillText('BEST '+best,W-24,40);
 x.textAlign='center';x.fillText('LIVES '+'\\u25B2 '.repeat(Math.max(0,lives)),W/2,40);
 if(over){x.fillStyle='rgba(0,0,0,.55)';x.fillRect(0,0,W,H);x.fillStyle='#fff';x.font='900 64px Arial';x.fillText('MISSION FAILED',W/2,H/2-10);x.font='24px Arial';x.fillText('Score '+score+'  -  Press Enter to retry',W/2,H/2+40)}
 else if(t<240){x.globalAlpha=1-t/240;x.font='22px Arial';x.fillStyle='#bcd';x.fillText('Move: Arrow keys / WASD     Fire: Space',W/2,H-30);x.globalAlpha=1}
}
requestAnimationFrame(loop);
${END}</body></html>`;

const SERPENT = `<!doctype html><html><head><meta charset="utf-8"><title>Neon Serpent</title>
<style>html,body{margin:0;height:100%;background:#03110b;overflow:hidden;font-family:Arial,sans-serif}canvas{display:block;width:100%;height:100%}</style></head>
<body><canvas id="c"></canvas><script>
var c=document.getElementById('c'),x=c.getContext('2d'),COLS=30,ROWS=18,cell,ox,oy;
function rs(){c.width=innerWidth;c.height=innerHeight;cell=Math.floor(Math.min(c.width*.92/COLS,c.height*.8/ROWS));ox=(c.width-cell*COLS)/2;oy=(c.height-cell*ROWS)/2+24}
rs();addEventListener('resize',rs);
var snake,dir,nd,food,score,over,paused,speed,acc=0,best=0,tick=0;
try{best=+localStorage.getItem('serpent-best')||0}catch(_){}
function place(){do{food={x:Math.random()*COLS|0,y:Math.random()*ROWS|0}}while(snake.some(function(s){return s.x===food.x&&s.y===food.y}))}
function reset(){snake=[{x:8,y:9},{x:7,y:9},{x:6,y:9}];dir={x:1,y:0};nd=dir;score=0;over=false;paused=false;speed=120;place()}
reset();
addEventListener('keydown',function(e){
 var k=e.key,d=null;
 if(k==='ArrowUp'||k==='w'||k==='W')d={x:0,y:-1};
 if(k==='ArrowDown'||k==='s'||k==='S')d={x:0,y:1};
 if(k==='ArrowLeft'||k==='a'||k==='A')d={x:-1,y:0};
 if(k==='ArrowRight'||k==='d'||k==='D')d={x:1,y:0};
 if(d){e.preventDefault();if(d.x!==-dir.x||d.y!==-dir.y)nd=d}
 if(k==='Enter'&&over)reset();
 if(k==='p'||k==='P'||k===' '){e.preventDefault();if(!over)paused=!paused}
});
function step(){
 dir=nd;var h={x:snake[0].x+dir.x,y:snake[0].y+dir.y};
 if(h.x<0||h.y<0||h.x>=COLS||h.y>=ROWS||snake.some(function(s){return s.x===h.x&&s.y===h.y})){over=true;if(score>best){best=score;try{localStorage.setItem('serpent-best',best)}catch(_){}}return}
 snake.unshift(h);
 if(h.x===food.x&&h.y===food.y){score+=10;speed=Math.max(55,speed-3);place()}else snake.pop();
}
var last=performance.now();
function loop(n){var dt=n-last;last=n;tick+=dt;if(!over&&!paused){acc+=dt;while(acc>=speed){acc-=speed;step();if(over)break}}draw();requestAnimationFrame(loop)}
function draw(){
 x.fillStyle='#03110b';x.fillRect(0,0,c.width,c.height);
 var g=x.createRadialGradient(c.width/2,c.height/2,50,c.width/2,c.height/2,c.width/1.2);g.addColorStop(0,'#0b3a28');g.addColorStop(1,'#03110b');x.fillStyle=g;x.fillRect(0,0,c.width,c.height);
 x.strokeStyle='rgba(80,255,170,.08)';x.lineWidth=1;
 for(var i=0;i<=COLS;i++){x.beginPath();x.moveTo(ox+i*cell,oy);x.lineTo(ox+i*cell,oy+ROWS*cell);x.stroke()}
 for(var j=0;j<=ROWS;j++){x.beginPath();x.moveTo(ox,oy+j*cell);x.lineTo(ox+COLS*cell,oy+j*cell);x.stroke()}
 x.strokeStyle='#3dffa8';x.lineWidth=2;x.shadowColor='#3dffa8';x.shadowBlur=14;x.strokeRect(ox,oy,COLS*cell,ROWS*cell);
 var p=1+Math.sin(tick/150)*.18;x.fillStyle='#ff4d8d';x.shadowColor='#ff4d8d';x.shadowBlur=22;
 x.beginPath();x.arc(ox+(food.x+.5)*cell,oy+(food.y+.5)*cell,cell*.32*p,0,6.3);x.fill();
 snake.forEach(function(s,i){var a=1-i/(snake.length+6)*.7;x.fillStyle='hsla('+(150+i*3)+',100%,'+(i?55:75)+'%,'+a+')';x.shadowColor='#3dffa8';x.shadowBlur=i?8:20;
  var r=cell*.08;x.beginPath();x.roundRect?x.roundRect(ox+s.x*cell+2,oy+s.y*cell+2,cell-4,cell-4,r*2):x.rect(ox+s.x*cell+2,oy+s.y*cell+2,cell-4,cell-4);x.fill()});
 x.shadowBlur=0;x.fillStyle='#d6ffe9';x.font='bold 24px Arial';x.textAlign='left';x.fillText('SCORE '+score,ox,oy-18);x.textAlign='right';x.fillText('BEST '+best,ox+COLS*cell,oy-18);
 x.textAlign='center';x.font='16px Arial';x.fillStyle='rgba(214,255,233,.6)';x.fillText('Arrow keys / WASD to steer   -   Space to pause',c.width/2,oy+ROWS*cell+30);
 if(over||paused){x.fillStyle='rgba(0,0,0,.6)';x.fillRect(ox,oy,COLS*cell,ROWS*cell);x.fillStyle='#fff';x.font='900 56px Arial';x.fillText(over?'GAME OVER':'PAUSED',c.width/2,c.height/2);x.font='22px Arial';if(over)x.fillText('Press Enter to play again',c.width/2,c.height/2+40)}
}
requestAnimationFrame(loop);
${END}</body></html>`;

function demo(id: string, title: string, html: string, opts: Parameters<typeof buildArt>[1], addedAt: number): Game {
  const art = buildArt(title, opts);
  return { id, title, html, ...art, addedAt, builtin: true, playtime: 0 };
}

export const DEMO_GAMES: Game[] = [
  demo("demo-starfall", "Starfall", STARFALL, { hueA: 255, hueB: 315, motif: "space" }, 2),
  demo("demo-serpent", "Neon Serpent", SERPENT, { hueA: 160, hueB: 165, motif: "grid" }, 1),
];
