import type { Game, Settings } from "../types";

const DB_NAME = "ps5-sim";
const STORE = "games";

function openDb(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    const req = indexedDB.open(DB_NAME, 1);
    req.onupgradeneeded = () => {
      req.result.createObjectStore(STORE, { keyPath: "id" });
    };
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}

export async function loadUserGames(): Promise<Game[]> {
  try {
    const db = await openDb();
    return await new Promise((resolve, reject) => {
      const r = db.transaction(STORE).objectStore(STORE).getAll();
      r.onsuccess = () => resolve(r.result as Game[]);
      r.onerror = () => reject(r.error);
    });
  } catch {
    return [];
  }
}

export async function saveGame(g: Game): Promise<void> {
  const db = await openDb();
  await new Promise<void>((resolve, reject) => {
    const tx = db.transaction(STORE, "readwrite");
    tx.objectStore(STORE).put(g);
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
  });
}

export async function removeGame(id: string): Promise<void> {
  const db = await openDb();
  await new Promise<void>((resolve, reject) => {
    const tx = db.transaction(STORE, "readwrite");
    tx.objectStore(STORE).delete(id);
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
  });
}

export async function clearGames(): Promise<void> {
  const db = await openDb();
  await new Promise<void>((resolve, reject) => {
    const tx = db.transaction(STORE, "readwrite");
    tx.objectStore(STORE).clear();
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
  });
}

/* ---- meta (last played / playtime) and hidden demo games ---- */

export type Meta = Record<string, { lastPlayed?: number; playtime: number }>;

export function getMeta(): Meta {
  try {
    return JSON.parse(localStorage.getItem("ps5.meta") || "{}");
  } catch {
    return {};
  }
}
export function addPlaytime(id: string, seconds: number) {
  const m = getMeta();
  const cur = m[id] ?? { playtime: 0 };
  m[id] = { lastPlayed: Date.now(), playtime: cur.playtime + seconds };
  localStorage.setItem("ps5.meta", JSON.stringify(m));
}
export function getHidden(): string[] {
  try {
    return JSON.parse(localStorage.getItem("ps5.hidden") || "[]");
  } catch {
    return [];
  }
}
export function setHidden(ids: string[]) {
  localStorage.setItem("ps5.hidden", JSON.stringify(ids));
}

/* ---- settings ---- */

export const DEFAULT_SETTINGS: Settings = {
  userName: "Player_One",
  avatarHue: 215,
  sfx: true,
  volume: 0.7,
  brightness: 1,
  hdr: false,
  hints: true,
  theme: "midnight",
  motion: true,
};

export function loadSettings(): Settings {
  try {
    return { ...DEFAULT_SETTINGS, ...JSON.parse(localStorage.getItem("ps5.settings") || "{}") };
  } catch {
    return DEFAULT_SETTINGS;
  }
}
export function saveSettings(s: Settings) {
  localStorage.setItem("ps5.settings", JSON.stringify(s));
}

export async function factoryReset() {
  localStorage.removeItem("ps5.settings");
  localStorage.removeItem("ps5.meta");
  localStorage.removeItem("ps5.hidden");
  await clearGames().catch(() => undefined);
}
